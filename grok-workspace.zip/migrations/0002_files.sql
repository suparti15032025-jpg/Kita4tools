create table if not exists files (
  id text primary key,
  original_name text not null,
  stored_name text not null,
  mime_type text not null,
  size_bytes integer not null,
  kind text not null,
  data bytea not null,
  download_count integer not null default 0,
  expires_at timestamptz,
  created_at timestamptz not null default now(),
  reported boolean not null default false
);

create index if not exists files_created_at_idx on files (created_at desc);
create index if not exists files_expires_at_idx on files (expires_at);
create index if not exists files_reported_idx on files (reported);

create table if not exists reports (
  id serial primary key,
  file_id text not null,
  reason text not null,
  created_at timestamptz not null default now()
);

create index if not exists reports_file_id_idx on reports (file_id);
