alter table files add column if not exists status text not null default 'ready';
alter table files add column if not exists chunk_count integer not null default 0;
alter table files alter column data drop not null;

create table if not exists file_chunks (
  file_id text not null,
  chunk_index integer not null,
  data bytea not null,
  primary key (file_id, chunk_index)
);

create index if not exists file_chunks_file_id_idx on file_chunks (file_id);
