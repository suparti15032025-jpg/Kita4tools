import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { x as formatBytes, y as fileExtension } from "./tiktok.server-BNVcQmyB.mjs";
import { m as Download } from "../_libs/lucide-react.mjs";
import { a as SiteShell, o as Button, r as Route$3 } from "./router-CJOUtL5o.mjs";
import { t as ReportDialog } from "./report-dialog-Ce3SdYd8.mjs";
import { n as formatDistanceToNow, t as id } from "../_libs/date-fns.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/f._id-C6NW2F0l.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function LinkQr({ value, size = 168 }) {
	const ref = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		const canvas = ref.current;
		if (!canvas || !value) return;
		let cancelled = false;
		(async () => {
			const QRCode = await import("../_libs/qrcode.mjs").then((n) => /* @__PURE__ */ __toESM(n.t()));
			if (cancelled) return;
			await QRCode.toCanvas(canvas, value, {
				width: size,
				margin: 1,
				color: {
					dark: "#161512",
					light: "#fffcf7"
				}
			});
		})();
		return () => {
			cancelled = true;
		};
	}, [value, size]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
		ref,
		width: size,
		height: size,
		className: "rounded-md"
	});
}
function FilePage() {
	const file = Route$3.useLoaderData();
	const downloadUrl = `/api/dl/${file.id}`;
	const pageUrl = typeof window === "undefined" ? `/f/${file.id}` : window.location.href;
	const ext = fileExtension(file.originalName) || "file";
	const expiry = file.expiresAt ? `Kedaluwarsa ${formatDistanceToNow(new Date(file.expiresAt), {
		addSuffix: true,
		locale: id
	})}` : "Permanen";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mx-auto max-w-3xl px-4 py-12 sm:px-6 sm:py-16",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "panel overflow-hidden rounded-2xl",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "border-b border-border px-6 py-8 sm:px-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "kicker",
					children: "Berkas publik"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-5 flex items-start gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "flex size-14 shrink-0 items-center justify-center rounded-lg bg-secondary font-mono text-xs font-medium uppercase tracking-wider",
						children: ext.slice(0, 4)
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "min-w-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "font-display text-title leading-tight font-semibold tracking-tight break-all",
							children: file.originalName
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-2 text-sm text-muted",
							children: [
								formatBytes(file.sizeBytes),
								" · ",
								expiry
							]
						})]
					})]
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-8 px-6 py-8 sm:px-8 lg:grid-cols-[1fr_11rem]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
							className: "grid grid-cols-2 gap-4 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-muted",
								children: "Diunggah"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "mt-1 font-medium",
								children: formatDistanceToNow(new Date(file.createdAt), {
									addSuffix: true,
									locale: id
								})
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
								className: "text-muted",
								children: "Unduhan"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
								className: "mt-1 font-medium tabular-nums",
								children: file.downloadCount
							})] })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							asChild: true,
							size: "lg",
							className: "w-full",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								href: downloadUrl,
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {}), "Unduh berkas"]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: "Berkas tidak tersimpan otomatis. Ketuk tombol di atas jika Anda ingin mengunduhnya."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReportDialog, { fileId: file.id })
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
					className: "flex flex-col items-start gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LinkQr, {
						value: pageUrl,
						size: 140
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs leading-relaxed text-muted",
						children: "Pindai dengan kamera HP — iPhone, Android, atau Google Lens. Tidak perlu aplikasi tambahan."
					})]
				})]
			})]
		})
	}) });
}
//#endregion
export { FilePage as component };
