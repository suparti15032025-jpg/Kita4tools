import { n as clsx } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { randomBytes } from "node:crypto";
//#region node_modules/.nitro/vite/services/ssr/assets/tiktok.server-BNVcQmyB.js
var APP_NAME = "Kita";
var APP_TAGLINE = "Semua alat, satu tempat.";
var MAX_MEDIA_BYTES = 31457280;
var MAX_FILE_BYTES = 157286400;
var UPLOAD_CHUNK_BYTES = 1572864;
function formatMbLimit(bytes) {
	return `${Math.round(bytes / 1048576)} MB`;
}
var BLOCKED_EXTENSIONS = /* @__PURE__ */ new Set([
	"php",
	"phtml",
	"php3",
	"php4",
	"php5",
	"phar",
	"sh",
	"bash",
	"zsh",
	"csh",
	"jsp",
	"jspx",
	"asp",
	"aspx",
	"cgi",
	"htaccess",
	"htpasswd",
	"py",
	"rb",
	"pl",
	"exe",
	"bat",
	"cmd",
	"ps1",
	"com",
	"dll",
	"so"
]);
var IMAGE_EXT = /* @__PURE__ */ new Set([
	"jpg",
	"jpeg",
	"png",
	"gif",
	"webp"
]);
var VIDEO_EXT = /* @__PURE__ */ new Set([
	"mp4",
	"webm",
	"mov"
]);
var INLINE_EXT = /* @__PURE__ */ new Set([...IMAGE_EXT, ...VIDEO_EXT]);
var IMAGE_MIME = /* @__PURE__ */ new Set([
	"image/jpeg",
	"image/png",
	"image/gif",
	"image/webp"
]);
var VIDEO_MIME = /* @__PURE__ */ new Set([
	"video/mp4",
	"video/webm",
	"video/quicktime"
]);
var APK_MIME = "application/vnd.android.package-archive";
var EXPIRY_OPTIONS = [
	{
		id: "1h",
		label: "1 jam",
		ms: 36e5
	},
	{
		id: "1d",
		label: "1 hari",
		ms: 864e5
	},
	{
		id: "7d",
		label: "7 hari",
		ms: 6048e5
	},
	{
		id: "30d",
		label: "30 hari",
		ms: 2592e6
	},
	{
		id: "forever",
		label: "Permanen",
		ms: null
	}
];
var REPORT_REASONS = [
	{
		id: "spam",
		label: "Spam atau iklan"
	},
	{
		id: "malware",
		label: "Malware / berbahaya"
	},
	{
		id: "copyright",
		label: "Melanggar hak cipta"
	},
	{
		id: "illegal",
		label: "Konten ilegal"
	},
	{
		id: "other",
		label: "Lainnya"
	}
];
var ADMIN_COOKIE = "kita_admin";
var ADMIN_PASSWORD_DEFAULT = "kita-admin";
var RATE = {
	upload: {
		limit: 40,
		windowMs: 36e5
	},
	chunk: {
		limit: 400,
		windowMs: 36e5
	},
	tiktok: {
		limit: 24,
		windowMs: 36e5
	},
	report: {
		limit: 12,
		windowMs: 36e5
	},
	admin: {
		limit: 12,
		windowMs: 9e5
	}
};
var TOOLS = [
	{
		slug: "qr",
		index: "01",
		href: "/qr",
		short: "QR",
		title: "QR Code",
		blurb: "Teks, WiFi, WhatsApp, email, dan vCard. Logo di tengah, unduh PNG atau SVG."
	},
	{
		slug: "media",
		index: "02",
		href: "/media",
		short: "Media",
		title: "Tautan media",
		blurb: "Unggah gambar atau video, dapatkan tautan langsung, halaman pratinjau, dan kode embed."
	},
	{
		slug: "tiktok",
		index: "03",
		href: "/tiktok",
		short: "TikTok",
		title: "Unduh TikTok",
		blurb: "Ambil video tanpa watermark, audio MP3, atau foto slideshow dari tautan TikTok."
	},
	{
		slug: "upload",
		index: "04",
		href: "/upload",
		short: "Berkas",
		title: "Berkas publik",
		blurb: "APK, ZIP, PDF, dan berkas lain jadi tautan unik. Atur masa aktif, unduh lewat halaman rapi."
	}
];
var _0002_files_default = "create table if not exists files (\n  id text primary key,\n  original_name text not null,\n  stored_name text not null,\n  mime_type text not null,\n  size_bytes integer not null,\n  kind text not null,\n  data bytea not null,\n  download_count integer not null default 0,\n  expires_at timestamptz,\n  created_at timestamptz not null default now(),\n  reported boolean not null default false\n);\n\ncreate index if not exists files_created_at_idx on files (created_at desc);\ncreate index if not exists files_expires_at_idx on files (expires_at);\ncreate index if not exists files_reported_idx on files (reported);\n\ncreate table if not exists reports (\n  id serial primary key,\n  file_id text not null,\n  reason text not null,\n  created_at timestamptz not null default now()\n);\n\ncreate index if not exists reports_file_id_idx on reports (file_id);\n";
var _0003_file_chunks_default = "alter table files add column if not exists status text not null default 'ready';\nalter table files add column if not exists chunk_count integer not null default 0;\nalter table files alter column data drop not null;\n\ncreate table if not exists file_chunks (\n  file_id text not null,\n  chunk_index integer not null,\n  data bytea not null,\n  primary key (file_id, chunk_index)\n);\n\ncreate index if not exists file_chunks_file_id_idx on file_chunks (file_id);\n";
/**
* Migration bookkeeping shared by the two appliers — `scripts/migrate.mjs`
* (deploy, `readdir`) and `src/lib/db.ts` (PGLite preview, `import.meta.glob`).
*
* Applied files are keyed by BASENAME, so the same file applies once no matter
* which directory it is globbed from. That is what makes the auth schema safe to
* copy from `migrations/auth/` into `migrations/` when an app turns sign-in on:
* a database that already has `0001_auth.sql` will not re-run it.
*
* Neither applier descends into subdirectories, so `migrations/auth/*.sql` is
* out of scope for both until it is copied up.
*/
/**
* The `_migrations` key for a migration path (or bare filename).
* @param {string} path
* @returns {string}
*/
function migrationName(path) {
	return path.split("/").pop() ?? path;
}
/**
* @param {string} path
* @returns {boolean}
*/
function isMigrationFile(path) {
	return path.endsWith(".sql");
}
/**
* Migrations in `paths` that are not yet in `applied`, in apply order.
* Non-`.sql` entries (a `readdir` also yields `migrations/auth/`) are dropped.
* @param {Iterable<string>} paths
* @param {Iterable<string>} applied
* @returns {Array<{ name: string, path: string }>}
*/
function pendingMigrations(paths, applied) {
	const done = new Set(applied);
	return [...paths].filter(isMigrationFile).map((path) => ({
		name: migrationName(path),
		path
	})).sort((a, b) => a.name.localeCompare(b.name)).filter(({ name }) => !done.has(name));
}
var rawDatabaseUrl = typeof process !== "undefined" ? process.env.DATABASE_URL : void 0;
var databaseUrl = rawDatabaseUrl && rawDatabaseUrl.trim() ? rawDatabaseUrl : void 0;
/**
* Active backend: real **Neon** when `DATABASE_URL` is set (deployed / configured
* sandbox), otherwise a local embedded **PGLite** (Postgres compiled to WASM) so
* the app has a working database even with nothing configured — the live preview
* included. Swap in Neon later by just setting `DATABASE_URL`; no code changes.
*/
var dbSource = databaseUrl ? "neon" : "pglite";
/**
* Init state lives on globalThis as promises: dev HMR creates new instances of
* this module, and two instances racing module-level state would open a second
* pool or run two concurrent PGLite migration passes (whose duplicate
* `_migrations` insert rejects — and would get memoized, poisoning every later
* `getSql()`). A failed init clears its slot so the next call retries.
*/
var globalRef = globalThis;
/**
* Result-type parity: Postgres sends every value as text plus a type OID — the
* JS value is the DRIVER's parsing choice, and pg and PGLite disagree (pg:
* int8 -> string, date -> local-midnight Date; PGLite: int8 -> BigInt, which
* JSON.stringify rejects, date -> UTC Date). Normalize both so preview and
* production return identical, JSON-safe shapes:
*   int8/bigint (incl. count(*)) -> number (past 2^53 loses precision — cast
*                                   `::text` if you ever need huge integers)
*   date                         -> 'YYYY-MM-DD' string
*   interval                     -> Postgres interval text
* numeric already comes back as a string on both (arbitrary precision).
*/
var OID_INT8 = 20;
var OID_DATE = 1082;
var OID_INTERVAL = 1186;
var identity = (v) => v;
/** Wrap a query runner in the tagged-template + `.query()` `Sql` surface. */
function toSql(run) {
	const sql = (async (strings, ...values) => {
		let text = strings[0];
		for (let i = 0; i < values.length; i += 1) text += `$${i + 1}${strings[i + 1]}`;
		return run(text, values);
	});
	sql.query = (text, params = []) => run(text, params);
	return sql;
}
function createNeonSql() {
	globalRef.__pgSqlPromise__ ??= (async () => {
		const { Pool, types } = await import("../_libs/pg.mjs").then((n) => n.t);
		types.setTypeParser(OID_INT8, Number);
		types.setTypeParser(OID_DATE, identity);
		types.setTypeParser(OID_INTERVAL, identity);
		const pool = new Pool({ connectionString: databaseUrl });
		return toSql(async (text, params) => {
			return (await pool.query(text, params)).rows;
		});
	})().catch((err) => {
		globalRef.__pgSqlPromise__ = void 0;
		throw err;
	});
	return globalRef.__pgSqlPromise__;
}
async function createPgliteSql() {
	globalRef.__pgliteInstance__ ??= (async () => {
		const { PGlite } = await import("../_libs/electric-sql__pglite.mjs").then((n) => n.t);
		const pg = new PGlite({ parsers: {
			[OID_INT8]: Number,
			[OID_DATE]: identity,
			[OID_INTERVAL]: identity
		} });
		await pg.waitReady;
		await pg.exec("create table if not exists _migrations (name text primary key, applied_at timestamptz not null default now())");
		return pg;
	})().catch((err) => {
		globalRef.__pgliteInstance__ = void 0;
		throw err;
	});
	const pg = await globalRef.__pgliteInstance__;
	const migrate = async () => {
		const migrations = /* #__PURE__ */ Object.assign({
			"/migrations/0002_files.sql": _0002_files_default,
			"/migrations/0003_file_chunks.sql": _0003_file_chunks_default
		});
		const done = (await pg.query("select name from _migrations")).rows.map((r) => r.name);
		for (const { name, path } of pendingMigrations(Object.keys(migrations), done)) await pg.transaction(async (tx) => {
			await tx.exec(migrations[path]);
			await tx.query("insert into _migrations (name) values ($1)", [name]);
		});
	};
	const pass = (globalRef.__pgliteMigrateChain__ ?? Promise.resolve()).catch(() => void 0).then(migrate);
	globalRef.__pgliteMigrateChain__ = pass;
	await pass;
	return toSql(async (text, params) => {
		return (await pg.query(text, params)).rows;
	});
}
var sqlPromise = null;
async function createSql() {
	if (typeof window !== "undefined") throw new Error("@/lib/db is server-only — call getSql() from a createServerFn handler or a server route loader, never from client code.");
	return dbSource === "neon" ? createNeonSql() : createPgliteSql();
}
/**
* Get the shared, **server-only** SQL client. Neon when `DATABASE_URL` is set,
* otherwise the local PGLite fallback. Memoized — safe to call per request.
*
* Schema comes from `migrations/*.sql`, auto-applied before the first query on
* both backends — define tables there, never inline in server functions.
*/
function getSql() {
	sqlPromise ??= createSql().catch((err) => {
		sqlPromise = null;
		throw err;
	});
	return sqlPromise;
}
/**
* Finish DB bootstrap before the server handles traffic.
*
* - **PGLite** (preview / no `DATABASE_URL`): open the in-memory DB and apply
*   `migrations/*.sql`. Idempotent — concurrent callers share one promise.
* - **Neon**: no-op (pool is created lazily on first query).
*
* Vite `configureServer` awaits this at dev startup; production imports of this
* module kick it off immediately (see bottom of file).
*/
function ensureDbReady() {
	if (dbSource !== "pglite") return Promise.resolve();
	return getSql().then(() => void 0);
}
var globalBoot = globalThis;
if (typeof window === "undefined" && dbSource === "pglite") globalBoot.__pgBootstrapPromise__ ??= ensureDbReady().catch((err) => {
	globalBoot.__pgBootstrapPromise__ = void 0;
	console.error("[db] PGLite bootstrap failed:", err);
	throw err;
});
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function formatBytes(bytes) {
	if (!Number.isFinite(bytes) || bytes < 0) return "0 B";
	if (bytes < 1024) return `${bytes} B`;
	if (bytes < 1048576) return `${(bytes / 1024).toFixed(1)} KB`;
	return `${(bytes / 1048576).toFixed(1)} MB`;
}
function sanitizeFileName(name) {
	return (name.replace(/\\/g, "/").split("/").pop() ?? "berkas").replace(/[\u0000-\u001f\u007f]/g, "").slice(0, 180) || "berkas";
}
function fileExtension(name) {
	const clean = sanitizeFileName(name);
	const i = clean.lastIndexOf(".");
	if (i <= 0) return "";
	return clean.slice(i + 1).toLowerCase();
}
async function copyText(text) {
	try {
		await navigator.clipboard.writeText(text);
		return true;
	} catch {
		try {
			const el = document.createElement("textarea");
			el.value = text;
			el.setAttribute("readonly", "");
			el.style.position = "fixed";
			el.style.left = "-9999px";
			document.body.appendChild(el);
			el.select();
			const ok = document.execCommand("copy");
			document.body.removeChild(el);
			return ok;
		} catch {
			return false;
		}
	}
}
function humanizeServerError(err, fallback) {
	let raw = "";
	if (err instanceof Error) raw = err.message;
	else if (typeof err === "string") raw = err;
	const trimmed = raw.trim();
	if (!trimmed) return fallback;
	if (trimmed.startsWith("{")) try {
		const parsed = JSON.parse(trimmed);
		const nested = parsed.errorMessage || parsed.message || parsed.error || "";
		if (nested && !/unknown error/i.test(nested)) return nested;
		return fallback;
	} catch {}
	if (/unknown error/i.test(trimmed) || trimmed.includes("errorType")) return fallback;
	return trimmed;
}
function toIso(value) {
	if (value == null) return null;
	if (value instanceof Date) return value.toISOString();
	const d = new Date(value);
	return Number.isNaN(d.getTime()) ? String(value) : d.toISOString();
}
function mapFile(row) {
	return {
		id: row.id,
		originalName: row.original_name,
		mimeType: row.mime_type,
		sizeBytes: Number(row.size_bytes),
		kind: row.kind,
		downloadCount: Number(row.download_count),
		expiresAt: toIso(row.expires_at),
		createdAt: toIso(row.created_at) ?? (/* @__PURE__ */ new Date()).toISOString(),
		reported: Boolean(row.reported)
	};
}
var META_COLS = `id, original_name, stored_name, mime_type, size_bytes, kind, download_count, expires_at, created_at, reported`;
function newFileId() {
	return randomBytes(10).toString("base64url");
}
function inferKind(name, mime) {
	const ext = fileExtension(name);
	if (IMAGE_EXT.has(ext) || IMAGE_MIME.has(mime)) return "image";
	if (VIDEO_EXT.has(ext) || VIDEO_MIME.has(mime)) return "video";
	return "file";
}
function inferMime(name, mime) {
	const ext = fileExtension(name);
	if (ext === "apk") return APK_MIME;
	if (mime && mime !== "application/octet-stream") return mime;
	return {
		jpg: "image/jpeg",
		jpeg: "image/jpeg",
		png: "image/png",
		gif: "image/gif",
		webp: "image/webp",
		mp4: "video/mp4",
		webm: "video/webm",
		mov: "video/quicktime",
		pdf: "application/pdf",
		zip: "application/zip",
		apk: "application/vnd.android.package-archive"
	}[ext] ?? "application/octet-stream";
}
function maxBytesForMode(mode) {
	return mode === "media" ? MAX_MEDIA_BYTES : MAX_FILE_BYTES;
}
function validateUpload(opts) {
	const name = sanitizeFileName(opts.name);
	const ext = fileExtension(name);
	if (BLOCKED_EXTENSIONS.has(ext)) return {
		ok: false,
		error: "Ekstensi berkas ini tidak diizinkan."
	};
	if (opts.size <= 0) return {
		ok: false,
		error: "Berkas kosong."
	};
	const cap = maxBytesForMode(opts.mode);
	if (opts.size > cap) return {
		ok: false,
		error: `Berkas terlalu besar. Maksimal ${Math.round(cap / 1048576)} MB.`
	};
	const mime = inferMime(name, opts.mime);
	const kind = inferKind(name, mime);
	if (opts.mode === "media" && kind === "file") return {
		ok: false,
		error: "Hanya gambar (JPG, PNG, GIF, WEBP) dan video (MP4, WEBM, MOV)."
	};
	return {
		ok: true,
		kind,
		mime,
		name
	};
}
function toBytes(data) {
	if (data instanceof Uint8Array) return data;
	if (typeof Buffer !== "undefined" && Buffer.isBuffer(data)) return new Uint8Array(data);
	if (typeof data === "string") {
		if (data.startsWith("\\x")) {
			const hex = data.slice(2);
			const out = new Uint8Array(hex.length / 2);
			for (let i = 0; i < out.length; i += 1) out[i] = Number.parseInt(hex.slice(i * 2, i * 2 + 2), 16);
			return out;
		}
		return Uint8Array.from(atob(data), (c) => c.charCodeAt(0));
	}
	if (data && typeof data === "object" && "data" in data) {
		const arr = data.data;
		return Uint8Array.from(arr);
	}
	throw new Error("Tidak bisa membaca data berkas.");
}
async function purgeExpired() {
	const sql = await getSql();
	await sql.query(`delete from file_chunks where file_id in (
      select id from files where (expires_at is not null and expires_at < now())
      or (status = 'pending' and created_at < now() - interval '1 hour')
    )`);
	await sql.query("delete from files where expires_at is not null and expires_at < now()");
	await sql.query("delete from files where status = 'pending' and created_at < now() - interval '1 hour'");
}
async function createPendingFile(opts) {
	const sql = await getSql();
	const id = newFileId();
	const ext = fileExtension(opts.originalName);
	const stored = ext ? `${id}.${ext}` : id;
	const row = (await sql.query(`insert into files (id, original_name, stored_name, mime_type, size_bytes, kind, data, expires_at, status, chunk_count)
     values ($1,$2,$3,$4,$5,$6,null,$7,'pending',$8)
     returning ${META_COLS}`, [
		id,
		opts.originalName,
		stored,
		opts.mime,
		opts.size,
		opts.kind,
		opts.expiresAt,
		opts.chunkCount
	]))[0];
	if (!row) throw new Error("Gagal menyimpan berkas.");
	return mapFile(row);
}
async function putFileChunk(id, index, bytes) {
	const sql = await getSql();
	const row = (await sql.query("select id, chunk_count, status from files where id = $1", [id]))[0];
	if (!row || row.status !== "pending") throw new Error("Sesi unggahan tidak valid. Unggah ulang.");
	if (index < 0 || index >= Number(row.chunk_count)) throw new Error("Potongan unggahan tidak valid.");
	await sql.query(`insert into file_chunks (file_id, chunk_index, data) values ($1,$2,$3)
     on conflict (file_id, chunk_index) do update set data = excluded.data`, [
		id,
		index,
		bytes
	]);
}
async function finalizeFile(id) {
	const sql = await getSql();
	const row = (await sql.query(`select ${META_COLS}, chunk_count, status from files where id = $1`, [id]))[0];
	if (!row || row.status !== "pending") throw new Error("Sesi unggahan tidak valid. Unggah ulang.");
	const stats = await sql.query(`select count(*)::int as n, coalesce(sum(octet_length(data)), 0)::bigint as bytes
     from file_chunks where file_id = $1`, [id]);
	const n = Number(stats[0]?.n ?? 0);
	const bytes = Number(stats[0]?.bytes ?? 0);
	if (n !== Number(row.chunk_count)) throw new Error("Unggahan belum lengkap. Coba lagi.");
	const ready = (await sql.query(`update files set status = 'ready', size_bytes = $2 where id = $1 returning ${META_COLS}`, [id, bytes]))[0];
	if (!ready) throw new Error("Gagal menyelesaikan unggahan.");
	return mapFile(ready);
}
async function insertFile(opts) {
	const sql = await getSql();
	const id = newFileId();
	const ext = fileExtension(opts.originalName);
	const stored = ext ? `${id}.${ext}` : id;
	const row = (await sql.query(`insert into files (id, original_name, stored_name, mime_type, size_bytes, kind, data, expires_at, status, chunk_count)
     values ($1,$2,$3,$4,$5,$6,$7,$8,'ready',0)
     returning ${META_COLS}`, [
		id,
		opts.originalName,
		stored,
		opts.mime,
		opts.bytes.byteLength,
		opts.kind,
		opts.bytes,
		opts.expiresAt
	]))[0];
	if (!row) throw new Error("Gagal menyimpan berkas.");
	return mapFile(row);
}
async function getFileMeta(id) {
	const sql = await getSql();
	const row = (await sql.query(`select ${META_COLS} from files where id = $1 and status = 'ready'`, [id]))[0];
	if (!row) return null;
	if (row.expires_at && new Date(row.expires_at).getTime() < Date.now()) {
		await sql.query("delete from file_chunks where file_id = $1", [id]);
		await sql.query("delete from files where id = $1", [id]);
		return null;
	}
	return mapFile(row);
}
async function streamFileData(id) {
	const sql = await getSql();
	const row = (await sql.query(`select ${META_COLS}, stored_name from files where id = $1 and status = 'ready'`, [id]))[0];
	if (!row) return null;
	if (row.expires_at && new Date(row.expires_at).getTime() < Date.now()) {
		await sql.query("delete from file_chunks where file_id = $1", [id]);
		await sql.query("delete from files where id = $1", [id]);
		return null;
	}
	const meta = mapFile(row);
	const countRows = await sql.query("select count(*)::int as n from file_chunks where file_id = $1", [id]);
	const chunkTotal = Number(countRows[0]?.n ?? 0);
	return {
		meta,
		body: new ReadableStream({ async start(controller) {
			try {
				if (chunkTotal > 0) for (let i = 0; i < chunkTotal; i += 1) {
					const part = await sql.query("select data from file_chunks where file_id = $1 and chunk_index = $2", [id, i]);
					if (!part[0]) throw new Error("Potongan berkas hilang.");
					controller.enqueue(toBytes(part[0].data));
				}
				else {
					const blob = await sql.query("select data from files where id = $1", [id]);
					if (!blob[0]?.data) throw new Error("Data berkas kosong.");
					controller.enqueue(toBytes(blob[0].data));
				}
				controller.close();
			} catch (err) {
				controller.error(err);
			}
		} }),
		storedName: row.stored_name
	};
}
async function bumpDownload(id) {
	await (await getSql()).query("update files set download_count = download_count + 1 where id = $1", [id]);
}
async function reportFile(id, reason) {
	const sql = await getSql();
	if (!(await sql.query("select id from files where id = $1", [id]))[0]) return false;
	await sql.query("insert into reports (file_id, reason) values ($1, $2)", [id, reason]);
	await sql.query("update files set reported = true where id = $1", [id]);
	return true;
}
async function listFiles(opts) {
	const sql = await getSql();
	await purgeExpired();
	const params = [];
	const where = ["status = 'ready'"];
	if (opts.q?.trim()) {
		params.push(`%${opts.q.trim()}%`);
		params.push(opts.q.trim());
		where.push(`(original_name ilike $${params.length - 1} or id = $${params.length})`);
	}
	if (opts.reportedOnly) where.push("reported = true");
	const clause = `where ${where.join(" and ")}`;
	const countRows = await sql.query(`select count(*)::int as n from files ${clause}`, params);
	const total = Number(countRows[0]?.n ?? 0);
	params.push(opts.limit, opts.offset);
	return {
		items: (await sql.query(`select ${META_COLS} from files ${clause} order by created_at desc limit $${params.length - 1} offset $${params.length}`, params)).map(mapFile),
		total
	};
}
async function deleteFile(id) {
	const sql = await getSql();
	await sql.query("delete from reports where file_id = $1", [id]);
	await sql.query("delete from file_chunks where file_id = $1", [id]);
	const rows = await sql.query("delete from files where id = $1 returning id", [id]);
	return Boolean(rows[0]);
}
function contentDisposition(filename, mode) {
	const safe = filename.replace(/["\\]/g, "_") || "berkas";
	return `${mode}; filename="${safe}"; filename*=UTF-8''${encodeURIComponent(safe)}`;
}
function shouldInline(kind, ext) {
	return (kind === "image" || kind === "video") && INLINE_EXT.has(ext);
}
var g = globalThis;
function store() {
	g.__kitaRate ??= /* @__PURE__ */ new Map();
	return g.__kitaRate;
}
function clientIp(request) {
	const fwd = request.headers.get("x-forwarded-for");
	if (fwd) return fwd.split(",")[0]?.trim() || "unknown";
	return request.headers.get("x-real-ip") ?? "unknown";
}
function rateLimit(key, limit, windowMs) {
	const now = Date.now();
	const buckets = store();
	const bucket = buckets.get(key) ?? { times: [] };
	bucket.times = bucket.times.filter((t) => now - t < windowMs);
	if (bucket.times.length >= limit) {
		const oldest = bucket.times[0] ?? now;
		const retryAfterSec = Math.max(1, Math.ceil((oldest + windowMs - now) / 1e3));
		buckets.set(key, bucket);
		return {
			ok: false,
			retryAfterSec
		};
	}
	bucket.times.push(now);
	buckets.set(key, bucket);
	return { ok: true };
}
var TIKTOK_RE = /^(https?:\/\/)?((www|vm|vt|m)\.)?tiktok\.com\/.+/i;
var UA = "Mozilla/5.0 (iPhone; CPU iPhone OS 17_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Mobile/15E148 Safari/604.1";
function isTikTokUrl(raw) {
	try {
		const host = new URL(raw.trim()).hostname.replace(/^www\./, "");
		return host === "tiktok.com" || host.endsWith(".tiktok.com") || host === "vm.tiktok.com" || host === "vt.tiktok.com";
	} catch {
		return TIKTOK_RE.test(raw.trim());
	}
}
function normalizeUrl(raw) {
	const t = raw.trim();
	if (!/^https?:\/\//i.test(t)) return `https://${t}`;
	return t;
}
function absUrl(value) {
	if (!value) return "";
	if (value.startsWith("//")) return `https:${value}`;
	if (value.startsWith("http")) return value;
	return `https://www.tikwm.com${value.startsWith("/") ? "" : "/"}${value}`;
}
function pickPlay(video) {
	if (!video) return "";
	for (const key of [
		"playAddr",
		"downloadAddr",
		"play_addr",
		"download_addr"
	]) {
		const val = video[key];
		if (typeof val === "string" && val) return val;
		if (val && typeof val === "object") {
			const rec = val;
			const list = rec.url_list || rec.urlList;
			if (Array.isArray(list) && list[0]) return String(list[0]);
		}
	}
	return "";
}
function mapTikwm(data, fallbackId) {
	const images = Array.isArray(data.images) ? data.images.filter(Boolean).map((url, index) => ({
		url: absUrl(url),
		index
	})) : [];
	const play = data.play ? absUrl(data.play) : "";
	const hd = data.hdplay ? absUrl(data.hdplay) : "";
	return {
		id: String(data.id ?? fallbackId),
		title: (data.title || "Video TikTok").trim(),
		author: data.author?.nickname || data.author?.unique_id || "Tidak diketahui",
		authorId: data.author?.unique_id || data.author?.id || "",
		cover: absUrl(data.origin_cover || data.cover),
		duration: typeof data.duration === "number" ? data.duration : null,
		videoUrl: play || hd || null,
		videoHdUrl: hd || play || null,
		musicUrl: data.music ? absUrl(data.music) : null,
		images
	};
}
async function fetchJson(url, init, timeoutMs = 7e3) {
	const res = await fetch(url, {
		...init,
		headers: {
			accept: "application/json, text/plain, */*",
			"user-agent": UA,
			...init?.headers ?? {}
		},
		signal: AbortSignal.timeout(timeoutMs)
	});
	if (!res.ok) throw new Error(`HTTP ${res.status}`);
	const text = await res.text();
	try {
		return JSON.parse(text);
	} catch {
		throw new Error("Respons bukan JSON.");
	}
}
async function fromTikwm(url) {
	const json = await fetchJson(`https://www.tikwm.com/api/?url=${encodeURIComponent(url)}&hd=1`);
	if (json?.code === 0 && json.data) return mapTikwm(json.data, url);
	throw new Error(json?.msg || "tikwm gagal");
}
async function fromTikly(url) {
	const json = await fetchJson(`https://api.tiklydown.eu.org/api/download?url=${encodeURIComponent(url)}`);
	const videoUrl = json.video?.noWatermark || json.video?.watermark || null;
	const images = Array.isArray(json.images) ? json.images.filter(Boolean).map((u, index) => ({
		url: absUrl(u),
		index
	})) : [];
	if (!videoUrl && images.length === 0) throw new Error("API cadangan tidak mengembalikan media.");
	return {
		id: String(json.id ?? url),
		title: (json.title || "Video TikTok").trim(),
		author: json.author?.nickname || json.author?.username || "Tidak diketahui",
		authorId: json.author?.username || "",
		cover: absUrl(json.cover || json.thumbnail),
		duration: null,
		videoUrl,
		videoHdUrl: json.video?.noWatermark || videoUrl,
		musicUrl: json.music?.play_url || json.music?.url || null,
		images
	};
}
function parseTikTokHtml(html, pageUrl) {
	const uni = html.match(/<script id="__UNIVERSAL_DATA_FOR_REHYDRATION__"[^>]*>([^<]+)<\/script>/);
	let item = null;
	if (uni?.[1]) try {
		item = JSON.parse(uni[1]).__DEFAULT_SCOPE__?.["webapp.video-detail"]?.itemInfo?.itemStruct ?? null;
	} catch {
		item = null;
	}
	if (!item) {
		const sigi = html.match(/<script id="SIGI_STATE"[^>]*>([^<]+)<\/script>/);
		if (sigi?.[1]) try {
			const json = JSON.parse(sigi[1]);
			const first = json.ItemModule && Object.values(json.ItemModule)[0];
			if (first) item = first;
		} catch {
			item = null;
		}
	}
	if (!item) return null;
	const video = item.video;
	const author = item.author;
	const music = item.music;
	const imagePost = item.imagePost;
	const play = pickPlay(video);
	const images = (imagePost?.images ?? []).map((img, index) => ({
		url: img.imageURL?.urlList?.[0] ?? "",
		index
	})).filter((img) => img.url);
	if (!play && images.length === 0) return null;
	const coverObj = video?.cover;
	let cover = "";
	if (typeof coverObj === "string") cover = coverObj;
	else if (coverObj?.url_list?.[0]) cover = coverObj.url_list[0];
	else if (coverObj?.urlList?.[0]) cover = coverObj.urlList[0];
	let musicUrl = null;
	const mu = music?.playUrl;
	if (typeof mu === "string") musicUrl = mu;
	else if (mu && typeof mu === "object") {
		const rec = mu;
		if (rec.url_list?.[0]) musicUrl = rec.url_list[0];
	}
	const idMatch = pageUrl.match(/(\d{8,})/);
	return {
		id: String(item.id ?? idMatch?.[1] ?? pageUrl),
		title: String(item.desc || "Video TikTok").trim(),
		author: author?.nickname || author?.uniqueId || "Tidak diketahui",
		authorId: author?.uniqueId || "",
		cover,
		duration: typeof video?.duration === "number" ? video.duration : null,
		videoUrl: play || null,
		videoHdUrl: play || null,
		musicUrl,
		images
	};
}
async function fromOfficialPage(url) {
	const res = await fetch(url, {
		headers: {
			"user-agent": UA,
			accept: "text/html,application/xhtml+xml"
		},
		redirect: "follow",
		signal: AbortSignal.timeout(8e3)
	});
	if (!res.ok) throw new Error(`HTTP ${res.status}`);
	const parsed = parseTikTokHtml(await res.text(), res.url || url);
	if (!parsed) throw new Error("Halaman TikTok tidak berisi media publik.");
	return parsed;
}
async function resolveTikTok(raw) {
	const url = normalizeUrl(raw);
	if (!isTikTokUrl(url)) throw new Error("Tautan bukan URL TikTok yang valid.");
	const tasks = [
		() => fromTikwm(url),
		() => fromOfficialPage(url),
		() => fromTikly(url)
	];
	try {
		return await Promise.any(tasks.map((fn) => fn()));
	} catch {
		throw new Error("Tidak bisa mengambil video. Pastikan tautan publik (bukan akun privat), coba tautan lengkap tiktok.com/@akun/video/…, lalu ulangi.");
	}
}
function safeRemoteUrl(url) {
	try {
		const u = new URL(url);
		return u.protocol === "https:" || u.protocol === "http:";
	} catch {
		return false;
	}
}
//#endregion
export { putFileChunk as A, getFileMeta as C, listFiles as D, isTikTokUrl as E, shouldInline as F, streamFileData as I, validateUpload as L, reportFile as M, resolveTikTok as N, maxBytesForMode as O, safeRemoteUrl as P, formatMbLimit as S, insertFile as T, createPendingFile as _, EXPIRY_OPTIONS as a, finalizeFile as b, RATE as c, UPLOAD_CHUNK_BYTES as d, bumpDownload as f, copyText as g, contentDisposition as h, APP_TAGLINE as i, rateLimit as j, purgeExpired as k, REPORT_REASONS as l, cn as m, ADMIN_PASSWORD_DEFAULT as n, MAX_FILE_BYTES as o, clientIp as p, APP_NAME as r, MAX_MEDIA_BYTES as s, ADMIN_COOKIE as t, TOOLS as u, deleteFile as v, humanizeServerError as w, formatBytes as x, fileExtension as y };
