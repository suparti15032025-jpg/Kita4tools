import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { a as SiteShell } from "./router-CJOUtL5o.mjs";
import { t as PageHeader } from "./page-header-DaUDOWJs.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/syarat-BfL0V2gA.js
var import_jsx_runtime = require_jsx_runtime();
function SyaratPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "mx-auto max-w-2xl space-y-8 px-4 py-10 sm:px-6 sm:py-16",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			title: "Syarat penggunaan",
			description: "Ringkas, tanpa bahasa hukum yang berputar-putar."
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-4 text-sm leading-relaxed text-muted",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Kita menyediakan alat gratis: pembuat QR, tautan media, unduhan TikTok, dan unggah berkas publik. Dengan memakai situs ini, Anda setuju untuk tidak mengunggah malware, data pribadi orang lain, atau materi yang melanggar hukum Indonesia." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Tautan berkas bersifat publik. Siapa pun yang memegang tautan dapat mengunduh isinya. Jangan unggah dokumen rahasia." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Unduhan TikTok hanya untuk keperluan pribadi. Hak cipta tetap milik kreator. Kita tidak menyimpan salinan video di server." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Berkas dapat kedaluwarsa sesuai masa aktif yang Anda pilih, atau dihapus jika dilaporkan. Layanan disediakan apa adanya, tanpa jaminan ketersediaan." })
			]
		})]
	}) });
}
//#endregion
export { SyaratPage as component };
