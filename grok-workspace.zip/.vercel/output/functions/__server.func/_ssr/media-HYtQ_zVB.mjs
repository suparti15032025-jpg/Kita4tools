import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { S as formatMbLimit, s as MAX_MEDIA_BYTES, w as humanizeServerError, x as formatBytes } from "./tiktok.server-BNVcQmyB.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { a as SiteShell } from "./router-CJOUtL5o.mjs";
import { t as CopyField } from "./copy-field-C9FQl0DI.mjs";
import { n as Progress, r as xhrUpload, t as DropZone } from "./upload-client-mc3pC6DQ.mjs";
import { t as PageHeader } from "./page-header-DaUDOWJs.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/media-HYtQ_zVB.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function MediaPage() {
	const [jobs, setJobs] = (0, import_react.useState)([]);
	const busy = jobs.some((j) => !j.result && !j.error);
	async function onFiles(files) {
		const slice = files.slice(0, 8);
		if (files.length > 8) toast.error(`Maksimal 8 berkas sekaligus.`);
		const incoming = slice.map((file) => ({
			id: `${file.name}-${file.size}-${file.lastModified}-${Math.random()}`,
			name: file.name,
			progress: 0,
			error: file.size > 31457280 ? `Berkas terlalu besar. Maksimal ${formatMbLimit(MAX_MEDIA_BYTES)}.` : void 0
		}));
		setJobs((prev) => [...incoming, ...prev]);
		await Promise.all(slice.map(async (file, i) => {
			const job = incoming[i];
			if (!job || job.error) return;
			try {
				const result = await xhrUpload(file, {
					mode: "media",
					expiry: "30d"
				}, (pct) => {
					setJobs((prev) => prev.map((j) => j.id === job.id ? {
						...j,
						progress: pct
					} : j));
				});
				setJobs((prev) => prev.map((j) => j.id === job.id ? {
					...j,
					progress: 100,
					result
				} : j));
			} catch (err) {
				const message = humanizeServerError(err, "Gagal mengunggah. Coba lagi.");
				setJobs((prev) => prev.map((j) => j.id === job.id ? {
					...j,
					error: message
				} : j));
			}
		}));
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-3xl space-y-10 px-4 py-10 sm:px-6 sm:py-16",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				kicker: "02 · Hosting",
				title: "Tautan media",
				description: "Unggah gambar atau video sampai 30 MB, lalu bagikan tautan langsung, halaman pratinjau, atau kode embed."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropZone, {
				accept: "image/jpeg,image/png,image/gif,image/webp,video/mp4,video/webm,video/quicktime,.jpg,.jpeg,.png,.gif,.webp,.mp4,.webm,.mov",
				multiple: true,
				disabled: busy,
				hint: `JPG, PNG, GIF, WEBP, MP4, WEBM, MOV · maks ${formatMbLimit(MAX_MEDIA_BYTES)}`,
				onFiles
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "space-y-4",
				children: jobs.map((job) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "panel rounded-2xl p-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start justify-between gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm font-medium",
								children: job.name
							}), job.result ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs text-muted",
								children: formatBytes(job.result.file.sizeBytes)
							}) : null]
						}),
						!job.result && !job.error ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 space-y-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Progress, { value: job.progress }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "font-mono text-xs text-muted tabular-nums",
								children: [job.progress, "%"]
							})]
						}) : null,
						job.error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-sm text-danger",
							children: job.error
						}) : null,
						job.result ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MediaResult, { result: job.result }) : null
					]
				}, job.id))
			})
		]
	}) });
}
function MediaResult({ result }) {
	const { file, directUrl, previewUrl } = result;
	const isVideo = file.kind === "video";
	const html = isVideo ? `<video src="${directUrl}" controls style="max-width:100%"></video>` : `<a href="${previewUrl}"><img src="${directUrl}" alt="${file.originalName}" /></a>`;
	const bb = isVideo ? `[video]${directUrl}[/video]` : `[img]${directUrl}[/img]`;
	const md = isVideo ? `[${file.originalName}](${directUrl})` : `![${file.originalName}](${directUrl})`;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-5 space-y-5",
		children: [
			isVideo ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("video", {
				src: directUrl,
				controls: true,
				className: "max-h-64 w-full rounded-lg bg-bg"
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: directUrl,
				alt: "",
				className: "max-h-64 rounded-lg object-contain"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyField, {
				label: "Halaman pratinjau",
				value: previewUrl
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyField, {
				label: "Tautan langsung",
				value: directUrl
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyField, {
				label: "HTML",
				value: html,
				multiline: true
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyField, {
				label: "BBCode",
				value: bb,
				multiline: true
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyField, {
				label: "Markdown",
				value: md,
				multiline: true
			})
		]
	});
}
//#endregion
export { MediaPage as component };
