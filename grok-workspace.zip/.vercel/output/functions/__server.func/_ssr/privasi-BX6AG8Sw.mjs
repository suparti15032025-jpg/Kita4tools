import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { a as SiteShell } from "./router-CJOUtL5o.mjs";
import { t as PageHeader } from "./page-header-DaUDOWJs.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/privasi-BX6AG8Sw.js
var import_jsx_runtime = require_jsx_runtime();
function PrivasiPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "mx-auto max-w-2xl space-y-8 px-4 py-10 sm:px-6 sm:py-16",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			title: "Privasi",
			description: "Kami menyimpan sesedikit mungkin."
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "space-y-4 text-sm leading-relaxed text-muted",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Tidak ada akun pengguna. QR dibuat sepenuhnya di peramban Anda. Tautan TikTok diproses di server lalu dibuang — kami tidak menyimpan video, audio, atau riwayat unduhan." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Berkas yang Anda unggah disimpan beserta nama, ukuran, tipe, dan waktu kedaluwarsa. Alamat IP dipakai hanya untuk membatasi penyalahgunaan (rate limit), tidak ditautkan ke identitas." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Laporan berkas mencatat alasan yang Anda pilih, bukan nama atau email. Panel admin hanya melihat metadata dan dapat menghapus berkas yang dilaporkan." }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Cookie dipakai untuk tema tampilan dan sesi admin, bukan untuk iklan." })
			]
		})]
	}) });
}
//#endregion
export { PrivasiPage as component };
