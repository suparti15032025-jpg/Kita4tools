import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { r as APP_NAME, u as TOOLS } from "./tiktok.server-BNVcQmyB.mjs";
import { g as Clapperboard, o as QrCode, p as FileUp, u as Images, x as ArrowDown, y as ArrowUpRight } from "../_libs/lucide-react.mjs";
import { a as SiteShell, o as Button } from "./router-CJOUtL5o.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-C5Pq_lW2.js
var import_jsx_runtime = require_jsx_runtime();
var ICONS = {
	qr: QrCode,
	media: Images,
	tiktok: Clapperboard,
	upload: FileUp
};
var NOTES = [
	{
		k: "01",
		t: "Tanpa akun",
		d: "Buka, pakai, selesai. Tidak ada daftar atau profil."
	},
	{
		k: "02",
		t: "QR di peramban",
		d: "Kode dibuat di perangkat Anda. Tidak pernah naik ke server."
	},
	{
		k: "03",
		t: "Berkas punya umur",
		d: "Pilih masa aktif. Yang kedaluwarsa dihapus sendiri."
	}
];
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SiteShell, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "hero-wash relative overflow-hidden",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto max-w-6xl px-4 pt-14 pb-12 sm:px-6 sm:pt-24 sm:pb-16",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "hero-copy kicker",
						children: [APP_NAME, " · empat alat · tanpa akun"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
						className: "hero-copy mt-6 max-w-5xl font-display text-display leading-display font-semibold tracking-tight",
						children: [
							"Semua yang perlu,",
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "font-sans font-normal italic",
								children: "tanpa"
							}),
							" yang tidak."
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "hero-copy mt-6 max-w-xl text-base leading-relaxed text-muted sm:text-lg",
						children: "QR, tautan media, unduhan TikTok, dan berkas publik. Langsung dipakai di peramban — rapi di ponsel, tenang di layar besar."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "hero-copy mt-8 flex flex-wrap items-center gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							asChild: true,
							size: "lg",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
								href: "#alat",
								children: ["Lihat alat", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowDown, {})]
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							asChild: true,
							size: "lg",
							variant: "secondary",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/qr",
								children: ["Buat QR sekarang", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, {})]
							})
						})]
					})
				]
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
			className: "border-y border-border",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mx-auto grid max-w-6xl gap-px bg-border sm:grid-cols-3",
				children: NOTES.map((note) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "bg-bg px-4 py-6 sm:px-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-mono text-xs tracking-widest text-muted",
							children: note.k
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 font-display text-lg font-semibold tracking-tight",
							children: note.t
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1.5 text-sm leading-relaxed text-muted",
							children: note.d
						})
					]
				}, note.k))
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			id: "alat",
			className: "mx-auto max-w-6xl scroll-mt-20 px-4 py-14 sm:px-6 sm:py-20",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mb-8 flex items-end justify-between gap-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "kicker",
					children: "Katalog"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "mt-3 font-display text-title font-semibold tracking-tight",
					children: "Empat alat."
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "hidden max-w-xs text-right text-sm text-muted sm:block",
					children: "Satu kartu, satu pekerjaan. Tidak ada yang tersembunyi di balik menu."
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "grid gap-3 sm:grid-cols-2",
				children: TOOLS.map((tool) => {
					const Icon = ICONS[tool.slug];
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
						className: "tool-card",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: tool.href,
							className: "group relative flex h-full min-h-56 flex-col overflow-hidden rounded-2xl p-6 tool-tile",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									"aria-hidden": true,
									className: "tool-index",
									children: tool.index
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "relative flex items-start justify-between gap-4",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "flex size-12 items-center justify-center rounded-md bg-secondary",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-5" })
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "font-mono text-xs tracking-widest text-muted",
										children: tool.index
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
									className: "relative mt-auto pt-10 font-display text-2xl font-semibold tracking-tight",
									children: tool.title
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "relative mt-2 max-w-sm text-sm leading-relaxed text-muted",
									children: tool.blurb
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "relative mt-5 inline-flex items-center gap-1.5 text-sm font-medium",
									children: ["Buka", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowUpRight, { className: "size-4 transition-transform duration-(--motion-fast) ease-(--ease-smooth-out) group-hover:translate-x-0.5 group-hover:-translate-y-0.5" })]
								})
							]
						})
					}, tool.slug);
				})
			})]
		})
	] });
}
//#endregion
export { Home as component };
