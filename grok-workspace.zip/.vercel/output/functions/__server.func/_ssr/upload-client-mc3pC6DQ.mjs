import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { d as UPLOAD_CHUNK_BYTES, m as cn } from "./tiktok.server-BNVcQmyB.mjs";
import { n as Upload } from "../_libs/lucide-react.mjs";
import { n as Root, t as Indicator } from "../_libs/radix-ui__react-progress.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/upload-client-mc3pC6DQ.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function DropZone({ accept, multiple, disabled, hint, onFiles }) {
	const inputRef = (0, import_react.useRef)(null);
	const [over, setOver] = (0, import_react.useState)(false);
	function take(list) {
		if (!list) return;
		const files = Array.from(list);
		if (files.length) onFiles(files);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		disabled,
		onClick: () => inputRef.current?.click(),
		onDragEnter: (e) => {
			e.preventDefault();
			setOver(true);
		},
		onDragOver: (e) => {
			e.preventDefault();
			setOver(true);
		},
		onDragLeave: () => setOver(false),
		onDrop: (e) => {
			e.preventDefault();
			setOver(false);
			take(e.dataTransfer.files);
		},
		className: cn("flex min-h-52 w-full flex-col items-center justify-center gap-4 rounded-2xl border border-dashed px-6 py-12 text-center transition-[border-color,background-color] duration-(--motion-fast) ease-(--ease-smooth-out)", over ? "border-fg bg-accent-soft" : "border-border-strong bg-surface", disabled && "opacity-60"),
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "flex size-12 items-center justify-center rounded-md bg-secondary",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, { className: "size-5" })
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-1.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-medium",
					children: "Letakkan berkas di sini, atau ketuk untuk memilih"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted",
					children: hint
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
				ref: inputRef,
				type: "file",
				className: "sr-only",
				accept,
				multiple,
				disabled,
				onChange: (e) => {
					take(e.target.files);
					e.currentTarget.value = "";
				}
			})
		]
	});
}
var Progress = import_react.forwardRef(({ className, value, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Root, {
	ref,
	className: cn("relative h-2 w-full overflow-hidden rounded-full bg-secondary", className),
	...props,
	children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Indicator, {
		className: "h-full w-full flex-1 bg-primary transition-transform duration-(--motion-fast) ease-(--ease-smooth-out)",
		style: { transform: `translateX(-${100 - (value ?? 0)}%)` }
	})
}));
Progress.displayName = Root.displayName;
function sendForm(fields, file, onProgress) {
	return new Promise((resolve, reject) => {
		const xhr = new XMLHttpRequest();
		xhr.open("POST", "/api/upload");
		xhr.responseType = "json";
		xhr.upload.onprogress = (event) => {
			if (onProgress && event.lengthComputable) onProgress(event.loaded, event.total);
		};
		xhr.onload = () => {
			const body = xhr.response ?? {};
			if (typeof xhr.response === "string") try {
				Object.assign(body, JSON.parse(xhr.response));
			} catch {}
			if (xhr.status >= 200 && xhr.status < 300) {
				resolve(body);
				return;
			}
			reject(new Error(body.error || `Unggah gagal (${xhr.status}).`));
		};
		xhr.onerror = () => reject(/* @__PURE__ */ new Error("Koneksi terputus saat mengunggah."));
		xhr.onabort = () => reject(/* @__PURE__ */ new Error("Unggah dibatalkan."));
		const fd = new FormData();
		for (const [key, value] of Object.entries(fields)) fd.append(key, value);
		if (file) fd.append(file.field, file.blob, file.name);
		xhr.send(fd);
	});
}
async function sendFormRetry(fields, file, onProgress) {
	let last = null;
	for (let attempt = 0; attempt < 3; attempt += 1) try {
		return await sendForm(fields, file, onProgress);
	} catch (err) {
		last = err instanceof Error ? err : /* @__PURE__ */ new Error("Unggah gagal.");
		if (/tidak diizinkan|terlalu besar|tidak valid|kosong|hanya gambar/i.test(last.message) || attempt === 2) throw last;
		await new Promise((r) => setTimeout(r, 400 * (attempt + 1)));
	}
	throw last ?? /* @__PURE__ */ new Error("Unggah gagal.");
}
async function xhrUpload(file, fields, onProgress) {
	const chunkCount = Math.max(1, Math.ceil(file.size / UPLOAD_CHUNK_BYTES));
	const init = await sendFormRetry({
		step: "init",
		name: file.name,
		size: String(file.size),
		mime: file.type,
		chunkCount: String(chunkCount),
		...fields
	});
	const id = String(init.id || "");
	if (!id) throw new Error("Gagal memulai unggahan.");
	for (let i = 0; i < chunkCount; i += 1) {
		const start = i * UPLOAD_CHUNK_BYTES;
		const blob = file.slice(start, start + UPLOAD_CHUNK_BYTES);
		await sendFormRetry({
			step: "chunk",
			id,
			index: String(i)
		}, {
			field: "chunk",
			blob,
			name: `chunk-${i}`
		}, (loaded, total) => {
			const done = start + loaded;
			onProgress(Math.max(0, Math.min(99, Math.round(done / Math.max(file.size, total) * 100))));
		});
	}
	const done = await sendFormRetry({
		step: "complete",
		id
	});
	onProgress(100);
	if (!done.file) throw new Error("Gagal menyelesaikan unggahan.");
	return done;
}
//#endregion
export { Progress as n, xhrUpload as r, DropZone as t };
