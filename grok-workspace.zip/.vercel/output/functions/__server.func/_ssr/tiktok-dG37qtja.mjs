import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { w as humanizeServerError } from "./tiktok.server-BNVcQmyB.mjs";
import { m as Download, s as Music2 } from "../_libs/lucide-react.mjs";
import { a as SiteShell, o as Button, u as inspectTikTok } from "./router-CJOUtL5o.mjs";
import { t as Input } from "./input-CPYv1eDm.mjs";
import { t as Label } from "./label-DCeeSPw0.mjs";
import { t as PageHeader } from "./page-header-DaUDOWJs.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/tiktok-dG37qtja.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function proxyUrl(url, filename) {
	return `/api/tiktok-file?${new URLSearchParams({
		url,
		filename
	}).toString()}`;
}
function TikTokPage() {
	const [url, setUrl] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [info, setInfo] = (0, import_react.useState)(null);
	const [error, setError] = (0, import_react.useState)(null);
	async function run(e) {
		e.preventDefault();
		setBusy(true);
		setInfo(null);
		setError(null);
		try {
			const data = await inspectTikTok({ data: { url } });
			setInfo(data);
		} catch (err) {
			setError(humanizeServerError(err, "Tidak bisa mengambil video. Pastikan tautan publik, coba tautan lengkap tiktok.com/@akun/video/…, lalu ulangi."));
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-3xl space-y-10 px-4 py-10 sm:px-6 sm:py-16",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				kicker: "03 · Unduhan",
				title: "Unduh TikTok",
				description: "Tempel tautan video atau vm.tiktok.com. Kami mengambil metadata di server, lalu menyiapkan unduhan video, audio, atau foto."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				onSubmit: run,
				className: "space-y-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					htmlFor: "tt-url",
					children: "Tautan TikTok"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col gap-2 sm:flex-row",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						id: "tt-url",
						value: url,
						onChange: (e) => setUrl(e.target.value),
						placeholder: "https://www.tiktok.com/@akun/video/…",
						required: true
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						disabled: busy,
						className: "sm:w-40",
						children: busy ? "Memeriksa…" : "Ambil"
					})]
				})]
			}),
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "rounded-xl border border-border bg-surface px-4 py-3 text-sm text-danger",
				children: error
			}) : null,
			info ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "panel overflow-hidden rounded-2xl",
				children: [info.cover ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
					src: info.cover,
					alt: "",
					className: "aspect-video w-full object-cover bg-bg"
				}) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-4 p-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "text-xs text-muted",
								children: ["@", info.authorId || info.author]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mt-1 font-display text-2xl font-semibold tracking-tight",
								children: info.title
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm text-muted",
								children: info.author
							})
						] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex flex-col gap-2 sm:flex-row sm:flex-wrap",
							children: [info.videoHdUrl || info.videoUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								asChild: true,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
									href: proxyUrl(info.videoHdUrl || info.videoUrl || "", `${info.id}.mp4`),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {}), "Video tanpa watermark"]
								})
							}) : null, info.musicUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								asChild: true,
								variant: "secondary",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
									href: proxyUrl(info.musicUrl, `${info.id}.mp3`),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Music2, {}), "Audio MP3"]
								})
							}) : null]
						}),
						info.images.length > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm font-medium",
								children: "Foto slideshow"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
								className: "grid grid-cols-2 gap-2 sm:grid-cols-3",
								children: info.images.map((img) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									href: proxyUrl(img.url, `${info.id}-${img.index + 1}.jpg`),
									className: "block overflow-hidden rounded-md",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
										src: img.url,
										alt: "",
										className: "aspect-square w-full object-cover"
									})
								}) }, img.index))
							})]
						}) : null
					]
				})]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted",
				children: "Hormati hak cipta kreator. Unduhan hanya untuk keperluan pribadi. Kita tidak berafiliasi dengan TikTok dan tidak menyimpan video di server kami."
			})
		]
	}) });
}
//#endregion
export { TikTokPage as component };
