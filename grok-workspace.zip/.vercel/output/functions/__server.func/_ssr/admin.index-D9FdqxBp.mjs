import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { b as useRouter, y as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { x as formatBytes } from "./tiktok.server-BNVcQmyB.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { a as SiteShell, i as Route$7, l as adminLogout, o as Button, s as adminDeleteFile } from "./router-CJOUtL5o.mjs";
import { t as Input } from "./input-CPYv1eDm.mjs";
import { t as Switch } from "./switch-CjAvPzoN.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/admin.index-D9FdqxBp.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function AdminPage() {
	const data = Route$7.useLoaderData();
	const search = Route$7.useSearch();
	const navigate = useNavigate({ from: "/admin/" });
	const router = useRouter();
	const [q, setQ] = (0, import_react.useState)(search.q ?? "");
	const page = search.page ?? 1;
	const reported = search.reported ?? false;
	const totalPages = Math.max(1, Math.ceil(data.total / 20));
	async function remove(id) {
		if (!confirm("Hapus berkas ini?")) return;
		try {
			await adminDeleteFile({ data: { id } });
			toast.success("Berkas dihapus.");
			await router.invalidate();
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Gagal menghapus.");
		}
	}
	async function logout() {
		await adminLogout();
		await navigate({ to: "/admin/login" });
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-5xl space-y-8 px-4 py-10 sm:px-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "kicker",
						children: "Panel"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-2 font-display text-title font-semibold tracking-tight",
						children: "Berkas"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-1 text-sm text-muted tabular-nums",
						children: [data.total, " item"]
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					variant: "outline",
					onClick: logout,
					children: "Keluar"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
				className: "flex flex-col gap-3 sm:flex-row sm:items-center",
				onSubmit: (e) => {
					e.preventDefault();
					navigate({ search: {
						q: q || void 0,
						reported: reported || void 0,
						page: void 0
					} });
				},
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: q,
						onChange: (e) => setQ(e.target.value),
						placeholder: "Cari nama atau ID",
						className: "sm:max-w-sm"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "submit",
						variant: "secondary",
						children: "Cari"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "flex min-h-11 items-center gap-2 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
							checked: reported,
							onCheckedChange: (on) => {
								navigate({ search: {
									q: search.q,
									reported: on || void 0,
									page: void 0
								} });
							}
						}), "Hanya dilaporkan"]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "overflow-x-auto rounded-xl border border-border",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full min-w-[40rem] text-left text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
						className: "border-b border-border bg-secondary text-muted",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3 font-medium",
								children: "Nama"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3 font-medium",
								children: "Ukuran"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3 font-medium",
								children: "Unduh"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "px-4 py-3 font-medium",
								children: "Status"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { className: "px-4 py-3 font-medium" })
						] })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: data.items.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tr", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						colSpan: 5,
						className: "px-4 py-10 text-center text-muted",
						children: "Belum ada berkas."
					}) }) : data.items.map((file) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
						className: "border-b border-border last:border-0",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
								className: "px-4 py-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									href: file.kind === "file" ? `/f/${file.id}` : `/v/${file.id}`,
									className: "font-medium hover:underline",
									children: file.originalName
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "font-mono text-[11px] text-muted",
									children: file.id
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-3 tabular-nums",
								children: formatBytes(file.sizeBytes)
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-3 tabular-nums",
								children: file.downloadCount
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-3",
								children: file.reported ? "Dilaporkan" : "Normal"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
								className: "px-4 py-3 text-right",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									type: "button",
									variant: "ghost",
									size: "sm",
									onClick: () => void remove(file.id),
									children: "Hapus"
								})
							})
						]
					}, file.id)) })]
				})
			}),
			totalPages > 1 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between text-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "outline",
						size: "sm",
						disabled: page <= 1,
						onClick: () => void navigate({ search: {
							...search,
							page: page - 1 > 1 ? page - 1 : void 0
						} }),
						children: "Sebelumnya"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "tabular-nums text-muted",
						children: [
							page,
							" / ",
							totalPages
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "outline",
						size: "sm",
						disabled: page >= totalPages,
						onClick: () => void navigate({ search: {
							...search,
							page: page + 1
						} }),
						children: "Berikutnya"
					})
				]
			}) : null
		]
	}) });
}
//#endregion
export { AdminPage as component };
