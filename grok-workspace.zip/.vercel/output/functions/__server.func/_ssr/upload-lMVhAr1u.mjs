import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { S as formatMbLimit, a as EXPIRY_OPTIONS, o as MAX_FILE_BYTES, w as humanizeServerError, x as formatBytes } from "./tiktok.server-BNVcQmyB.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { a as SiteShell } from "./router-CJOUtL5o.mjs";
import { t as Label } from "./label-DCeeSPw0.mjs";
import { t as CopyField } from "./copy-field-C9FQl0DI.mjs";
import { n as Progress, r as xhrUpload, t as DropZone } from "./upload-client-mc3pC6DQ.mjs";
import { t as PageHeader } from "./page-header-DaUDOWJs.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/upload-lMVhAr1u.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function UploadPage() {
	const [expiry, setExpiry] = (0, import_react.useState)("7d");
	const [jobs, setJobs] = (0, import_react.useState)([]);
	const busy = jobs.some((j) => !j.result && !j.error);
	async function onFiles(files) {
		const slice = files.slice(0, 8);
		if (files.length > 8) toast.error(`Maksimal 8 berkas sekaligus.`);
		const incoming = slice.map((file) => ({
			id: `${file.name}-${file.size}-${file.lastModified}-${Math.random()}`,
			name: file.name,
			progress: 0,
			error: file.size > 157286400 ? `Berkas terlalu besar. Maksimal ${formatMbLimit(MAX_FILE_BYTES)}.` : void 0
		}));
		setJobs((prev) => [...incoming, ...prev]);
		await Promise.all(slice.map(async (file, i) => {
			const job = incoming[i];
			if (!job || job.error) return;
			try {
				const result = await xhrUpload(file, {
					mode: "file",
					expiry
				}, (pct) => {
					setJobs((prev) => prev.map((j) => j.id === job.id ? {
						...j,
						progress: pct
					} : j));
				});
				setJobs((prev) => prev.map((j) => j.id === job.id ? {
					...j,
					progress: 100,
					result
				} : j));
			} catch (err) {
				const message = humanizeServerError(err, "Gagal mengunggah. Coba lagi.");
				setJobs((prev) => prev.map((j) => j.id === job.id ? {
					...j,
					error: message
				} : j));
			}
		}));
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-3xl space-y-10 px-4 py-10 sm:px-6 sm:py-16",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				kicker: "04 · Penyimpanan",
				title: "Berkas publik",
				description: "Unggah APK, ZIP, PDF, atau berkas lain sampai 150 MB. Penerima membuka halaman unduh — berkas tidak langsung tersimpan."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					htmlFor: "expiry",
					children: "Masa aktif"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
					id: "expiry",
					className: "native-select",
					value: expiry,
					onChange: (e) => setExpiry(e.target.value),
					children: EXPIRY_OPTIONS.map((opt) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
						value: opt.id,
						children: opt.label
					}, opt.id))
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropZone, {
				multiple: true,
				disabled: busy,
				hint: `Semua jenis berkas kecuali skrip server · maks ${formatMbLimit(MAX_FILE_BYTES)}`,
				onFiles
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "space-y-4",
				children: jobs.map((job) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "panel rounded-2xl p-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-medium",
							children: job.name
						}),
						!job.result && !job.error ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-3 space-y-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Progress, { value: job.progress }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "font-mono text-xs text-muted tabular-nums",
								children: [job.progress, "%"]
							})]
						}) : null,
						job.error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 text-sm text-danger",
							children: job.error
						}) : null,
						job.result ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-5 space-y-4",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-muted",
								children: formatBytes(job.result.file.sizeBytes)
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyField, {
								label: "Bagikan halaman ini",
								value: job.result.pageUrl
							})]
						}) : null
					]
				}, job.id))
			})
		]
	}) });
}
//#endregion
export { UploadPage as component };
