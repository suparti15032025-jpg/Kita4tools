import { C as getFileMeta, D as listFiles, E as isTikTokUrl, M as reportFile, N as resolveTikTok, c as RATE, j as rateLimit, k as purgeExpired, l as REPORT_REASONS, p as clientIp, t as ADMIN_COOKIE, v as deleteFile } from "./tiktok.server-BNVcQmyB.mjs";
import { a as setResponseHeader, i as getRequest, n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
import { a as string, i as object, r as number, t as boolean } from "../_libs/zod.mjs";
import { createHmac, randomBytes, timingSafeEqual } from "node:crypto";
//#region node_modules/.nitro/vite/services/ssr/assets/server-fns-c781On6Z.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
function secret() {
	return process.env.ADMIN_SECRET?.trim() || "kita-preview-admin-secret";
}
function password() {
	return process.env.ADMIN_PASSWORD?.trim() || "kita-admin";
}
function checkAdminPassword(input) {
	const expected = password();
	const a = Buffer.from(input);
	const b = Buffer.from(expected);
	if (a.length !== b.length) {
		timingSafeEqual(a.length > b.length ? a : Buffer.concat([a, a]), a.length > b.length ? a : Buffer.concat([a, a]));
		return false;
	}
	return timingSafeEqual(a, b);
}
function signAdminToken() {
	const payload = `${randomBytes(12).toString("base64url")}.${Date.now() + 432e5}`;
	return `${payload}.${createHmac("sha256", secret()).update(payload).digest("base64url")}`;
}
function verifyAdminToken(token) {
	if (!token) return false;
	const parts = token.split(".");
	if (parts.length !== 3) return false;
	const [nonce, expStr, sig] = parts;
	if (!nonce || !expStr || !sig) return false;
	const exp = Number(expStr);
	if (!Number.isFinite(exp) || Date.now() > exp) return false;
	const payload = `${nonce}.${expStr}`;
	const expected = createHmac("sha256", secret()).update(payload).digest("base64url");
	const a = Buffer.from(sig);
	const b = Buffer.from(expected);
	if (a.length !== b.length) return false;
	return timingSafeEqual(a, b);
}
function adminCookieHeader(token) {
	return `${ADMIN_COOKIE}=${token}; Path=/; HttpOnly; SameSite=Lax; Max-Age=43200`;
}
function clearAdminCookieHeader() {
	return `${ADMIN_COOKIE}=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0`;
}
function readAdminCookie(request) {
	const raw = request.headers.get("cookie") ?? "";
	for (const part of raw.split(";")) {
		const [k, ...rest] = part.trim().split("=");
		if (k === "kita_admin") return rest.join("=") || null;
	}
	return null;
}
function isAdminRequest(request) {
	return verifyAdminToken(readAdminCookie(request));
}
var reasonIds = REPORT_REASONS.map((r) => r.id);
var getPublicFile_createServerFn_handler = createServerRpc({
	id: "f0a270c3d15ee8fd5cf8545ac210eb2b24cf6e8b6015f0e4d4a4b0a79919fc52",
	name: "getPublicFile",
	filename: "src/lib/server-fns.ts"
}, (opts) => getPublicFile.__executeServer(opts));
var getPublicFile = createServerFn({ method: "GET" }).validator(object({ id: string().min(1).max(64) })).handler(getPublicFile_createServerFn_handler, async ({ data }) => {
	await purgeExpired();
	return getFileMeta(data.id);
});
var submitReport_createServerFn_handler = createServerRpc({
	id: "a3e05f954418ea1105e5c1ff4acc0838c7ed10042b09f4cccdc1d5b2fb7b01c2",
	name: "submitReport",
	filename: "src/lib/server-fns.ts"
}, (opts) => submitReport.__executeServer(opts));
var submitReport = createServerFn({ method: "POST" }).validator(object({
	id: string().min(1).max(64),
	reason: string().min(1).max(40)
})).handler(submitReport_createServerFn_handler, async ({ data }) => {
	if (!reasonIds.includes(data.reason)) throw new Error("Alasan tidak valid.");
	const request = getRequest();
	const ip = clientIp(request);
	if (!rateLimit(`report:${ip}`, RATE.report.limit, RATE.report.windowMs).ok) throw new Error("Terlalu banyak laporan. Coba lagi nanti.");
	if (!await reportFile(data.id, data.reason)) throw new Error("Berkas tidak ditemukan.");
	return { ok: true };
});
var inspectTikTok_createServerFn_handler = createServerRpc({
	id: "f257bf51cb38b362dc637ca62da6a182f758015706cc9dbdbd58ce39b520dea8",
	name: "inspectTikTok",
	filename: "src/lib/server-fns.ts"
}, (opts) => inspectTikTok.__executeServer(opts));
var inspectTikTok = createServerFn({ method: "POST" }).validator(object({ url: string().min(8).max(500) })).handler(inspectTikTok_createServerFn_handler, async ({ data }) => {
	const request = getRequest();
	const ip = clientIp(request);
	const rl = rateLimit(`tiktok:${ip}`, RATE.tiktok.limit, RATE.tiktok.windowMs);
	if (!rl.ok) throw new Error(`Terlalu banyak permintaan. Coba lagi dalam ${rl.retryAfterSec} detik.`);
	if (!isTikTokUrl(data.url)) throw new Error("Masukkan tautan TikTok yang valid, termasuk vm.tiktok.com.");
	try {
		return await resolveTikTok(data.url);
	} catch (err) {
		const message = err instanceof Error && err.message && !/unknown error/i.test(err.message) ? err.message : "Tidak bisa mengambil video. Pastikan tautan publik, lalu coba lagi.";
		throw new Error(message);
	}
});
function requireAdmin() {
	if (!isAdminRequest(getRequest())) throw new Error("Tidak diizinkan.");
}
var adminSession_createServerFn_handler = createServerRpc({
	id: "5a05d50df64c2b7aa53ffe5747e81756f116063f97b5d89a09b90879f2c58a16",
	name: "adminSession",
	filename: "src/lib/server-fns.ts"
}, (opts) => adminSession.__executeServer(opts));
var adminSession = createServerFn({ method: "GET" }).handler(adminSession_createServerFn_handler, async () => {
	return { ok: isAdminRequest(getRequest()) };
});
var adminLogin_createServerFn_handler = createServerRpc({
	id: "7f4aaf15444801417e25d1023ef89d979ecfc6caa83795ef8d79ca999f96a314",
	name: "adminLogin",
	filename: "src/lib/server-fns.ts"
}, (opts) => adminLogin.__executeServer(opts));
var adminLogin = createServerFn({ method: "POST" }).validator(object({ password: string().min(1).max(200) })).handler(adminLogin_createServerFn_handler, async ({ data }) => {
	const request = getRequest();
	const ip = clientIp(request);
	if (!rateLimit(`admin:${ip}`, RATE.admin.limit, RATE.admin.windowMs).ok) throw new Error("Terlalu banyak percobaan. Tunggu sebentar.");
	if (!checkAdminPassword(data.password)) throw new Error("Sandi salah.");
	setResponseHeader("set-cookie", adminCookieHeader(signAdminToken()));
	return { ok: true };
});
var adminLogout_createServerFn_handler = createServerRpc({
	id: "ef500b865ded474ada9177cb740af019b4470871f4f8a62c7c79d82ee0adbc44",
	name: "adminLogout",
	filename: "src/lib/server-fns.ts"
}, (opts) => adminLogout.__executeServer(opts));
var adminLogout = createServerFn({ method: "POST" }).handler(adminLogout_createServerFn_handler, async () => {
	setResponseHeader("set-cookie", clearAdminCookieHeader());
	return { ok: true };
});
var adminListFiles_createServerFn_handler = createServerRpc({
	id: "2ede684d283164feba1e929e5b72f53054486b38de6a7044b97e003e97084a25",
	name: "adminListFiles",
	filename: "src/lib/server-fns.ts"
}, (opts) => adminListFiles.__executeServer(opts));
var adminListFiles = createServerFn({ method: "GET" }).validator(object({
	q: string().max(120).optional(),
	reportedOnly: boolean().optional(),
	page: number().int().min(1).max(200).optional()
})).handler(adminListFiles_createServerFn_handler, async ({ data }) => {
	requireAdmin();
	const page = data.page ?? 1;
	const limit = 20;
	return listFiles({
		q: data.q,
		reportedOnly: data.reportedOnly,
		limit,
		offset: (page - 1) * limit
	});
});
var adminDeleteFile_createServerFn_handler = createServerRpc({
	id: "3cc498d453e1453dc6c006dacf5df140e49cc76e48778e1666231797ff1d16d3",
	name: "adminDeleteFile",
	filename: "src/lib/server-fns.ts"
}, (opts) => adminDeleteFile.__executeServer(opts));
var adminDeleteFile = createServerFn({ method: "POST" }).validator(object({ id: string().min(1).max(64) })).handler(adminDeleteFile_createServerFn_handler, async ({ data }) => {
	requireAdmin();
	if (!await deleteFile(data.id)) throw new Error("Berkas tidak ditemukan.");
	return { ok: true };
});
//#endregion
export { adminDeleteFile_createServerFn_handler, adminListFiles_createServerFn_handler, adminLogin_createServerFn_handler, adminLogout_createServerFn_handler, adminSession_createServerFn_handler, getPublicFile_createServerFn_handler, inspectTikTok_createServerFn_handler, submitReport_createServerFn_handler };
