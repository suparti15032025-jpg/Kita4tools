import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { L as redirect, V as notFound, _ as createRootRoute, b as useRouter, d as useRouterState, g as createFileRoute, h as lazyRouteComponent, l as Scripts, m as Outlet, p as createRouter, u as HeadContent, v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { o as require_jsx_runtime, r as Slot } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { A as putFileChunk, F as shouldInline, I as streamFileData, L as validateUpload, O as maxBytesForMode, P as safeRemoteUrl, T as insertFile, _ as createPendingFile, a as EXPIRY_OPTIONS, b as finalizeFile, c as RATE, d as UPLOAD_CHUNK_BYTES, f as bumpDownload, h as contentDisposition, i as APP_TAGLINE, j as rateLimit, k as purgeExpired, m as cn, p as clientIp, r as APP_NAME, u as TOOLS, x as formatBytes, y as fileExtension } from "./tiktok.server-BNVcQmyB.mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
import { a as string, i as object, n as literal, o as union, r as number, t as boolean } from "../_libs/zod.mjs";
import { c as Moon, i as Sun, l as Menu, r as TriangleAlert, t as X } from "../_libs/lucide-react.mjs";
import { a as DialogOverlay, c as DialogTrigger, n as DialogClose, o as DialogPortal, r as DialogContent, s as DialogTitle, t as Dialog } from "../_libs/@radix-ui/react-dialog+[...].mjs";
import { t as Toaster } from "../_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/server-fns-Cx9lggnD.js
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var getPublicFile = createServerFn({ method: "GET" }).validator(object({ id: string().min(1).max(64) })).handler(createSsrRpc("f0a270c3d15ee8fd5cf8545ac210eb2b24cf6e8b6015f0e4d4a4b0a79919fc52"));
var submitReport = createServerFn({ method: "POST" }).validator(object({
	id: string().min(1).max(64),
	reason: string().min(1).max(40)
})).handler(createSsrRpc("a3e05f954418ea1105e5c1ff4acc0838c7ed10042b09f4cccdc1d5b2fb7b01c2"));
var inspectTikTok = createServerFn({ method: "POST" }).validator(object({ url: string().min(8).max(500) })).handler(createSsrRpc("f257bf51cb38b362dc637ca62da6a182f758015706cc9dbdbd58ce39b520dea8"));
var adminSession = createServerFn({ method: "GET" }).handler(createSsrRpc("5a05d50df64c2b7aa53ffe5747e81756f116063f97b5d89a09b90879f2c58a16"));
var adminLogin = createServerFn({ method: "POST" }).validator(object({ password: string().min(1).max(200) })).handler(createSsrRpc("7f4aaf15444801417e25d1023ef89d979ecfc6caa83795ef8d79ca999f96a314"));
var adminLogout = createServerFn({ method: "POST" }).handler(createSsrRpc("ef500b865ded474ada9177cb740af019b4470871f4f8a62c7c79d82ee0adbc44"));
var adminListFiles = createServerFn({ method: "GET" }).validator(object({
	q: string().max(120).optional(),
	reportedOnly: boolean().optional(),
	page: number().int().min(1).max(200).optional()
})).handler(createSsrRpc("2ede684d283164feba1e929e5b72f53054486b38de6a7044b97e003e97084a25"));
var adminDeleteFile = createServerFn({ method: "POST" }).validator(object({ id: string().min(1).max(64) })).handler(createSsrRpc("3cc498d453e1453dc6c006dacf5df140e49cc76e48778e1666231797ff1d16d3"));
//#endregion
//#region node_modules/.nitro/vite/services/ssr/assets/router-CJOUtL5o.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var FALLBACK_MESSAGE = "Terjadi kesalahan. Muat ulang halaman, atau kembali ke beranda.";
function errorMessage(error) {
	if (error instanceof Error && error.message) return error.message;
	if (typeof error === "string" && error) return error;
	return FALLBACK_MESSAGE;
}
function AppErrorComponent({ error }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-dvh flex-col items-center justify-center gap-3 bg-bg px-6 text-center text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-danger",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
					className: "size-10",
					strokeWidth: 2
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-lg font-medium",
				children: "Ada yang tidak beres"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-md text-sm break-words text-muted",
				children: errorMessage(error)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
				to: "/",
				className: "mt-2 text-sm text-primary underline-offset-4 hover:underline",
				children: "Kembali ke beranda"
			})
		]
	});
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap text-sm font-medium transition-[color,background-color,opacity,transform,box-shadow] duration-(--motion-fast) ease-(--ease-smooth-out) focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 active:scale-[0.96]", {
	variants: {
		variant: {
			default: "bg-primary text-primary-foreground hover:opacity-90",
			secondary: "bg-secondary text-secondary-foreground border border-border hover:border-border-strong",
			outline: "border border-border bg-transparent hover:bg-secondary",
			ghost: "hover:bg-secondary",
			danger: "bg-danger text-danger-fg hover:opacity-90",
			link: "text-primary underline-offset-4 hover:underline"
		},
		size: {
			default: "h-11 rounded-md px-4",
			sm: "h-9 rounded-sm px-3 text-xs",
			lg: "h-12 rounded-lg px-6",
			icon: "h-11 w-11 rounded-md"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
var Button = import_react.forwardRef(({ className, variant, size, asChild = false, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size,
			className
		})),
		ref,
		...props
	});
});
Button.displayName = "Button";
function BrandMark({ className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 32 32",
		className: cn("size-8 shrink-0", className),
		"aria-hidden": true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
			width: "32",
			height: "32",
			rx: "6",
			className: "fill-fg"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			className: "fill-bg",
			d: "M7 6h6v20H7zm10.2 0 8.8 0-6.4 8.4h-2.4zm0 11.6h2.4L26 26h-8.8z"
		})]
	});
}
function BrandLockup({ className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to: "/",
		className: cn("flex min-h-11 items-center gap-2.5", className),
		"aria-label": APP_NAME,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BrandMark, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "font-display text-lg font-semibold tracking-tight",
			children: APP_NAME
		})]
	});
}
function SiteFooter() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
		className: "border-t border-border",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto grid max-w-6xl gap-10 px-4 py-12 sm:px-6 md:grid-cols-[1.4fr_1fr_1fr]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BrandMark, { className: "size-7" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-display text-lg font-semibold tracking-tight",
							children: APP_NAME
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "max-w-xs text-sm leading-relaxed text-muted",
						children: "Empat alat harian. Tanpa akun, tanpa omong kosong. QR, media, TikTok, dan berkas publik."
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "kicker",
					children: "Alat"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-4 space-y-2",
					children: TOOLS.map((tool) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: tool.href,
						className: "text-sm text-muted transition-colors hover:text-fg",
						children: tool.title
					}) }, tool.slug))
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "kicker",
					children: "Situs"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
					className: "mt-4 space-y-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/syarat",
							className: "text-sm text-muted transition-colors hover:text-fg",
							children: "Syarat"
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/privasi",
							className: "text-sm text-muted transition-colors hover:text-fg",
							children: "Privasi"
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/admin/login",
							className: "text-sm text-muted transition-colors hover:text-fg",
							children: "Admin"
						}) })
					]
				})] })
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "border-t border-border",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto flex max-w-6xl items-center justify-between px-4 py-5 sm:px-6",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-mono text-xs tracking-widest text-muted uppercase",
					children: APP_NAME
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted",
					children: "Tanpa akun. Siap dipakai."
				})]
			})
		})]
	});
}
function currentTheme() {
	if (typeof document === "undefined") return "light";
	return document.documentElement.classList.contains("dark") ? "dark" : "light";
}
function ThemeToggle() {
	const [theme, setTheme] = (0, import_react.useState)("light");
	(0, import_react.useEffect)(() => {
		setTheme(currentTheme());
	}, []);
	function toggle() {
		const next = currentTheme() === "dark" ? "light" : "dark";
		document.documentElement.classList.toggle("dark", next === "dark");
		try {
			localStorage.setItem("kita-theme", next);
		} catch {}
		setTheme(next);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
		type: "button",
		variant: "ghost",
		size: "icon",
		onClick: toggle,
		"aria-label": theme === "dark" ? "Mode terang" : "Mode gelap",
		children: theme === "dark" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sun, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Moon, {})
	});
}
var Sheet = Dialog;
var SheetTrigger = DialogTrigger;
var SheetPortal = DialogPortal;
var SheetOverlay = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, {
	ref,
	className: cn("fixed inset-0 z-50 bg-bg/70", className),
	...props
}));
SheetOverlay.displayName = DialogOverlay.displayName;
var SheetContent = import_react.forwardRef(({ className, children, side = "right", ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetOverlay, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
	ref,
	className: cn("fixed z-50 flex h-full w-[min(100%,20rem)] flex-col border-border bg-surface p-6", side === "right" ? "top-0 right-0 border-l" : "top-0 left-0 border-r", className),
	...props,
	children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogClose, {
		className: "absolute top-4 right-4 rounded-sm p-1 text-muted hover:text-fg",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "sr-only",
			children: "Tutup"
		})]
	})]
})] }));
SheetContent.displayName = DialogContent.displayName;
function SheetHeader({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("flex flex-col gap-1.5 pr-8", className),
		...props
	});
}
var SheetTitle = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
	ref,
	className: cn("font-display text-lg font-medium", className),
	...props
}));
SheetTitle.displayName = DialogTitle.displayName;
function NavLinks({ onClick, className }) {
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
		className: cn("flex items-center gap-1", className),
		children: TOOLS.map((tool) => {
			const active = pathname === tool.href || pathname.startsWith(`${tool.href}/`);
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: tool.href,
				onClick,
				className: cn("relative inline-flex min-h-11 items-center px-3 text-sm font-medium transition-colors duration-(--motion-quick) ease-(--ease-out)", active ? "text-fg" : "text-muted hover:text-fg"),
				children: [tool.short, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: cn("absolute inset-x-3 bottom-2 h-px bg-fg transition-opacity duration-(--motion-quick)", active ? "opacity-100" : "opacity-0") })]
			}, tool.slug);
		})
	});
}
function SiteHeader() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
		className: "sticky top-0 z-40 border-b border-border bg-bg",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mx-auto flex h-16 max-w-6xl items-center justify-between gap-3 px-4 sm:px-6",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(BrandLockup, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "hidden md:block",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavLinks, {})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ThemeToggle, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Sheet, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetTrigger, {
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							size: "icon",
							className: "md:hidden",
							"aria-label": "Menu",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, {})
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetTitle, { children: APP_NAME }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavLinks, { className: "mt-8 flex-col items-stretch" })] })] })]
				})
			]
		})
	});
}
function SiteShell({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative flex min-h-dvh flex-col bg-bg text-fg",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "bg-grid pointer-events-none absolute inset-0",
			"aria-hidden": true
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative flex min-h-dvh flex-col",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteHeader, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
					className: "flex-1",
					children
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteFooter, {})
			]
		})]
	});
}
function NotFound() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto flex max-w-lg flex-col items-start gap-4 px-4 py-24 sm:px-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "kicker",
				children: "404"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-title font-semibold tracking-tight",
				children: "Halaman tidak ada."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-muted",
				children: "Tautan salah, atau berkasnya sudah kedaluwarsa."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				asChild: true,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/",
					children: "Kembali ke beranda"
				})
			})
		]
	}) });
}
/**
* App-wide client provider mounted once near the root (in `src/routes/__root.tsx`):
*
*   <AuthProvider><Outlet /></AuthProvider>
*
* Better Auth's React client (`@/lib/auth/client`) needs NO context provider —
* its `useSession()` works standalone — so this is a passthrough today. It's
* kept as the single, stable mount point for any future client-side providers
* (e.g. a toast or theme provider) without churning the root shell.
*/
function AuthProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
var CONNECTOR_TOKEN_READY_EVENT = "grok:connector-token-ready";
function isGrokEmbedderOrigin(origin) {
	try {
		const url = new URL(origin);
		if (url.protocol !== "https:" && url.protocol !== "http:") return false;
		const host = url.hostname.toLowerCase();
		if (host === "grok.com" || host.endsWith(".grok.com")) return true;
		if (host === "localhost" || host === "127.0.0.1" || host === "[::1]") return true;
		return false;
	} catch {
		return false;
	}
}
function isSandboxPreviewGuestHost(hostname) {
	const host = hostname.toLowerCase();
	return host === "grok-sandbox.com" || host.endsWith(".grok-sandbox.com");
}
function isRemintPreviewPair(guestHost, parentHost) {
	const guest = guestHost.toLowerCase();
	const parent = parentHost.toLowerCase();
	const i = guest.indexOf(".preview.");
	if (i <= 0) return false;
	const label = guest.slice(0, i);
	const rest = guest.slice(i + 9);
	if (label.includes(".") || !rest.includes(".")) return false;
	return parent === rest || parent === `grok.${rest}`;
}
function resolveParentEmbedderOrigin(parentIsSelf, referrer, ancestorOrigin, guestHostname = "") {
	if (parentIsSelf) return null;
	for (const candidate of [referrer, ancestorOrigin ?? ""].filter(Boolean)) try {
		const url = new URL(candidate.includes("://") ? candidate : `https://${candidate}`);
		if (url.protocol !== "https:" && url.protocol !== "http:") continue;
		if (isGrokEmbedderOrigin(url.origin)) return url.origin;
		if (isSandboxPreviewGuestHost(guestHostname) || isRemintPreviewPair(guestHostname, url.hostname)) return url.origin;
	} catch {}
	return null;
}
/**
* Guest side of the grok-web ↔ sandbox preview postMessage bridge.
*
* Activates only when this page is framed by an allowlisted Grok embedder.
* Top-level runs (download/export, local `npm run dev`, deployed sites) noop.
*/
var PREVIEW_BRIDGE_CHANNEL = "grok-preview-bridge";
var EnvelopeSchema = object({
	channel: literal(PREVIEW_BRIDGE_CHANNEL),
	version: number().int().positive(),
	type: string().min(1)
});
var HelloSchema = EnvelopeSchema.extend({ type: literal("hello") });
var NavigateSchema = EnvelopeSchema.extend({
	type: literal("navigate"),
	path: string().min(1)
});
var HistorySchema = EnvelopeSchema.extend({
	type: literal("history"),
	delta: union([literal(-1), literal(1)])
});
var ConnectorTokenReadySchema = EnvelopeSchema.extend({ type: literal("connector-token-ready") });
function isSafeBridgePath(path) {
	if (!path.startsWith("/") || path.startsWith("//") || path.includes("\\")) return false;
	try {
		return new URL(path, "https://preview.invalid").origin === "https://preview.invalid";
	} catch {
		return false;
	}
}
/**
* Origin of the Grok embedder framing this page, or null when the page runs
* top-level (download/export, local `npm run dev`, deployed sites) or under a
* non-Grok parent. Client-only; null during SSR.
*/
function resolveCurrentEmbedderOrigin() {
	if (typeof window === "undefined") return null;
	const ancestorOrigin = typeof location.ancestorOrigins !== "undefined" && location.ancestorOrigins.length > 0 ? location.ancestorOrigins[0] : null;
	return resolveParentEmbedderOrigin(window.parent === window, document.referrer, ancestorOrigin, window.location.hostname);
}
/**
* Install host↔guest messaging. Returns a dispose function.
* Noops (returns a no-op dispose) when not embedded under a Grok parent.
*/
function installPreviewHostBridge(options = {}) {
	const parentOrigin = resolveCurrentEmbedderOrigin();
	if (parentOrigin === null) return () => {};
	const ROOT_STATE_KEY = "__grokPreviewBridgeRoot";
	const originalPushState = window.history.pushState.bind(window.history);
	const originalReplaceState = window.history.replaceState.bind(window.history);
	const isAtHistoryRoot = () => {
		const state = window.history.state;
		return Boolean(state && typeof state === "object" && state[ROOT_STATE_KEY] === true);
	};
	try {
		const current = window.history.state;
		if (!(current !== null && typeof current === "object" && Object.prototype.hasOwnProperty.call(current, ROOT_STATE_KEY))) {
			const isRoot = window.history.length <= 1;
			originalReplaceState(current && typeof current === "object" ? {
				...current,
				[ROOT_STATE_KEY]: isRoot
			} : { [ROOT_STATE_KEY]: isRoot }, "", window.location.href);
		}
	} catch {}
	const post = (message) => {
		window.parent.postMessage(message, parentOrigin);
	};
	const reportLocation = () => {
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "location",
			path: window.location.pathname || "/",
			search: window.location.search,
			hash: window.location.hash
		});
	};
	const reportRoutes = () => {
		const paths = options.getRoutePaths?.() ?? [];
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "routes",
			paths
		});
	};
	const defaultNavigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		try {
			const url = new URL(path, window.location.origin);
			if (url.origin !== window.location.origin) return;
			const next = `${url.pathname}${url.search}${url.hash}`;
			window.history.pushState(window.history.state, "", next);
			window.dispatchEvent(new PopStateEvent("popstate", { state: window.history.state }));
		} catch {}
	};
	const navigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		if (options.navigate) {
			options.navigate(path);
			return;
		}
		defaultNavigate(path);
	};
	const announce = () => {
		reportLocation();
		reportRoutes();
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "ready"
		});
	};
	const onHello = (data) => {
		if (!HelloSchema.safeParse(data).success) return;
		announce();
	};
	const onNavigate = (data) => {
		const parsed = NavigateSchema.safeParse(data);
		if (!parsed.success) return;
		navigate(parsed.data.path);
		queueMicrotask(reportLocation);
	};
	const onHistory = (data) => {
		const parsed = HistorySchema.safeParse(data);
		if (!parsed.success) return;
		if (parsed.data.delta === -1 && isAtHistoryRoot()) return;
		window.history.go(parsed.data.delta);
	};
	const onConnectorTokenReady = (data) => {
		if (!ConnectorTokenReadySchema.safeParse(data).success) return;
		window.dispatchEvent(new Event(CONNECTOR_TOKEN_READY_EVENT));
	};
	const hostMessageHandlers = /* @__PURE__ */ new Map([
		["hello", onHello],
		["navigate", onNavigate],
		["history", onHistory],
		["connector-token-ready", onConnectorTokenReady]
	]);
	const onMessage = (event) => {
		if (event.source !== window.parent) return;
		if (event.origin !== parentOrigin) return;
		const envelope = EnvelopeSchema.safeParse(event.data);
		if (!envelope.success || envelope.data.version !== 1) return;
		hostMessageHandlers.get(envelope.data.type)?.(event.data);
	};
	const onPopState = () => {
		reportLocation();
	};
	const onHashChange = () => {
		reportLocation();
	};
	window.history.pushState = (data, unused, url) => {
		const next = data && typeof data === "object" ? {
			...data,
			[ROOT_STATE_KEY]: false
		} : data;
		originalPushState(next, unused, url);
		reportLocation();
	};
	window.history.replaceState = (data, unused, url) => {
		const next = isAtHistoryRoot() ? {
			...data && typeof data === "object" ? data : {},
			[ROOT_STATE_KEY]: true
		} : data;
		originalReplaceState(next, unused, url);
		reportLocation();
	};
	window.addEventListener("message", onMessage);
	window.addEventListener("popstate", onPopState);
	window.addEventListener("hashchange", onHashChange);
	announce();
	return () => {
		window.removeEventListener("message", onMessage);
		window.removeEventListener("popstate", onPopState);
		window.removeEventListener("hashchange", onHashChange);
		window.history.pushState = originalPushState;
		window.history.replaceState = originalReplaceState;
	};
}
/** Collect static path patterns from a TanStack route tree (best-effort). */
function collectRoutePathsFromTree(routeTree) {
	const paths = /* @__PURE__ */ new Set();
	const walk = (node) => {
		if (!node || typeof node !== "object") return;
		const record = node;
		const full = typeof record.fullPath === "string" ? record.fullPath : typeof record.path === "string" ? record.path : null;
		if (full !== null && full !== "") paths.add(full.startsWith("/") ? full : `/${full}`);
		else if (full === "") paths.add("/");
		const children = record.children;
		if (Array.isArray(children)) for (const child of children) walk(child);
		else if (children && typeof children === "object") for (const child of Object.values(children)) walk(child);
	};
	walk(routeTree);
	return [...paths];
}
/**
* Mount once in `__root.tsx` so the Grok preview chrome can drive navigation
* (and later receive registered routes). Noops when the app is not embedded.
*/
function PreviewHostBridge() {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		return installPreviewHostBridge({
			navigate: (path) => {
				router.history.push(path);
			},
			getRoutePaths: () => collectRoutePathsFromTree(router.routeTree)
		});
	}, [router]);
	return null;
}
function Toaster$1({ ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
		theme: "system",
		className: "toaster group",
		toastOptions: { classNames: {
			toast: "group toast bg-surface text-fg border-border font-sans",
			description: "text-muted",
			actionButton: "bg-primary text-primary-foreground",
			cancelButton: "bg-secondary text-fg"
		} },
		...props
	});
}
var styles_default = "/assets/styles-BzfGppow.css";
var THEME_BOOT = `(function(){try{var t=localStorage.getItem('kita-theme');var d=t==='dark'||(t!=='light'&&window.matchMedia('(prefers-color-scheme: dark)').matches);if(d)document.documentElement.classList.add('dark');}catch(e){}})();`;
var Route$16 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: `${APP_NAME} — ${APP_TAGLINE}` },
			{
				name: "description",
				content: "QR, tautan gambar dan video, unduhan TikTok, dan berkas publik. Tanpa akun."
			},
			{
				name: "theme-color",
				content: "#0b0c0d"
			}
		],
		links: [
			{
				rel: "icon",
				type: "image/svg+xml",
				href: "/favicon.svg"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "manifest",
				href: "/__grok/manifest.webmanifest"
			},
			{
				rel: "apple-touch-icon",
				href: "/__grok/icon-180.png"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Figtree:ital,wght@0,400;0,500;0,600;0,700;1,400&family=IBM+Plex+Mono:wght@400;500&family=Syne:wght@500;600;700;800&display=swap"
			}
		]
	}),
	notFoundComponent: NotFound,
	component: RootComponent
});
function RootComponent() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "id",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", {
			className: "antialiased",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("script", { dangerouslySetInnerHTML: { __html: THEME_BOOT } }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewHostBridge, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AuthProvider, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster$1, {})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
			]
		})]
	});
}
var $$splitComponentImporter$11 = () => import("./routes-C5Pq_lW2.mjs");
var Route$15 = createFileRoute("/")({ component: lazyRouteComponent($$splitComponentImporter$11, "component") });
var $$splitComponentImporter$10 = () => import("./admin-ChRe4jtd.mjs");
var Route$14 = createFileRoute("/admin")({ component: lazyRouteComponent($$splitComponentImporter$10, "component") });
var $$splitComponentImporter$9 = () => import("./media-HYtQ_zVB.mjs");
var Route$13 = createFileRoute("/media")({ component: lazyRouteComponent($$splitComponentImporter$9, "component") });
var $$splitComponentImporter$8 = () => import("./privasi-BX6AG8Sw.mjs");
var Route$12 = createFileRoute("/privasi")({ component: lazyRouteComponent($$splitComponentImporter$8, "component") });
var $$splitComponentImporter$7 = () => import("./qr-Bn8WI_wr.mjs");
var Route$11 = createFileRoute("/qr")({ component: lazyRouteComponent($$splitComponentImporter$7, "component") });
var $$splitComponentImporter$6 = () => import("./syarat-BfL0V2gA.mjs");
var Route$10 = createFileRoute("/syarat")({ component: lazyRouteComponent($$splitComponentImporter$6, "component") });
var $$splitComponentImporter$5 = () => import("./tiktok-dG37qtja.mjs");
var Route$9 = createFileRoute("/tiktok")({ component: lazyRouteComponent($$splitComponentImporter$5, "component") });
var $$splitComponentImporter$4 = () => import("./upload-lMVhAr1u.mjs");
var Route$8 = createFileRoute("/upload")({ component: lazyRouteComponent($$splitComponentImporter$4, "component") });
var $$splitComponentImporter$3 = () => import("./admin.index-D9FdqxBp.mjs");
var Route$7 = createFileRoute("/admin/")({
	validateSearch: (search) => ({
		q: typeof search.q === "string" && search.q ? search.q : void 0,
		reported: search.reported === "1" || search.reported === true ? true : void 0,
		page: Number(search.page) > 1 ? Number(search.page) : void 0
	}),
	loaderDeps: ({ search }) => search,
	loader: async ({ deps }) => {
		if (!(await adminSession()).ok) throw redirect({ to: "/admin/login" });
		return adminListFiles({ data: {
			q: deps.q,
			reportedOnly: deps.reported,
			page: deps.page ?? 1
		} });
	},
	component: lazyRouteComponent($$splitComponentImporter$3, "component")
});
var $$splitComponentImporter$2 = () => import("./admin.login-ZplSI4Mw.mjs");
var Route$6 = createFileRoute("/admin/login")({
	loader: async () => {
		if ((await adminSession()).ok) throw redirect({ to: "/admin" });
		return null;
	},
	component: lazyRouteComponent($$splitComponentImporter$2, "component")
});
function allowedHost(host) {
	const h = host.toLowerCase();
	return [
		"tiktok",
		"tiktokcdn",
		"tiktokv",
		"byteoversea",
		"bytecdn",
		"ibyteimg",
		"musical.ly",
		"muscdn",
		"tikwm",
		"ttwstatic",
		"akamaized",
		"ssstik",
		"tiklydown"
	].some((part) => h.includes(part));
}
var Route$5 = createFileRoute("/api/tiktok-file")({ server: { handlers: { GET: async ({ request }) => {
	const url = new URL(request.url);
	const remote = url.searchParams.get("url") ?? "";
	const filename = (url.searchParams.get("filename") ?? "tiktok-media").replace(/[/\\]/g, "");
	if (!safeRemoteUrl(remote)) return Response.json({ error: "URL tidak valid." }, { status: 400 });
	let parsed;
	try {
		parsed = new URL(remote);
	} catch {
		return Response.json({ error: "URL tidak valid." }, { status: 400 });
	}
	if (!allowedHost(parsed.hostname)) return Response.json({ error: "Sumber media tidak diizinkan." }, { status: 400 });
	try {
		const res = await fetch(remote, {
			headers: {
				"user-agent": "Mozilla/5.0 (iPhone; CPU iPhone OS 17_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Mobile/15E148 Safari/604.1",
				referer: "https://www.tiktok.com/"
			},
			redirect: "follow",
			signal: AbortSignal.timeout(25e3)
		});
		if (!res.ok || !res.body) return Response.json({ error: "Gagal mengunduh media sumber. Coba lagi." }, { status: 502 });
		const type = res.headers.get("content-type") ?? "application/octet-stream";
		const headers = new Headers({
			"content-type": type,
			"content-disposition": contentDisposition(filename, "attachment"),
			"x-content-type-options": "nosniff"
		});
		const len = res.headers.get("content-length");
		if (len) headers.set("content-length", len);
		return new Response(res.body, { headers });
	} catch {
		return Response.json({ error: "Gagal mengunduh media sumber. Tautan kedaluwarsa atau diblokir. Ambil ulang videonya." }, { status: 502 });
	}
} } } });
function originFromRequest(request) {
	return `${request.headers.get("x-forwarded-proto") ?? "http"}://${request.headers.get("x-forwarded-host") ?? request.headers.get("host") ?? "localhost:8080"}`;
}
function urlsForFile(origin, id, kind) {
	return {
		directUrl: `${origin}/api/raw/${id}`,
		downloadUrl: `${origin}/api/dl/${id}`,
		previewUrl: kind === "image" || kind === "video" ? `${origin}/v/${id}` : `${origin}/f/${id}`,
		pageUrl: kind === "file" ? `${origin}/f/${id}` : `${origin}/v/${id}`
	};
}
function jsonError(error, status) {
	return Response.json({ error }, { status });
}
function parseExpiry(raw) {
	return EXPIRY_OPTIONS.find((o) => o.id === raw) ?? EXPIRY_OPTIONS[2];
}
var Route$4 = createFileRoute("/api/upload")({ server: { handlers: { POST: async ({ request }) => {
	try {
		const ip = clientIp(request);
		await purgeExpired();
		let form;
		try {
			form = await request.formData();
		} catch (err) {
			const msg = err instanceof Error ? err.message : "";
			if (/payload|too large|body/i.test(msg)) return jsonError("Berkas terlalu besar. Unggah ulang; sistem akan memotongnya otomatis.", 413);
			return jsonError("Tidak bisa membaca unggahan.", 400);
		}
		const step = String(form.get("step") || "single");
		if (step === "init") {
			const rl = rateLimit(`upload:${ip}`, RATE.upload.limit, RATE.upload.windowMs);
			if (!rl.ok) return jsonError(`Terlalu banyak unggahan. Coba lagi dalam ${rl.retryAfterSec} detik.`, 429);
			const name = String(form.get("name") || "");
			const size = Number(form.get("size") || 0);
			const mime = String(form.get("mime") || "");
			const mode = form.get("mode") === "media" ? "media" : "file";
			const chunkCount = Number(form.get("chunkCount") || 0);
			const expiry = parseExpiry(String(form.get("expiry") ?? "7d"));
			const check = validateUpload({
				name,
				size,
				mime,
				mode
			});
			if (!check.ok) return jsonError(check.error, 400);
			const expected = Math.max(1, Math.ceil(size / UPLOAD_CHUNK_BYTES));
			if (!Number.isInteger(chunkCount) || chunkCount < 1 || chunkCount > expected + 2) return jsonError("Jumlah potongan unggahan tidak valid.", 400);
			const meta = await createPendingFile({
				originalName: check.name,
				mime: check.mime,
				kind: check.kind,
				size,
				chunkCount,
				expiresAt: expiry.ms ? new Date(Date.now() + expiry.ms) : null
			});
			return Response.json({ id: meta.id });
		}
		if (step === "chunk") {
			const rl = rateLimit(`chunk:${ip}`, RATE.chunk.limit, RATE.chunk.windowMs);
			if (!rl.ok) return jsonError(`Terlalu banyak unggahan. Coba lagi dalam ${rl.retryAfterSec} detik.`, 429);
			const id = String(form.get("id") || "");
			const index = Number(form.get("index"));
			const chunk = form.get("chunk");
			if (!id || !Number.isInteger(index) || !(chunk instanceof File)) return jsonError("Potongan unggahan tidak valid.", 400);
			if (chunk.size > 1638400) return jsonError("Potongan terlalu besar.", 413);
			const bytes = new Uint8Array(await chunk.arrayBuffer());
			await putFileChunk(id, index, bytes);
			return Response.json({
				ok: true,
				index
			});
		}
		if (step === "complete") {
			const id = String(form.get("id") || "");
			if (!id) return jsonError("Sesi unggahan tidak valid.", 400);
			const meta = await finalizeFile(id);
			const urls = urlsForFile(originFromRequest(request), meta.id, meta.kind);
			return Response.json({
				file: meta,
				...urls
			});
		}
		const rl = rateLimit(`upload:${ip}`, RATE.upload.limit, RATE.upload.windowMs);
		if (!rl.ok) return jsonError(`Terlalu banyak unggahan. Coba lagi dalam ${rl.retryAfterSec} detik.`, 429);
		const file = form.get("file");
		if (!(file instanceof File)) return jsonError("Berkas tidak ditemukan.", 400);
		const mode = form.get("mode") === "media" ? "media" : "file";
		const cap = maxBytesForMode(mode);
		if (file.size > cap) return jsonError(`Berkas terlalu besar. Maksimal ${Math.round(cap / 1048576)} MB.`, 413);
		const expiry = parseExpiry(String(form.get("expiry") ?? "7d"));
		const check = validateUpload({
			name: file.name,
			size: file.size,
			mime: file.type,
			mode
		});
		if (!check.ok) return jsonError(check.error, 400);
		const bytes = new Uint8Array(await file.arrayBuffer());
		const meta = await insertFile({
			originalName: check.name,
			mime: check.mime,
			kind: check.kind,
			bytes,
			expiresAt: expiry.ms ? new Date(Date.now() + expiry.ms) : null
		});
		const urls = urlsForFile(originFromRequest(request), meta.id, meta.kind);
		return Response.json({
			file: meta,
			...urls
		});
	} catch (err) {
		const message = err instanceof Error ? err.message : "Gagal mengunggah.";
		return jsonError(message, /terlalu besar|potongan/i.test(message) ? 413 : 500);
	}
} } } });
var $$splitComponentImporter$1 = () => import("./f._id-C6NW2F0l.mjs");
var Route$3 = createFileRoute("/f/$id")({
	loader: async ({ params }) => {
		const file = await getPublicFile({ data: { id: params.id } });
		if (!file) throw notFound();
		return file;
	},
	component: lazyRouteComponent($$splitComponentImporter$1, "component")
});
var $$splitComponentImporter = () => import("./v._id-DYUBf3KR.mjs");
var Route$2 = createFileRoute("/v/$id")({
	loader: async ({ params }) => {
		const file = await getPublicFile({ data: { id: params.id } });
		if (!file) throw notFound();
		return file;
	},
	head: ({ loaderData }) => {
		const file = loaderData;
		if (!file) return { meta: [{ title: `Media — ${APP_NAME}` }] };
		const image = `/api/raw/${file.id}`;
		const isVideo = file.kind === "video";
		const meta = [
			{ title: `${file.originalName} — ${APP_NAME}` },
			{
				name: "description",
				content: `Media di ${APP_NAME}`
			},
			{
				property: "og:title",
				content: file.originalName
			},
			{
				property: "og:description",
				content: `${formatBytes(file.sizeBytes)} · ${APP_NAME}`
			},
			{
				property: "og:type",
				content: isVideo ? "video.other" : "website"
			}
		];
		if (isVideo) {
			meta.push({
				property: "og:video",
				content: image
			});
			meta.push({
				name: "twitter:card",
				content: "player"
			});
		} else {
			meta.push({
				property: "og:image",
				content: image
			});
			meta.push({
				name: "twitter:card",
				content: "summary_large_image"
			});
		}
		return { meta };
	},
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
async function serveStoredFile(id, mode) {
	const blob = await streamFileData(id);
	if (!blob) return Response.json({ error: "Berkas tidak ditemukan atau sudah kedaluwarsa." }, { status: 404 });
	await bumpDownload(id);
	const ext = fileExtension(blob.meta.originalName);
	const inline = mode === "inline" && shouldInline(blob.meta.kind, ext);
	const disposition = contentDisposition(blob.meta.originalName, inline ? "inline" : "attachment");
	const headers = {
		"content-type": blob.meta.mimeType,
		"content-disposition": disposition,
		"x-content-type-options": "nosniff",
		"cache-control": "private, max-age=3600",
		"content-length": String(blob.meta.sizeBytes)
	};
	return new Response(blob.body, { headers });
}
var Route$1 = createFileRoute("/api/dl/$id")({ server: { handlers: { GET: async ({ params }) => serveStoredFile(params.id, "attachment") } } });
var Route = createFileRoute("/api/raw/$id")({ server: { handlers: { GET: async ({ params }) => serveStoredFile(params.id, "inline") } } });
var IndexRoute = Route$15.update({
	id: "/",
	path: "/",
	getParentRoute: () => Route$16
});
var AdminRoute = Route$14.update({
	id: "/admin",
	path: "/admin",
	getParentRoute: () => Route$16
});
var MediaRoute = Route$13.update({
	id: "/media",
	path: "/media",
	getParentRoute: () => Route$16
});
var PrivasiRoute = Route$12.update({
	id: "/privasi",
	path: "/privasi",
	getParentRoute: () => Route$16
});
var QrRoute = Route$11.update({
	id: "/qr",
	path: "/qr",
	getParentRoute: () => Route$16
});
var SyaratRoute = Route$10.update({
	id: "/syarat",
	path: "/syarat",
	getParentRoute: () => Route$16
});
var TiktokRoute = Route$9.update({
	id: "/tiktok",
	path: "/tiktok",
	getParentRoute: () => Route$16
});
var UploadRoute = Route$8.update({
	id: "/upload",
	path: "/upload",
	getParentRoute: () => Route$16
});
var AdminIndexRoute = Route$7.update({
	id: "/",
	path: "/",
	getParentRoute: () => AdminRoute
});
var AdminLoginRoute = Route$6.update({
	id: "/login",
	path: "/login",
	getParentRoute: () => AdminRoute
});
var ApiTiktokFileRoute = Route$5.update({
	id: "/api/tiktok-file",
	path: "/api/tiktok-file",
	getParentRoute: () => Route$16
});
var ApiUploadRoute = Route$4.update({
	id: "/api/upload",
	path: "/api/upload",
	getParentRoute: () => Route$16
});
var FIdRoute = Route$3.update({
	id: "/f/$id",
	path: "/f/$id",
	getParentRoute: () => Route$16
});
var VIdRoute = Route$2.update({
	id: "/v/$id",
	path: "/v/$id",
	getParentRoute: () => Route$16
});
var ApiDlIdRoute = Route$1.update({
	id: "/api/dl/$id",
	path: "/api/dl/$id",
	getParentRoute: () => Route$16
});
var ApiRawIdRoute = Route.update({
	id: "/api/raw/$id",
	path: "/api/raw/$id",
	getParentRoute: () => Route$16
});
var AdminRouteChildren = {
	AdminLoginRoute,
	AdminIndexRoute
};
var rootRouteChildren = {
	IndexRoute,
	AdminRoute: AdminRoute._addFileChildren(AdminRouteChildren),
	MediaRoute,
	PrivasiRoute,
	QrRoute,
	SyaratRoute,
	TiktokRoute,
	UploadRoute,
	ApiTiktokFileRoute,
	ApiUploadRoute,
	FIdRoute,
	VIdRoute,
	ApiDlIdRoute,
	ApiRawIdRoute
};
var routeTree = Route$16._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
function getRouter() {
	return createRouter({
		routeTree,
		defaultErrorComponent: AppErrorComponent,
		defaultNotFoundComponent: NotFound,
		scrollRestoration: true
	});
}
//#endregion
export { SiteShell as a, adminLogin as c, submitReport as d, Route$7 as i, adminLogout as l, Route$2 as n, Button as o, Route$3 as r, adminDeleteFile as s, router_exports as t, inspectTikTok as u };
