import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { x as formatBytes } from "./tiktok.server-BNVcQmyB.mjs";
import { m as Download } from "../_libs/lucide-react.mjs";
import { a as SiteShell, n as Route$2, o as Button } from "./router-CJOUtL5o.mjs";
import { t as ReportDialog } from "./report-dialog-Ce3SdYd8.mjs";
import { n as formatDistanceToNow, t as id } from "../_libs/date-fns.mjs";
import { t as CopyField } from "./copy-field-C9FQl0DI.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/v._id-DYUBf3KR.js
var import_jsx_runtime = require_jsx_runtime();
function MediaViewPage() {
	const file = Route$2.useLoaderData();
	const direct = `/api/raw/${file.id}`;
	const downloadUrl = `/api/dl/${file.id}`;
	const isVideo = file.kind === "video";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-3xl space-y-6 px-4 py-12 sm:px-6 sm:py-16",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "kicker",
				children: "Pratinjau media"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-title font-semibold tracking-tight break-all",
				children: file.originalName
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted",
				children: [
					formatBytes(file.sizeBytes),
					" ·",
					" ",
					formatDistanceToNow(new Date(file.createdAt), {
						addSuffix: true,
						locale: id
					}),
					" ·",
					" ",
					file.downloadCount,
					" unduhan"
				]
			}),
			isVideo ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("video", {
				src: direct,
				controls: true,
				className: "w-full rounded-2xl bg-bg"
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				src: direct,
				alt: file.originalName,
				className: "w-full rounded-2xl"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					asChild: true,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
						href: downloadUrl,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {}), "Unduh"]
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReportDialog, { fileId: file.id })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyField, {
				label: "Tautan langsung",
				value: typeof window === "undefined" ? direct : `${window.location.origin}${direct}`
			})
		]
	}) });
}
//#endregion
export { MediaViewPage as component };
