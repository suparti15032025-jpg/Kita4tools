import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { m as cn } from "./tiktok.server-BNVcQmyB.mjs";
import { a as RotateCcw, d as ImagePlus, m as Download } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { a as SiteShell, o as Button } from "./router-CJOUtL5o.mjs";
import { t as Input } from "./input-CPYv1eDm.mjs";
import { t as Switch } from "./switch-CjAvPzoN.mjs";
import { t as Label } from "./label-DCeeSPw0.mjs";
import { t as PageHeader } from "./page-header-DaUDOWJs.mjs";
import { i as SliderTrack, n as SliderRange, r as SliderThumb, t as Slider$1 } from "../_libs/radix-ui__react-slider.mjs";
import { i as Trigger, n as List, r as Root2, t as Content } from "../_libs/radix-ui__react-tabs.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/qr-Bn8WI_wr.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var Slider = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Slider$1, {
	ref,
	className: cn("relative flex w-full touch-none select-none items-center", className),
	...props,
	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderTrack, {
		className: "relative h-1.5 w-full grow overflow-hidden rounded-full bg-secondary",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderRange, { className: "absolute h-full bg-primary" })
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderThumb, { className: "block h-5 w-5 rounded-full border border-border-strong bg-surface shadow-none focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring" })]
}));
Slider.displayName = Slider$1.displayName;
var Tabs = Root2;
var TabsList = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(List, {
	ref,
	className: cn("flex min-h-11 w-full flex-wrap items-center gap-1 rounded-lg bg-secondary p-1 text-muted", className),
	...props
}));
TabsList.displayName = List.displayName;
var TabsTrigger = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trigger, {
	ref,
	className: cn("inline-flex min-h-9 flex-1 items-center justify-center whitespace-nowrap rounded-md px-3 text-sm font-medium transition-[background-color,color] duration-(--motion-fast) data-[state=active]:bg-surface data-[state=active]:text-fg data-[state=inactive]:hover:text-fg disabled:pointer-events-none disabled:opacity-50", className),
	...props
}));
TabsTrigger.displayName = Trigger.displayName;
var TabsContent = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Content, {
	ref,
	className: cn("mt-5 outline-none", className),
	...props
}));
TabsContent.displayName = Content.displayName;
var Textarea = import_react.forwardRef(({ className, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("textarea", {
		className: cn("flex min-h-28 w-full rounded-md border border-border bg-surface px-3 py-2.5 text-sm text-fg placeholder:text-muted focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50", className),
		ref,
		...props
	});
});
Textarea.displayName = "Textarea";
var EMPTY_QR_FIELDS = {
	text: "",
	wifiSsid: "",
	wifiPassword: "",
	wifiHidden: false,
	wifiType: "WPA",
	waPhone: "",
	waMessage: "",
	emailTo: "",
	emailSubject: "",
	emailBody: "",
	vName: "",
	vOrg: "",
	vPhone: "",
	vEmail: "",
	vUrl: ""
};
function escapeWifi(value) {
	return value.replace(/([\\;,:"])/g, "\\$1");
}
function digitsPhone(value) {
	const trimmed = value.trim();
	if (trimmed.startsWith("+")) return `+${trimmed.slice(1).replace(/\D/g, "")}`;
	return trimmed.replace(/\D/g, "");
}
function buildQrPayload(kind, fields) {
	switch (kind) {
		case "text": return fields.text.trim();
		case "wifi": {
			const t = fields.wifiType;
			const hidden = fields.wifiHidden ? "H:true;" : "";
			const pass = t === "nopass" ? "" : `P:${escapeWifi(fields.wifiPassword)};`;
			return `WIFI:T:${t};S:${escapeWifi(fields.wifiSsid)};${pass}${hidden};`;
		}
		case "whatsapp": {
			const phone = digitsPhone(fields.waPhone);
			const text = encodeURIComponent(fields.waMessage);
			const q = fields.waMessage.trim() ? `?text=${text}` : "";
			return phone ? `https://wa.me/${phone}${q}` : "";
		}
		case "email": {
			const to = fields.emailTo.trim();
			if (!to) return "";
			const params = new URLSearchParams();
			if (fields.emailSubject.trim()) params.set("subject", fields.emailSubject.trim());
			if (fields.emailBody.trim()) params.set("body", fields.emailBody.trim());
			const qs = params.toString();
			return `mailto:${to}${qs ? `?${qs}` : ""}`;
		}
		case "vcard": {
			const lines = [
				"BEGIN:VCARD",
				"VERSION:3.0",
				fields.vName.trim() ? `FN:${fields.vName.trim()}` : "",
				fields.vOrg.trim() ? `ORG:${fields.vOrg.trim()}` : "",
				fields.vPhone.trim() ? `TEL:${fields.vPhone.trim()}` : "",
				fields.vEmail.trim() ? `EMAIL:${fields.vEmail.trim()}` : "",
				fields.vUrl.trim() ? `URL:${fields.vUrl.trim()}` : "",
				"END:VCARD"
			].filter(Boolean);
			return lines.length > 3 ? lines.join("\n") : "";
		}
	}
}
function downloadBlob(blob, name) {
	const url = URL.createObjectURL(blob);
	const a = document.createElement("a");
	a.href = url;
	a.download = name;
	a.click();
	URL.revokeObjectURL(url);
}
function QrStudio() {
	const canvasRef = (0, import_react.useRef)(null);
	const [kind, setKind] = (0, import_react.useState)("text");
	const [fields, setFields] = (0, import_react.useState)(EMPTY_QR_FIELDS);
	const [size, setSize] = (0, import_react.useState)(320);
	const [margin, setMargin] = (0, import_react.useState)(2);
	const [fg, setFg] = (0, import_react.useState)("#12110e");
	const [bg, setBg] = (0, import_react.useState)("#faf7f0");
	const [level, setLevel] = (0, import_react.useState)("M");
	const [logo, setLogo] = (0, import_react.useState)(null);
	const payload = (0, import_react.useMemo)(() => buildQrPayload(kind, fields), [kind, fields]);
	function patch(partial) {
		setFields((prev) => ({
			...prev,
			...partial
		}));
	}
	(0, import_react.useEffect)(() => {
		const canvas = canvasRef.current;
		if (!canvas) return;
		let cancelled = false;
		const effectiveLevel = logo ? "H" : level;
		(async () => {
			const QRCode = await import("../_libs/qrcode.mjs").then((n) => /* @__PURE__ */ __toESM(n.t()));
			if (cancelled || !payload) {
				const ctx = canvas.getContext("2d");
				if (ctx) {
					ctx.fillStyle = bg;
					ctx.fillRect(0, 0, size, size);
				}
				return;
			}
			canvas.width = size;
			canvas.height = size;
			await QRCode.toCanvas(canvas, payload, {
				width: size,
				margin,
				errorCorrectionLevel: effectiveLevel,
				color: {
					dark: fg,
					light: bg
				}
			});
			if (cancelled || !logo) return;
			const img = new Image();
			img.crossOrigin = "anonymous";
			await new Promise((resolve, reject) => {
				img.onload = () => resolve();
				img.onerror = () => reject(/* @__PURE__ */ new Error("Logo gagal dimuat"));
				img.src = logo;
			});
			if (cancelled) return;
			const ctx = canvas.getContext("2d");
			if (!ctx) return;
			const logoSize = Math.round(size * .2);
			const x = (size - logoSize) / 2;
			const y = (size - logoSize) / 2;
			const pad = Math.round(logoSize * .12);
			ctx.fillStyle = bg;
			ctx.beginPath();
			ctx.roundRect(x - pad, y - pad, logoSize + pad * 2, logoSize + pad * 2, 8);
			ctx.fill();
			ctx.drawImage(img, x, y, logoSize, logoSize);
		})().catch(() => {
			toast.error("Gagal menggambar QR.");
		});
		return () => {
			cancelled = true;
		};
	}, [
		payload,
		size,
		margin,
		fg,
		bg,
		level,
		logo
	]);
	async function downloadPng() {
		const canvas = canvasRef.current;
		if (!canvas || !payload) return;
		canvas.toBlob((blob) => {
			if (!blob) return;
			downloadBlob(blob, "kita-qr.png");
		}, "image/png");
	}
	async function downloadSvg() {
		if (!payload) return;
		let svg = await (await import("../_libs/qrcode.mjs").then((n) => /* @__PURE__ */ __toESM(n.t()))).toString(payload, {
			type: "svg",
			margin,
			errorCorrectionLevel: logo ? "H" : level,
			color: {
				dark: fg,
				light: bg
			},
			width: size
		});
		if (logo) {
			const logoSize = Math.round(size * .2);
			const x = (size - logoSize) / 2;
			const y = (size - logoSize) / 2;
			svg = svg.replace("</svg>", `<image href="${logo}" x="${x}" y="${y}" width="${logoSize}" height="${logoSize}" /></svg>`);
		}
		downloadBlob(new Blob([svg], { type: "image/svg+xml" }), "kita-qr.svg");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-6 lg:grid-cols-[minmax(0,1fr)_22rem]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "panel rounded-2xl p-5 md:p-6",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tabs, {
				value: kind,
				onValueChange: (v) => setKind(v),
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsList, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
							value: "text",
							children: "Teks"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
							value: "wifi",
							children: "WiFi"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
							value: "whatsapp",
							children: "WhatsApp"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
							value: "email",
							children: "Email"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TabsTrigger, {
							value: "vcard",
							children: "Kontak"
						})
					] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsContent, {
						value: "text",
						className: "space-y-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "qr-text",
							children: "Teks atau tautan"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
							id: "qr-text",
							value: fields.text,
							onChange: (e) => patch({ text: e.target.value }),
							placeholder: "https://contoh.com atau catatan singkat"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsContent, {
						value: "wifi",
						className: "grid gap-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Nama jaringan (SSID)",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: fields.wifiSsid,
									onChange: (e) => patch({ wifiSsid: e.target.value })
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Sandi",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "password",
									value: fields.wifiPassword,
									onChange: (e) => patch({ wifiPassword: e.target.value }),
									disabled: fields.wifiType === "nopass"
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Keamanan",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
									className: "native-select",
									value: fields.wifiType,
									onChange: (e) => patch({ wifiType: e.target.value }),
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "WPA",
											children: "WPA / WPA2"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "WEP",
											children: "WEP"
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
											value: "nopass",
											children: "Tanpa sandi"
										})
									]
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "flex min-h-11 items-center justify-between gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-sm",
									children: "Jaringan tersembunyi"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
									checked: fields.wifiHidden,
									onCheckedChange: (v) => patch({ wifiHidden: v })
								})]
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsContent, {
						value: "whatsapp",
						className: "grid gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Nomor (kode negara, tanpa + boleh)",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								inputMode: "tel",
								placeholder: "62812xxxxxxx",
								value: fields.waPhone,
								onChange: (e) => patch({ waPhone: e.target.value })
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Pesan",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
								value: fields.waMessage,
								onChange: (e) => patch({ waMessage: e.target.value }),
								placeholder: "Halo, saya tertarik…"
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsContent, {
						value: "email",
						className: "grid gap-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Alamat",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									type: "email",
									value: fields.emailTo,
									onChange: (e) => patch({ emailTo: e.target.value })
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Subjek",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: fields.emailSubject,
									onChange: (e) => patch({ emailSubject: e.target.value })
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Isi",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
									value: fields.emailBody,
									onChange: (e) => patch({ emailBody: e.target.value })
								})
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(TabsContent, {
						value: "vcard",
						className: "grid gap-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Nama",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: fields.vName,
									onChange: (e) => patch({ vName: e.target.value })
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Organisasi",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: fields.vOrg,
									onChange: (e) => patch({ vOrg: e.target.value })
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Telepon",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: fields.vPhone,
									onChange: (e) => patch({ vPhone: e.target.value })
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Email",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: fields.vEmail,
									onChange: (e) => patch({ vEmail: e.target.value })
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
								label: "Situs",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
									value: fields.vUrl,
									onChange: (e) => patch({ vUrl: e.target.value })
								})
							})
						]
					})
				]
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
			className: "space-y-5",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "panel rounded-2xl p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex aspect-square items-center justify-center rounded-lg bg-bg p-4",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
							ref: canvasRef,
							width: size,
							height: size,
							className: "max-h-full max-w-full",
							style: { imageRendering: "pixelated" }
						})
					}),
					!payload ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-3 text-center text-sm text-muted",
						children: "Isi data untuk melihat pratinjau."
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-4 grid grid-cols-2 gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							type: "button",
							onClick: downloadPng,
							disabled: !payload,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {}), "PNG"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							type: "button",
							variant: "secondary",
							onClick: downloadSvg,
							disabled: !payload,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, {}), "SVG"]
						})]
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "panel space-y-4 rounded-2xl p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: `Ukuran · ${size}px`,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
							min: 160,
							max: 720,
							step: 8,
							value: [size],
							onValueChange: (v) => setSize(v[0] ?? 320)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: `Margin · ${margin}`,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
							min: 0,
							max: 8,
							step: 1,
							value: [margin],
							onValueChange: (v) => setMargin(v[0] ?? 2)
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Warna QR",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "color",
								value: fg,
								onChange: (e) => setFg(e.target.value),
								className: "h-11 p-1"
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Latar",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								type: "color",
								value: bg,
								onChange: (e) => setBg(e.target.value),
								className: "h-11 p-1"
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Field, {
						label: "Koreksi error",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("select", {
							className: "native-select",
							value: level,
							onChange: (e) => setLevel(e.target.value),
							disabled: Boolean(logo),
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "L",
									children: "L — rendah"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "M",
									children: "M — sedang"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "Q",
									children: "Q — tinggi"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
									value: "H",
									children: "H — sangat tinggi"
								})
							]
						}), logo ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-xs text-muted",
							children: "Logo memakai koreksi H otomatis."
						}) : null]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "secondary",
							className: "flex-1",
							asChild: true,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
								className: "cursor-pointer",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImagePlus, {}),
									"Logo",
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										type: "file",
										accept: "image/png,image/jpeg,image/webp,image/svg+xml",
										className: "sr-only",
										onChange: (e) => {
											const file = e.target.files?.[0];
											if (!file) return;
											const reader = new FileReader();
											reader.onload = () => setLogo(String(reader.result));
											reader.readAsDataURL(file);
										}
									})
								]
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							type: "button",
							variant: "ghost",
							size: "icon",
							"aria-label": "Reset",
							onClick: () => {
								setLogo(null);
								setFg("#12110e");
								setBg("#faf7f0");
								setSize(320);
								setMargin(2);
								setLevel("M");
							},
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, {})
						})]
					})
				]
			})]
		})]
	});
}
function Field({ label, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: label }), children]
	});
}
function QrPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteShell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mx-auto max-w-6xl space-y-10 px-4 py-10 sm:px-6 sm:py-16",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
				kicker: "01 · Studio",
				title: "QR Code",
				description: "Bangun kode untuk tautan, WiFi, WhatsApp, email, atau kartu nama. Pratinjau langsung, unduh PNG atau SVG."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(QrStudio, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "max-w-2xl rounded-2xl bg-secondary px-5 py-4 text-sm leading-relaxed text-muted",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-medium text-fg",
					children: "Cara pindai"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1",
					children: "Buka kamera HP, lalu arahkan ke kode. iPhone dan Android membaca QR tanpa aplikasi tambahan. Kalau kamera tidak menawarkan tautan, pakai Google Lens."
				})]
			})
		]
	}) });
}
//#endregion
export { QrPage as component };
