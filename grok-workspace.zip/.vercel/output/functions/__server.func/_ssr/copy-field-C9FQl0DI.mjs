import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { g as copyText } from "./tiktok.server-BNVcQmyB.mjs";
import { h as Copy, v as Check } from "../_libs/lucide-react.mjs";
import { o as Button } from "./router-CJOUtL5o.mjs";
import { t as Input } from "./input-CPYv1eDm.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/copy-field-C9FQl0DI.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function CopyField({ label, value, multiline = false }) {
	const [copied, setCopied] = (0, import_react.useState)(false);
	async function onCopy() {
		if (!await copyText(value)) return;
		setCopied(true);
		window.setTimeout(() => setCopied(false), 1400);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-2",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs font-medium tracking-wide text-muted uppercase",
				children: label
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				type: "button",
				variant: "ghost",
				size: "sm",
				onClick: onCopy,
				className: "h-8 px-2",
				children: [copied ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-3.5" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, { className: "size-3.5" }), copied ? "Tersalin" : "Salin"]
			})]
		}), multiline ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
			className: "overflow-x-auto rounded-md border border-border bg-bg px-3 py-2.5 font-mono text-xs leading-relaxed whitespace-pre-wrap",
			children: value
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
			readOnly: true,
			value,
			className: "font-mono text-xs"
		})]
	});
}
//#endregion
export { CopyField as t };
