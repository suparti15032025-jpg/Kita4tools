//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Dewr74T9.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/admin",
			"/media",
			"/privasi",
			"/qr",
			"/syarat",
			"/tiktok",
			"/upload",
			"/api/tiktok-file",
			"/api/upload",
			"/f/$id",
			"/v/$id",
			"/api/dl/$id",
			"/api/raw/$id"
		],
		preloads: [
			"/assets/index-DLQZO0jn.js",
			"/assets/rolldown-runtime-CbXtAM7H.js",
			"/assets/useStore-LOmwgNWu.js",
			"/assets/site-shell-CMHnmiol.js",
			"/assets/server-fns-DzyrjoQY.js",
			"/assets/not-found-i5RsCZif.js",
			"/assets/root-DLTE-HSj.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DLQZO0jn.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-DIl64Bs9.js"]
	},
	"/admin": {
		filePath: "/workspace/src/routes/admin.tsx",
		children: ["/admin/login", "/admin/"],
		preloads: ["/assets/admin-BDAbCJMp.js"]
	},
	"/media": {
		filePath: "/workspace/src/routes/media.tsx",
		children: void 0,
		preloads: [
			"/assets/media-BF2DZ-u5.js",
			"/assets/page-header-FQfrn3Ib.js",
			"/assets/copy-field-CSwu4KF1.js",
			"/assets/upload-client-CRA4JnKc.js"
		]
	},
	"/privasi": {
		filePath: "/workspace/src/routes/privasi.tsx",
		children: void 0,
		preloads: ["/assets/privasi-Dp6-2aA3.js", "/assets/page-header-FQfrn3Ib.js"]
	},
	"/qr": {
		filePath: "/workspace/src/routes/qr.tsx",
		children: void 0,
		preloads: [
			"/assets/qr-D2iZB9I_.js",
			"/assets/page-header-FQfrn3Ib.js",
			"/assets/download-CiskDY0i.js",
			"/assets/input-B_L-F6qf.js",
			"/assets/dist-dfNO8O1Z.js",
			"/assets/switch-BV7P1JY8.js",
			"/assets/label-B2nKPSzs.js",
			"/assets/dist-DfaaSzO2.js"
		]
	},
	"/syarat": {
		filePath: "/workspace/src/routes/syarat.tsx",
		children: void 0,
		preloads: ["/assets/syarat-DZi7ccld.js", "/assets/page-header-FQfrn3Ib.js"]
	},
	"/tiktok": {
		filePath: "/workspace/src/routes/tiktok.tsx",
		children: void 0,
		preloads: [
			"/assets/tiktok-BxYl87AL.js",
			"/assets/page-header-FQfrn3Ib.js",
			"/assets/download-CiskDY0i.js",
			"/assets/input-B_L-F6qf.js",
			"/assets/label-B2nKPSzs.js"
		]
	},
	"/upload": {
		filePath: "/workspace/src/routes/upload.tsx",
		children: void 0,
		preloads: [
			"/assets/upload-CPU44P0U.js",
			"/assets/page-header-FQfrn3Ib.js",
			"/assets/copy-field-CSwu4KF1.js",
			"/assets/upload-client-CRA4JnKc.js",
			"/assets/label-B2nKPSzs.js"
		]
	},
	"/admin/login": {
		filePath: "/workspace/src/routes/admin.login.tsx",
		children: void 0,
		preloads: [
			"/assets/admin.login-BSiLjcma.js",
			"/assets/input-B_L-F6qf.js",
			"/assets/label-B2nKPSzs.js"
		]
	},
	"/f/$id": {
		filePath: "/workspace/src/routes/f.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/f._id-BGcbsqVA.js",
			"/assets/report-dialog-BZfuKTYP.js",
			"/assets/download-CiskDY0i.js"
		]
	},
	"/v/$id": {
		filePath: "/workspace/src/routes/v.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/v._id-BuMGZ4vz.js",
			"/assets/report-dialog-BZfuKTYP.js",
			"/assets/copy-field-CSwu4KF1.js",
			"/assets/download-CiskDY0i.js"
		]
	},
	"/admin/": {
		filePath: "/workspace/src/routes/admin.index.tsx",
		children: void 0,
		preloads: [
			"/assets/admin.index-DS-1ymPL.js",
			"/assets/input-B_L-F6qf.js",
			"/assets/switch-BV7P1JY8.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
