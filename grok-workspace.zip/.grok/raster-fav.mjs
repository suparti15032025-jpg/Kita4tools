import { chromium } from "playwright";
import { readFileSync } from "fs";

const svg = readFileSync("/workspace/.grok/favicon.svg.tmp", "utf8");
const browser = await chromium.launch();

for (const size of [16, 32, 64, 192]) {
  const page = await browser.newPage({ viewport: { width: size, height: size }, deviceScaleFactor: 1 });
  await page.setContent(`<!doctype html><html><body style="margin:0;background:#888">
    ${svg.replace("<svg", `<svg id="m" width="${size}" height="${size}"`)}
  </body></html>`);
  await page.locator("#m").screenshot({ path: `/workspace/.grok/favicon-${size}.png`, omitBackground: false });
  await page.close();
}

await browser.close();
console.log("rasterized");
