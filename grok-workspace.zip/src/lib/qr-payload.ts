export type QrKind = "text" | "wifi" | "whatsapp" | "email" | "vcard";

export type QrFields = {
  text: string;
  wifiSsid: string;
  wifiPassword: string;
  wifiHidden: boolean;
  wifiType: "WPA" | "WEP" | "nopass";
  waPhone: string;
  waMessage: string;
  emailTo: string;
  emailSubject: string;
  emailBody: string;
  vName: string;
  vOrg: string;
  vPhone: string;
  vEmail: string;
  vUrl: string;
};

export const EMPTY_QR_FIELDS: QrFields = {
  text: "",
  wifiSsid: "",
  wifiPassword: "",
  wifiHidden: false,
  wifiType: "WPA",
  waPhone: "",
  waMessage: "",
  emailTo: "",
  emailSubject: "",
  emailBody: "",
  vName: "",
  vOrg: "",
  vPhone: "",
  vEmail: "",
  vUrl: "",
};

function escapeWifi(value: string) {
  return value.replace(/([\\;,:"])/g, "\\$1");
}

function digitsPhone(value: string) {
  const trimmed = value.trim();
  if (trimmed.startsWith("+")) return `+${trimmed.slice(1).replace(/\D/g, "")}`;
  return trimmed.replace(/\D/g, "");
}

export function buildQrPayload(kind: QrKind, fields: QrFields): string {
  switch (kind) {
    case "text":
      return fields.text.trim();
    case "wifi": {
      const t = fields.wifiType;
      const hidden = fields.wifiHidden ? "H:true;" : "";
      const pass = t === "nopass" ? "" : `P:${escapeWifi(fields.wifiPassword)};`;
      return `WIFI:T:${t};S:${escapeWifi(fields.wifiSsid)};${pass}${hidden};`;
    }
    case "whatsapp": {
      const phone = digitsPhone(fields.waPhone);
      const text = encodeURIComponent(fields.waMessage);
      const q = fields.waMessage.trim() ? `?text=${text}` : "";
      return phone ? `https://wa.me/${phone}${q}` : "";
    }
    case "email": {
      const to = fields.emailTo.trim();
      if (!to) return "";
      const params = new URLSearchParams();
      if (fields.emailSubject.trim()) params.set("subject", fields.emailSubject.trim());
      if (fields.emailBody.trim()) params.set("body", fields.emailBody.trim());
      const qs = params.toString();
      return `mailto:${to}${qs ? `?${qs}` : ""}`;
    }
    case "vcard": {
      const lines = [
        "BEGIN:VCARD",
        "VERSION:3.0",
        fields.vName.trim() ? `FN:${fields.vName.trim()}` : "",
        fields.vOrg.trim() ? `ORG:${fields.vOrg.trim()}` : "",
        fields.vPhone.trim() ? `TEL:${fields.vPhone.trim()}` : "",
        fields.vEmail.trim() ? `EMAIL:${fields.vEmail.trim()}` : "",
        fields.vUrl.trim() ? `URL:${fields.vUrl.trim()}` : "",
        "END:VCARD",
      ].filter(Boolean);
      return lines.length > 3 ? lines.join("\n") : "";
    }
  }
}
