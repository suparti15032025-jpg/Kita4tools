type Bucket = { times: number[] };

const g = globalThis as typeof globalThis & {
  __kitaRate?: Map<string, Bucket>;
};

function store() {
  g.__kitaRate ??= new Map();
  return g.__kitaRate;
}

export function clientIp(request: Request): string {
  const fwd = request.headers.get("x-forwarded-for");
  if (fwd) return fwd.split(",")[0]?.trim() || "unknown";
  return request.headers.get("x-real-ip") ?? "unknown";
}

export function rateLimit(
  key: string,
  limit: number,
  windowMs: number,
): { ok: true } | { ok: false; retryAfterSec: number } {
  const now = Date.now();
  const buckets = store();
  const bucket = buckets.get(key) ?? { times: [] };
  bucket.times = bucket.times.filter((t) => now - t < windowMs);
  if (bucket.times.length >= limit) {
    const oldest = bucket.times[0] ?? now;
    const retryAfterSec = Math.max(1, Math.ceil((oldest + windowMs - now) / 1000));
    buckets.set(key, bucket);
    return { ok: false, retryAfterSec };
  }
  bucket.times.push(now);
  buckets.set(key, bucket);
  return { ok: true };
}
