import { createServerFn } from "@tanstack/react-start";
import { getRequest, setResponseHeader } from "@tanstack/react-start/server";
import { z } from "zod";
import { RATE, REPORT_REASONS } from "@/lib/config";
import {
  deleteFile,
  getFileMeta,
  listFiles,
  purgeExpired,
  reportFile,
} from "@/lib/files.server";
import {
  adminCookieHeader,
  checkAdminPassword,
  clearAdminCookieHeader,
  isAdminRequest,
  signAdminToken,
} from "@/lib/admin.server";
import { clientIp, rateLimit } from "@/lib/rate-limit.server";
import { isTikTokUrl, resolveTikTok } from "@/lib/tiktok.server";

const reasonIds = REPORT_REASONS.map((r) => r.id) as [string, ...string[]];

export const getPublicFile = createServerFn({ method: "GET" })
  .validator(z.object({ id: z.string().min(1).max(64) }))
  .handler(async ({ data }) => {
    await purgeExpired();
    return getFileMeta(data.id);
  });

export const submitReport = createServerFn({ method: "POST" })
  .validator(
    z.object({
      id: z.string().min(1).max(64),
      reason: z.string().min(1).max(40),
    }),
  )
  .handler(async ({ data }) => {
    if (!reasonIds.includes(data.reason)) {
      throw new Error("Alasan tidak valid.");
    }
    const request = getRequest();
    const ip = clientIp(request);
    const rl = rateLimit(`report:${ip}`, RATE.report.limit, RATE.report.windowMs);
    if (!rl.ok) {
      throw new Error("Terlalu banyak laporan. Coba lagi nanti.");
    }
    const ok = await reportFile(data.id, data.reason);
    if (!ok) throw new Error("Berkas tidak ditemukan.");
    return { ok: true };
  });

export const inspectTikTok = createServerFn({ method: "POST" })
  .validator(z.object({ url: z.string().min(8).max(500) }))
  .handler(async ({ data }) => {
    const request = getRequest();
    const ip = clientIp(request);
    const rl = rateLimit(`tiktok:${ip}`, RATE.tiktok.limit, RATE.tiktok.windowMs);
    if (!rl.ok) {
      throw new Error(`Terlalu banyak permintaan. Coba lagi dalam ${rl.retryAfterSec} detik.`);
    }
    if (!isTikTokUrl(data.url)) {
      throw new Error("Masukkan tautan TikTok yang valid, termasuk vm.tiktok.com.");
    }
    try {
      return await resolveTikTok(data.url);
    } catch (err) {
      const message =
        err instanceof Error && err.message && !/unknown error/i.test(err.message)
          ? err.message
          : "Tidak bisa mengambil video. Pastikan tautan publik, lalu coba lagi.";
      throw new Error(message);
    }
  });

function requireAdmin() {
  const request = getRequest();
  if (!isAdminRequest(request)) {
    throw new Error("Tidak diizinkan.");
  }
}

export const adminSession = createServerFn({ method: "GET" }).handler(async () => {
  const request = getRequest();
  return { ok: isAdminRequest(request) };
});

export const adminLogin = createServerFn({ method: "POST" })
  .validator(z.object({ password: z.string().min(1).max(200) }))
  .handler(async ({ data }) => {
    const request = getRequest();
    const ip = clientIp(request);
    const rl = rateLimit(`admin:${ip}`, RATE.admin.limit, RATE.admin.windowMs);
    if (!rl.ok) {
      throw new Error("Terlalu banyak percobaan. Tunggu sebentar.");
    }
    if (!checkAdminPassword(data.password)) {
      throw new Error("Sandi salah.");
    }
    setResponseHeader("set-cookie", adminCookieHeader(signAdminToken()));
    return { ok: true };
  });

export const adminLogout = createServerFn({ method: "POST" }).handler(async () => {
  setResponseHeader("set-cookie", clearAdminCookieHeader());
  return { ok: true };
});

export const adminListFiles = createServerFn({ method: "GET" })
  .validator(
    z.object({
      q: z.string().max(120).optional(),
      reportedOnly: z.boolean().optional(),
      page: z.number().int().min(1).max(200).optional(),
    }),
  )
  .handler(async ({ data }) => {
    requireAdmin();
    const page = data.page ?? 1;
    const limit = 20;
    return listFiles({
      q: data.q,
      reportedOnly: data.reportedOnly,
      limit,
      offset: (page - 1) * limit,
    });
  });

export const adminDeleteFile = createServerFn({ method: "POST" })
  .validator(z.object({ id: z.string().min(1).max(64) }))
  .handler(async ({ data }) => {
    requireAdmin();
    const ok = await deleteFile(data.id);
    if (!ok) throw new Error("Berkas tidak ditemukan.");
    return { ok: true };
  });
