import { fileExtension } from "@/lib/utils";
import {
  bumpDownload,
  contentDisposition,
  shouldInline,
  streamFileData,
} from "@/lib/files.server";

export async function serveStoredFile(
  id: string,
  mode: "inline" | "attachment",
): Promise<Response> {
  const blob = await streamFileData(id);
  if (!blob) {
    return Response.json(
      { error: "Berkas tidak ditemukan atau sudah kedaluwarsa." },
      { status: 404 },
    );
  }
  await bumpDownload(id);
  const ext = fileExtension(blob.meta.originalName);
  const inline = mode === "inline" && shouldInline(blob.meta.kind, ext);
  const disposition = contentDisposition(
    blob.meta.originalName,
    inline ? "inline" : "attachment",
  );
  const headers: Record<string, string> = {
    "content-type": blob.meta.mimeType,
    "content-disposition": disposition,
    "x-content-type-options": "nosniff",
    "cache-control": "private, max-age=3600",
    "content-length": String(blob.meta.sizeBytes),
  };
  return new Response(blob.body, { headers });
}
