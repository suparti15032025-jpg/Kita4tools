import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

export function formatBytes(bytes: number): string {
  if (!Number.isFinite(bytes) || bytes < 0) return "0 B";
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

export function sanitizeFileName(name: string): string {
  const base = name.replace(/\\/g, "/").split("/").pop() ?? "berkas";
  return base.replace(/[\u0000-\u001f\u007f]/g, "").slice(0, 180) || "berkas";
}

export function fileExtension(name: string): string {
  const clean = sanitizeFileName(name);
  const i = clean.lastIndexOf(".");
  if (i <= 0) return "";
  return clean.slice(i + 1).toLowerCase();
}

export async function copyText(text: string): Promise<boolean> {
  try {
    await navigator.clipboard.writeText(text);
    return true;
  } catch {
    try {
      const el = document.createElement("textarea");
      el.value = text;
      el.setAttribute("readonly", "");
      el.style.position = "fixed";
      el.style.left = "-9999px";
      document.body.appendChild(el);
      el.select();
      const ok = document.execCommand("copy");
      document.body.removeChild(el);
      return ok;
    } catch {
      return false;
    }
  }
}

export function humanizeServerError(err: unknown, fallback: string): string {
  let raw = "";
  if (err instanceof Error) raw = err.message;
  else if (typeof err === "string") raw = err;
  const trimmed = raw.trim();
  if (!trimmed) return fallback;
  if (trimmed.startsWith("{")) {
    try {
      const parsed = JSON.parse(trimmed) as { errorMessage?: string; message?: string; error?: string };
      const nested = parsed.errorMessage || parsed.message || parsed.error || "";
      if (nested && !/unknown error/i.test(nested)) return nested;
      return fallback;
    } catch {
      /* not json */
    }
  }
  if (/unknown error/i.test(trimmed) || trimmed.includes("errorType")) return fallback;
  return trimmed;
}
