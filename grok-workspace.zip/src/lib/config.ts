export const APP_NAME = "Kita";
export const APP_TAGLINE = "Semua alat, satu tempat.";

export const MAX_MEDIA_BYTES = 30 * 1024 * 1024;
export const MAX_FILE_BYTES = 150 * 1024 * 1024;
export const UPLOAD_CHUNK_BYTES = 1536 * 1024;
export const MAX_FILES_PER_BATCH = 8;

export function formatMbLimit(bytes: number): string {
  return `${Math.round(bytes / (1024 * 1024))} MB`;
}

export const BLOCKED_EXTENSIONS = new Set([
  "php",
  "phtml",
  "php3",
  "php4",
  "php5",
  "phar",
  "sh",
  "bash",
  "zsh",
  "csh",
  "jsp",
  "jspx",
  "asp",
  "aspx",
  "cgi",
  "htaccess",
  "htpasswd",
  "py",
  "rb",
  "pl",
  "exe",
  "bat",
  "cmd",
  "ps1",
  "com",
  "dll",
  "so",
]);

export const IMAGE_EXT = new Set(["jpg", "jpeg", "png", "gif", "webp"]);
export const VIDEO_EXT = new Set(["mp4", "webm", "mov"]);
export const INLINE_EXT = new Set([...IMAGE_EXT, ...VIDEO_EXT]);

export const IMAGE_MIME = new Set([
  "image/jpeg",
  "image/png",
  "image/gif",
  "image/webp",
]);
export const VIDEO_MIME = new Set([
  "video/mp4",
  "video/webm",
  "video/quicktime",
]);

export const APK_MIME = "application/vnd.android.package-archive";

export const EXPIRY_OPTIONS = [
  { id: "1h", label: "1 jam", ms: 60 * 60 * 1000 },
  { id: "1d", label: "1 hari", ms: 24 * 60 * 60 * 1000 },
  { id: "7d", label: "7 hari", ms: 7 * 24 * 60 * 60 * 1000 },
  { id: "30d", label: "30 hari", ms: 30 * 24 * 60 * 60 * 1000 },
  { id: "forever", label: "Permanen", ms: null },
] as const;

export type ExpiryId = (typeof EXPIRY_OPTIONS)[number]["id"];

export const REPORT_REASONS = [
  { id: "spam", label: "Spam atau iklan" },
  { id: "malware", label: "Malware / berbahaya" },
  { id: "copyright", label: "Melanggar hak cipta" },
  { id: "illegal", label: "Konten ilegal" },
  { id: "other", label: "Lainnya" },
] as const;

export const ADMIN_COOKIE = "kita_admin";
export const ADMIN_PASSWORD_DEFAULT = "kita-admin";

export const RATE = {
  upload: { limit: 40, windowMs: 60 * 60 * 1000 },
  chunk: { limit: 400, windowMs: 60 * 60 * 1000 },
  tiktok: { limit: 24, windowMs: 60 * 60 * 1000 },
  report: { limit: 12, windowMs: 60 * 60 * 1000 },
  admin: { limit: 12, windowMs: 15 * 60 * 1000 },
};

export const TOOLS = [
  {
    slug: "qr",
    index: "01",
    href: "/qr",
    short: "QR",
    title: "QR Code",
    blurb: "Teks, WiFi, WhatsApp, email, dan vCard. Logo di tengah, unduh PNG atau SVG.",
  },
  {
    slug: "media",
    index: "02",
    href: "/media",
    short: "Media",
    title: "Tautan media",
    blurb: "Unggah gambar atau video, dapatkan tautan langsung, halaman pratinjau, dan kode embed.",
  },
  {
    slug: "tiktok",
    index: "03",
    href: "/tiktok",
    short: "TikTok",
    title: "Unduh TikTok",
    blurb: "Ambil video tanpa watermark, audio MP3, atau foto slideshow dari tautan TikTok.",
  },
  {
    slug: "upload",
    index: "04",
    href: "/upload",
    short: "Berkas",
    title: "Berkas publik",
    blurb: "APK, ZIP, PDF, dan berkas lain jadi tautan unik. Atur masa aktif, unduh lewat halaman rapi.",
  },
] as const;
