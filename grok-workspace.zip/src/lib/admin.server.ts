import { createHmac, randomBytes, timingSafeEqual } from "node:crypto";
import { ADMIN_COOKIE, ADMIN_PASSWORD_DEFAULT } from "@/lib/config";

function secret() {
  return process.env.ADMIN_SECRET?.trim() || "kita-preview-admin-secret";
}

function password() {
  return process.env.ADMIN_PASSWORD?.trim() || ADMIN_PASSWORD_DEFAULT;
}

export function checkAdminPassword(input: string): boolean {
  const expected = password();
  const a = Buffer.from(input);
  const b = Buffer.from(expected);
  if (a.length !== b.length) {
    timingSafeEqual(a.length > b.length ? a : Buffer.concat([a, a]), a.length > b.length ? a : Buffer.concat([a, a]));
    return false;
  }
  return timingSafeEqual(a, b);
}

export function signAdminToken(): string {
  const nonce = randomBytes(12).toString("base64url");
  const exp = Date.now() + 12 * 60 * 60 * 1000;
  const payload = `${nonce}.${exp}`;
  const sig = createHmac("sha256", secret()).update(payload).digest("base64url");
  return `${payload}.${sig}`;
}

export function verifyAdminToken(token: string | undefined | null): boolean {
  if (!token) return false;
  const parts = token.split(".");
  if (parts.length !== 3) return false;
  const [nonce, expStr, sig] = parts;
  if (!nonce || !expStr || !sig) return false;
  const exp = Number(expStr);
  if (!Number.isFinite(exp) || Date.now() > exp) return false;
  const payload = `${nonce}.${expStr}`;
  const expected = createHmac("sha256", secret()).update(payload).digest("base64url");
  const a = Buffer.from(sig);
  const b = Buffer.from(expected);
  if (a.length !== b.length) return false;
  return timingSafeEqual(a, b);
}

export function adminCookieHeader(token: string): string {
  return `${ADMIN_COOKIE}=${token}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${12 * 60 * 60}`;
}

export function clearAdminCookieHeader(): string {
  return `${ADMIN_COOKIE}=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0`;
}

export function readAdminCookie(request: Request): string | null {
  const raw = request.headers.get("cookie") ?? "";
  for (const part of raw.split(";")) {
    const [k, ...rest] = part.trim().split("=");
    if (k === ADMIN_COOKIE) return rest.join("=") || null;
  }
  return null;
}

export function isAdminRequest(request: Request): boolean {
  return verifyAdminToken(readAdminCookie(request));
}
