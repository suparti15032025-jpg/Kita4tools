import type { TikTokInfo } from "@/lib/files-shared";

const TIKTOK_RE =
  /^(https?:\/\/)?((www|vm|vt|m)\.)?tiktok\.com\/.+/i;

const UA =
  "Mozilla/5.0 (iPhone; CPU iPhone OS 17_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Mobile/15E148 Safari/604.1";

export function isTikTokUrl(raw: string): boolean {
  try {
    const u = new URL(raw.trim());
    const host = u.hostname.replace(/^www\./, "");
    return (
      host === "tiktok.com" ||
      host.endsWith(".tiktok.com") ||
      host === "vm.tiktok.com" ||
      host === "vt.tiktok.com"
    );
  } catch {
    return TIKTOK_RE.test(raw.trim());
  }
}

function normalizeUrl(raw: string): string {
  const t = raw.trim();
  if (!/^https?:\/\//i.test(t)) return `https://${t}`;
  return t;
}

function absUrl(value: string | undefined): string {
  if (!value) return "";
  if (value.startsWith("//")) return `https:${value}`;
  if (value.startsWith("http")) return value;
  return `https://www.tikwm.com${value.startsWith("/") ? "" : "/"}${value}`;
}

function pickPlay(video: Record<string, unknown> | undefined): string {
  if (!video) return "";
  const keys = ["playAddr", "downloadAddr", "play_addr", "download_addr"];
  for (const key of keys) {
    const val = video[key];
    if (typeof val === "string" && val) return val;
    if (val && typeof val === "object") {
      const rec = val as { url_list?: string[]; urlList?: string[] };
      const list = rec.url_list || rec.urlList;
      if (Array.isArray(list) && list[0]) return String(list[0]);
    }
  }
  return "";
}

type TikwmPayload = {
  code?: number;
  msg?: string;
  data?: {
    id?: string;
    title?: string;
    cover?: string;
    origin_cover?: string;
    duration?: number;
    play?: string;
    hdplay?: string;
    wmplay?: string;
    music?: string;
    images?: string[];
    author?: {
      unique_id?: string;
      nickname?: string;
      id?: string;
    };
  };
};

function mapTikwm(data: NonNullable<TikwmPayload["data"]>, fallbackId: string): TikTokInfo {
  const images = Array.isArray(data.images)
    ? data.images.filter(Boolean).map((url, index) => ({ url: absUrl(url), index }))
    : [];
  const play = data.play ? absUrl(data.play) : "";
  const hd = data.hdplay ? absUrl(data.hdplay) : "";
  return {
    id: String(data.id ?? fallbackId),
    title: (data.title || "Video TikTok").trim(),
    author: data.author?.nickname || data.author?.unique_id || "Tidak diketahui",
    authorId: data.author?.unique_id || data.author?.id || "",
    cover: absUrl(data.origin_cover || data.cover),
    duration: typeof data.duration === "number" ? data.duration : null,
    videoUrl: play || hd || null,
    videoHdUrl: hd || play || null,
    musicUrl: data.music ? absUrl(data.music) : null,
    images,
  };
}

async function fetchJson(url: string, init?: RequestInit, timeoutMs = 7000): Promise<unknown> {
  const res = await fetch(url, {
    ...init,
    headers: {
      accept: "application/json, text/plain, */*",
      "user-agent": UA,
      ...(init?.headers ?? {}),
    },
    signal: AbortSignal.timeout(timeoutMs),
  });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  const text = await res.text();
  try {
    return JSON.parse(text);
  } catch {
    throw new Error("Respons bukan JSON.");
  }
}

async function fromTikwm(url: string): Promise<TikTokInfo> {
  const json = (await fetchJson(
    `https://www.tikwm.com/api/?url=${encodeURIComponent(url)}&hd=1`,
  )) as TikwmPayload;
  if (json?.code === 0 && json.data) return mapTikwm(json.data, url);
  throw new Error(json?.msg || "tikwm gagal");
}

type Tikly = {
  title?: string;
  video?: { noWatermark?: string; watermark?: string };
  music?: { play_url?: string; url?: string };
  author?: { nickname?: string; username?: string };
  images?: string[];
  thumbnail?: string;
  cover?: string;
  id?: string;
};

async function fromTikly(url: string): Promise<TikTokInfo> {
  const json = (await fetchJson(
    `https://api.tiklydown.eu.org/api/download?url=${encodeURIComponent(url)}`,
  )) as Tikly;
  const videoUrl = json.video?.noWatermark || json.video?.watermark || null;
  const images = Array.isArray(json.images)
    ? json.images.filter(Boolean).map((u, index) => ({ url: absUrl(u), index }))
    : [];
  if (!videoUrl && images.length === 0) {
    throw new Error("API cadangan tidak mengembalikan media.");
  }
  return {
    id: String(json.id ?? url),
    title: (json.title || "Video TikTok").trim(),
    author: json.author?.nickname || json.author?.username || "Tidak diketahui",
    authorId: json.author?.username || "",
    cover: absUrl(json.cover || json.thumbnail),
    duration: null,
    videoUrl,
    videoHdUrl: json.video?.noWatermark || videoUrl,
    musicUrl: json.music?.play_url || json.music?.url || null,
    images,
  };
}

function parseTikTokHtml(html: string, pageUrl: string): TikTokInfo | null {
  const uni = html.match(
    /<script id="__UNIVERSAL_DATA_FOR_REHYDRATION__"[^>]*>([^<]+)<\/script>/,
  );
  let item: Record<string, unknown> | null = null;
  if (uni?.[1]) {
    try {
      const json = JSON.parse(uni[1]) as {
        __DEFAULT_SCOPE__?: Record<string, { itemInfo?: { itemStruct?: Record<string, unknown> } }>;
      };
      item = json.__DEFAULT_SCOPE__?.["webapp.video-detail"]?.itemInfo?.itemStruct ?? null;
    } catch {
      item = null;
    }
  }
  if (!item) {
    const sigi = html.match(/<script id="SIGI_STATE"[^>]*>([^<]+)<\/script>/);
    if (sigi?.[1]) {
      try {
        const json = JSON.parse(sigi[1]) as {
          ItemModule?: Record<string, Record<string, unknown>>;
        };
        const first = json.ItemModule && Object.values(json.ItemModule)[0];
        if (first) item = first;
      } catch {
        item = null;
      }
    }
  }
  if (!item) return null;
  const video = item.video as Record<string, unknown> | undefined;
  const author = item.author as { uniqueId?: string; nickname?: string } | undefined;
  const music = item.music as { playUrl?: unknown } | undefined;
  const imagePost = item.imagePost as { images?: Array<{ imageURL?: { urlList?: string[] } }> } | undefined;
  const play = pickPlay(video);
  const images = (imagePost?.images ?? [])
    .map((img, index) => ({ url: img.imageURL?.urlList?.[0] ?? "", index }))
    .filter((img) => img.url);
  if (!play && images.length === 0) return null;
  const coverObj = video?.cover as { url_list?: string[]; urlList?: string[] } | string | undefined;
  let cover = "";
  if (typeof coverObj === "string") cover = coverObj;
  else if (coverObj?.url_list?.[0]) cover = coverObj.url_list[0];
  else if (coverObj?.urlList?.[0]) cover = coverObj.urlList[0];
  let musicUrl: string | null = null;
  const mu = music?.playUrl;
  if (typeof mu === "string") musicUrl = mu;
  else if (mu && typeof mu === "object") {
    const rec = mu as { url_list?: string[] };
    if (rec.url_list?.[0]) musicUrl = rec.url_list[0];
  }
  const idMatch = pageUrl.match(/(\d{8,})/);
  return {
    id: String(item.id ?? idMatch?.[1] ?? pageUrl),
    title: String(item.desc || "Video TikTok").trim(),
    author: author?.nickname || author?.uniqueId || "Tidak diketahui",
    authorId: author?.uniqueId || "",
    cover,
    duration: typeof video?.duration === "number" ? video.duration : null,
    videoUrl: play || null,
    videoHdUrl: play || null,
    musicUrl,
    images,
  };
}

async function fromOfficialPage(url: string): Promise<TikTokInfo> {
  const res = await fetch(url, {
    headers: {
      "user-agent": UA,
      accept: "text/html,application/xhtml+xml",
    },
    redirect: "follow",
    signal: AbortSignal.timeout(8000),
  });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  const html = await res.text();
  const parsed = parseTikTokHtml(html, res.url || url);
  if (!parsed) throw new Error("Halaman TikTok tidak berisi media publik.");
  return parsed;
}

export async function resolveTikTok(raw: string): Promise<TikTokInfo> {
  const url = normalizeUrl(raw);
  if (!isTikTokUrl(url)) {
    throw new Error("Tautan bukan URL TikTok yang valid.");
  }
  const tasks: Array<() => Promise<TikTokInfo>> = [
    () => fromTikwm(url),
    () => fromOfficialPage(url),
    () => fromTikly(url),
  ];
  try {
    return await Promise.any(tasks.map((fn) => fn()));
  } catch {
    throw new Error(
      "Tidak bisa mengambil video. Pastikan tautan publik (bukan akun privat), coba tautan lengkap tiktok.com/@akun/video/…, lalu ulangi.",
    );
  }
}

export function safeRemoteUrl(url: string): boolean {
  try {
    const u = new URL(url);
    return u.protocol === "https:" || u.protocol === "http:";
  } catch {
    return false;
  }
}
