import { UPLOAD_CHUNK_BYTES } from "@/lib/config";
import type { UploadResult } from "@/lib/files-shared";

function sendForm(
  fields: Record<string, string>,
  file?: { field: string; blob: Blob; name: string },
  onProgress?: (loaded: number, total: number) => void,
): Promise<Record<string, unknown>> {
  return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.open("POST", "/api/upload");
    xhr.responseType = "json";
    xhr.upload.onprogress = (event) => {
      if (onProgress && event.lengthComputable) onProgress(event.loaded, event.total);
    };
    xhr.onload = () => {
      const body = (xhr.response ?? {}) as { error?: string };
      if (typeof xhr.response === "string") {
        try {
          Object.assign(body, JSON.parse(xhr.response));
        } catch {
          /* ignore */
        }
      }
      if (xhr.status >= 200 && xhr.status < 300) {
        resolve(body as Record<string, unknown>);
        return;
      }
      reject(new Error(body.error || `Unggah gagal (${xhr.status}).`));
    };
    xhr.onerror = () => reject(new Error("Koneksi terputus saat mengunggah."));
    xhr.onabort = () => reject(new Error("Unggah dibatalkan."));
    const fd = new FormData();
    for (const [key, value] of Object.entries(fields)) fd.append(key, value);
    if (file) fd.append(file.field, file.blob, file.name);
    xhr.send(fd);
  });
}

async function sendFormRetry(
  fields: Record<string, string>,
  file?: { field: string; blob: Blob; name: string },
  onProgress?: (loaded: number, total: number) => void,
): Promise<Record<string, unknown>> {
  let last: Error | null = null;
  for (let attempt = 0; attempt < 3; attempt += 1) {
    try {
      return await sendForm(fields, file, onProgress);
    } catch (err) {
      last = err instanceof Error ? err : new Error("Unggah gagal.");
      const fatal = /tidak diizinkan|terlalu besar|tidak valid|kosong|hanya gambar/i.test(last.message);
      if (fatal || attempt === 2) throw last;
      await new Promise((r) => setTimeout(r, 400 * (attempt + 1)));
    }
  }
  throw last ?? new Error("Unggah gagal.");
}

export async function xhrUpload(
  file: File,
  fields: Record<string, string>,
  onProgress: (pct: number) => void,
): Promise<UploadResult> {
  const chunkCount = Math.max(1, Math.ceil(file.size / UPLOAD_CHUNK_BYTES));
  const init = await sendFormRetry({
    step: "init",
    name: file.name,
    size: String(file.size),
    mime: file.type,
    chunkCount: String(chunkCount),
    ...fields,
  });
  const id = String(init.id || "");
  if (!id) throw new Error("Gagal memulai unggahan.");

  for (let i = 0; i < chunkCount; i += 1) {
    const start = i * UPLOAD_CHUNK_BYTES;
    const blob = file.slice(start, start + UPLOAD_CHUNK_BYTES);
    await sendFormRetry(
      { step: "chunk", id, index: String(i) },
      { field: "chunk", blob, name: `chunk-${i}` },
      (loaded, total) => {
        const done = start + loaded;
        const pct = Math.max(0, Math.min(99, Math.round((done / Math.max(file.size, total)) * 100)));
        onProgress(pct);
      },
    );
  }

  const done = await sendFormRetry({ step: "complete", id });
  onProgress(100);
  if (!done.file) throw new Error("Gagal menyelesaikan unggahan.");
  return done as unknown as UploadResult;
}
