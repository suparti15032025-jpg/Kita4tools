import { randomBytes } from "node:crypto";
import { getSql } from "@/lib/db";
import {
  APK_MIME,
  BLOCKED_EXTENSIONS,
  IMAGE_EXT,
  IMAGE_MIME,
  INLINE_EXT,
  MAX_FILE_BYTES,
  MAX_MEDIA_BYTES,
  VIDEO_EXT,
  VIDEO_MIME,
} from "@/lib/config";
import type { FileKind, FileMeta } from "@/lib/files-shared";
import { fileExtension, sanitizeFileName } from "@/lib/utils";

type FileRow = {
  id: string;
  original_name: string;
  stored_name: string;
  mime_type: string;
  size_bytes: number;
  kind: string;
  download_count: number;
  expires_at: string | Date | null;
  created_at: string | Date;
  reported: boolean;
  status?: string;
  chunk_count?: number;
};

function toIso(value: string | Date | null | undefined): string | null {
  if (value == null) return null;
  if (value instanceof Date) return value.toISOString();
  const d = new Date(value);
  return Number.isNaN(d.getTime()) ? String(value) : d.toISOString();
}

export function mapFile(row: FileRow): FileMeta {
  return {
    id: row.id,
    originalName: row.original_name,
    mimeType: row.mime_type,
    sizeBytes: Number(row.size_bytes),
    kind: row.kind as FileKind,
    downloadCount: Number(row.download_count),
    expiresAt: toIso(row.expires_at),
    createdAt: toIso(row.created_at) ?? new Date().toISOString(),
    reported: Boolean(row.reported),
  };
}

const META_COLS = `id, original_name, stored_name, mime_type, size_bytes, kind, download_count, expires_at, created_at, reported`;

export function newFileId(): string {
  return randomBytes(10).toString("base64url");
}

export function inferKind(name: string, mime: string): FileKind {
  const ext = fileExtension(name);
  if (IMAGE_EXT.has(ext) || IMAGE_MIME.has(mime)) return "image";
  if (VIDEO_EXT.has(ext) || VIDEO_MIME.has(mime)) return "video";
  return "file";
}

export function inferMime(name: string, mime: string): string {
  const ext = fileExtension(name);
  if (ext === "apk") return APK_MIME;
  if (mime && mime !== "application/octet-stream") return mime;
  const map: Record<string, string> = {
    jpg: "image/jpeg",
    jpeg: "image/jpeg",
    png: "image/png",
    gif: "image/gif",
    webp: "image/webp",
    mp4: "video/mp4",
    webm: "video/webm",
    mov: "video/quicktime",
    pdf: "application/pdf",
    zip: "application/zip",
    apk: APK_MIME,
  };
  return map[ext] ?? "application/octet-stream";
}

export function maxBytesForMode(mode: "media" | "file"): number {
  return mode === "media" ? MAX_MEDIA_BYTES : MAX_FILE_BYTES;
}

export function validateUpload(opts: {
  name: string;
  size: number;
  mime: string;
  mode: "media" | "file";
}): { ok: true; kind: FileKind; mime: string; name: string } | { ok: false; error: string } {
  const name = sanitizeFileName(opts.name);
  const ext = fileExtension(name);
  if (BLOCKED_EXTENSIONS.has(ext)) {
    return { ok: false, error: "Ekstensi berkas ini tidak diizinkan." };
  }
  if (opts.size <= 0) return { ok: false, error: "Berkas kosong." };
  const cap = maxBytesForMode(opts.mode);
  if (opts.size > cap) {
    return {
      ok: false,
      error: `Berkas terlalu besar. Maksimal ${Math.round(cap / (1024 * 1024))} MB.`,
    };
  }
  const mime = inferMime(name, opts.mime);
  const kind = inferKind(name, mime);
  if (opts.mode === "media" && kind === "file") {
    return {
      ok: false,
      error: "Hanya gambar (JPG, PNG, GIF, WEBP) dan video (MP4, WEBM, MOV).",
    };
  }
  return { ok: true, kind, mime, name };
}

async function ensureFileSchema(): Promise<void> {
  const sql = await getSql();
  await sql.query("alter table files add column if not exists status text not null default 'ready'");
  await sql.query("alter table files add column if not exists chunk_count integer not null default 0");
  await sql.query("alter table files alter column data drop not null");
  await sql.query(`create table if not exists file_chunks (
    file_id text not null,
    chunk_index integer not null,
    data bytea not null,
    primary key (file_id, chunk_index)
  )`);
}

function toBytes(data: unknown): Uint8Array {
  if (data instanceof Uint8Array) return data;
  if (typeof Buffer !== "undefined" && Buffer.isBuffer(data)) {
    return new Uint8Array(data);
  }
  if (typeof data === "string") {
    if (data.startsWith("\\x")) {
      const hex = data.slice(2);
      const out = new Uint8Array(hex.length / 2);
      for (let i = 0; i < out.length; i += 1) {
        out[i] = Number.parseInt(hex.slice(i * 2, i * 2 + 2), 16);
      }
      return out;
    }
    return Uint8Array.from(atob(data), (c) => c.charCodeAt(0));
  }
  if (data && typeof data === "object" && "data" in (data as object)) {
    const arr = (data as { data: number[] }).data;
    return Uint8Array.from(arr);
  }
  throw new Error("Tidak bisa membaca data berkas.");
}

export async function purgeExpired(): Promise<void> {
  await ensureFileSchema();
  const sql = await getSql();
  await sql.query(
    `delete from file_chunks where file_id in (
      select id from files where (expires_at is not null and expires_at < now())
      or (status = 'pending' and created_at < now() - interval '1 hour')
    )`,
  );
  await sql.query("delete from files where expires_at is not null and expires_at < now()");
  await sql.query(
    "delete from files where status = 'pending' and created_at < now() - interval '1 hour'",
  );
}

export async function createPendingFile(opts: {
  originalName: string;
  mime: string;
  kind: FileKind;
  size: number;
  chunkCount: number;
  expiresAt: Date | null;
}): Promise<FileMeta> {
  const sql = await getSql();
  const id = newFileId();
  const ext = fileExtension(opts.originalName);
  const stored = ext ? `${id}.${ext}` : id;
  const rows = await sql.query<FileRow>(
    `insert into files (id, original_name, stored_name, mime_type, size_bytes, kind, data, expires_at, status, chunk_count)
     values ($1,$2,$3,$4,$5,$6,null,$7,'pending',$8)
     returning ${META_COLS}`,
    [
      id,
      opts.originalName,
      stored,
      opts.mime,
      opts.size,
      opts.kind,
      opts.expiresAt,
      opts.chunkCount,
    ],
  );
  const row = rows[0];
  if (!row) throw new Error("Gagal menyimpan berkas.");
  return mapFile(row);
}

export async function putFileChunk(id: string, index: number, bytes: Uint8Array): Promise<void> {
  const sql = await getSql();
  const rows = await sql.query<{ id: string; chunk_count: number; status: string }>(
    "select id, chunk_count, status from files where id = $1",
    [id],
  );
  const row = rows[0];
  if (!row || row.status !== "pending") {
    throw new Error("Sesi unggahan tidak valid. Unggah ulang.");
  }
  if (index < 0 || index >= Number(row.chunk_count)) {
    throw new Error("Potongan unggahan tidak valid.");
  }
  await sql.query(
    `insert into file_chunks (file_id, chunk_index, data) values ($1,$2,$3)
     on conflict (file_id, chunk_index) do update set data = excluded.data`,
    [id, index, bytes],
  );
}

export async function finalizeFile(id: string): Promise<FileMeta> {
  const sql = await getSql();
  const rows = await sql.query<FileRow & { chunk_count: number; status: string }>(
    `select ${META_COLS}, chunk_count, status from files where id = $1`,
    [id],
  );
  const row = rows[0];
  if (!row || row.status !== "pending") {
    throw new Error("Sesi unggahan tidak valid. Unggah ulang.");
  }
  const stats = await sql.query<{ n: number; bytes: number }>(
    `select count(*)::int as n, coalesce(sum(octet_length(data)), 0)::bigint as bytes
     from file_chunks where file_id = $1`,
    [id],
  );
  const n = Number(stats[0]?.n ?? 0);
  const bytes = Number(stats[0]?.bytes ?? 0);
  if (n !== Number(row.chunk_count)) {
    throw new Error("Unggahan belum lengkap. Coba lagi.");
  }
  const updated = await sql.query<FileRow>(
    `update files set status = 'ready', size_bytes = $2 where id = $1 returning ${META_COLS}`,
    [id, bytes],
  );
  const ready = updated[0];
  if (!ready) throw new Error("Gagal menyelesaikan unggahan.");
  return mapFile(ready);
}

export async function insertFile(opts: {
  originalName: string;
  mime: string;
  kind: FileKind;
  bytes: Uint8Array;
  expiresAt: Date | null;
}): Promise<FileMeta> {
  const sql = await getSql();
  const id = newFileId();
  const ext = fileExtension(opts.originalName);
  const stored = ext ? `${id}.${ext}` : id;
  const rows = await sql.query<FileRow>(
    `insert into files (id, original_name, stored_name, mime_type, size_bytes, kind, data, expires_at, status, chunk_count)
     values ($1,$2,$3,$4,$5,$6,$7,$8,'ready',0)
     returning ${META_COLS}`,
    [
      id,
      opts.originalName,
      stored,
      opts.mime,
      opts.bytes.byteLength,
      opts.kind,
      opts.bytes,
      opts.expiresAt,
    ],
  );
  const row = rows[0];
  if (!row) throw new Error("Gagal menyimpan berkas.");
  return mapFile(row);
}

export async function getFileMeta(id: string): Promise<FileMeta | null> {
  const sql = await getSql();
  const rows = await sql.query<FileRow>(
    `select ${META_COLS} from files where id = $1 and status = 'ready'`,
    [id],
  );
  const row = rows[0];
  if (!row) return null;
  if (row.expires_at && new Date(row.expires_at).getTime() < Date.now()) {
    await sql.query("delete from file_chunks where file_id = $1", [id]);
    await sql.query("delete from files where id = $1", [id]);
    return null;
  }
  return mapFile(row);
}

export async function streamFileData(id: string): Promise<{
  meta: FileMeta;
  body: ReadableStream<Uint8Array>;
  storedName: string;
} | null> {
  const sql = await getSql();
  const rows = await sql.query<FileRow & { stored_name: string }>(
    `select ${META_COLS}, stored_name from files where id = $1 and status = 'ready'`,
    [id],
  );
  const row = rows[0];
  if (!row) return null;
  if (row.expires_at && new Date(row.expires_at).getTime() < Date.now()) {
    await sql.query("delete from file_chunks where file_id = $1", [id]);
    await sql.query("delete from files where id = $1", [id]);
    return null;
  }
  const meta = mapFile(row);
  const countRows = await sql.query<{ n: number }>(
    "select count(*)::int as n from file_chunks where file_id = $1",
    [id],
  );
  const chunkTotal = Number(countRows[0]?.n ?? 0);

  const body = new ReadableStream<Uint8Array>({
    async start(controller) {
      try {
        if (chunkTotal > 0) {
          for (let i = 0; i < chunkTotal; i += 1) {
            const part = await sql.query<{ data: unknown }>(
              "select data from file_chunks where file_id = $1 and chunk_index = $2",
              [id, i],
            );
            if (!part[0]) throw new Error("Potongan berkas hilang.");
            controller.enqueue(toBytes(part[0].data));
          }
        } else {
          const blob = await sql.query<{ data: unknown }>("select data from files where id = $1", [id]);
          if (!blob[0]?.data) throw new Error("Data berkas kosong.");
          controller.enqueue(toBytes(blob[0].data));
        }
        controller.close();
      } catch (err) {
        controller.error(err);
      }
    },
  });

  return { meta, body, storedName: row.stored_name };
}

export async function bumpDownload(id: string): Promise<void> {
  const sql = await getSql();
  await sql.query("update files set download_count = download_count + 1 where id = $1", [id]);
}

export async function reportFile(id: string, reason: string): Promise<boolean> {
  const sql = await getSql();
  const exists = await sql.query<{ id: string }>("select id from files where id = $1", [id]);
  if (!exists[0]) return false;
  await sql.query("insert into reports (file_id, reason) values ($1, $2)", [id, reason]);
  await sql.query("update files set reported = true where id = $1", [id]);
  return true;
}

export async function listFiles(opts: {
  q?: string;
  reportedOnly?: boolean;
  limit: number;
  offset: number;
}): Promise<{ items: FileMeta[]; total: number }> {
  const sql = await getSql();
  await purgeExpired();
  const params: unknown[] = [];
  const where: string[] = ["status = 'ready'"];
  if (opts.q?.trim()) {
    params.push(`%${opts.q.trim()}%`);
    params.push(opts.q.trim());
    where.push(`(original_name ilike $${params.length - 1} or id = $${params.length})`);
  }
  if (opts.reportedOnly) where.push("reported = true");
  const clause = `where ${where.join(" and ")}`;
  const countRows = await sql.query<{ n: number }>(`select count(*)::int as n from files ${clause}`, params);
  const total = Number(countRows[0]?.n ?? 0);
  params.push(opts.limit, opts.offset);
  const items = await sql.query<FileRow>(
    `select ${META_COLS} from files ${clause} order by created_at desc limit $${params.length - 1} offset $${params.length}`,
    params,
  );
  return { items: items.map(mapFile), total };
}

export async function deleteFile(id: string): Promise<boolean> {
  const sql = await getSql();
  await sql.query("delete from reports where file_id = $1", [id]);
  await sql.query("delete from file_chunks where file_id = $1", [id]);
  const rows = await sql.query<{ id: string }>("delete from files where id = $1 returning id", [id]);
  return Boolean(rows[0]);
}

export function contentDisposition(filename: string, mode: "inline" | "attachment"): string {
  const safe = filename.replace(/["\\]/g, "_") || "berkas";
  const encoded = encodeURIComponent(safe);
  return `${mode}; filename="${safe}"; filename*=UTF-8''${encoded}`;
}

export function shouldInline(kind: FileKind, ext: string): boolean {
  return (kind === "image" || kind === "video") && INLINE_EXT.has(ext);
}
