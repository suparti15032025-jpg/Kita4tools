export type FileKind = "image" | "video" | "file";

export type FileMeta = {
  id: string;
  originalName: string;
  mimeType: string;
  sizeBytes: number;
  kind: FileKind;
  downloadCount: number;
  expiresAt: string | null;
  createdAt: string;
  reported: boolean;
};

export type UploadResult = {
  file: FileMeta;
  directUrl: string;
  previewUrl: string;
  downloadUrl: string;
  pageUrl: string;
};

export type TikTokImage = {
  url: string;
  index: number;
};

export type TikTokInfo = {
  id: string;
  title: string;
  author: string;
  authorId: string;
  cover: string;
  duration: number | null;
  videoUrl: string | null;
  videoHdUrl: string | null;
  musicUrl: string | null;
  images: TikTokImage[];
};

export function originFromRequest(request: Request): string {
  const proto = request.headers.get("x-forwarded-proto") ?? "http";
  const host =
    request.headers.get("x-forwarded-host") ??
    request.headers.get("host") ??
    "localhost:8080";
  return `${proto}://${host}`;
}

export function urlsForFile(origin: string, id: string, kind: FileKind) {
  const directUrl = `${origin}/api/raw/${id}`;
  const downloadUrl = `${origin}/api/dl/${id}`;
  const previewUrl =
    kind === "image" || kind === "video"
      ? `${origin}/v/${id}`
      : `${origin}/f/${id}`;
  const pageUrl = kind === "file" ? `${origin}/f/${id}` : `${origin}/v/${id}`;
  return { directUrl, downloadUrl, previewUrl, pageUrl };
}
