import { Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { SiteShell } from "@/components/site-shell";

export function NotFound() {
  return (
    <SiteShell>
      <div className="mx-auto flex max-w-lg flex-col items-start gap-4 px-4 py-24 sm:px-6">
        <p className="kicker">404</p>
        <h1 className="font-display text-title font-semibold tracking-tight">Halaman tidak ada.</h1>
        <p className="text-muted">Tautan salah, atau berkasnya sudah kedaluwarsa.</p>
        <Button asChild>
          <Link to="/">Kembali ke beranda</Link>
        </Button>
      </div>
    </SiteShell>
  );
}
