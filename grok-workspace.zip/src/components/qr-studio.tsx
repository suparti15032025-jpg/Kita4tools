import { Download, ImagePlus, RotateCcw } from "lucide-react";
import { useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import {
  buildQrPayload,
  EMPTY_QR_FIELDS,
  type QrFields,
  type QrKind,
} from "@/lib/qr-payload";

type Level = "L" | "M" | "Q" | "H";

function downloadBlob(blob: Blob, name: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = name;
  a.click();
  URL.revokeObjectURL(url);
}

export function QrStudio() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [kind, setKind] = useState<QrKind>("text");
  const [fields, setFields] = useState<QrFields>(EMPTY_QR_FIELDS);
  const [size, setSize] = useState(320);
  const [margin, setMargin] = useState(2);
  const [fg, setFg] = useState("#12110e");
  const [bg, setBg] = useState("#faf7f0");
  const [level, setLevel] = useState<Level>("M");
  const [logo, setLogo] = useState<string | null>(null);
  const payload = useMemo(() => buildQrPayload(kind, fields), [kind, fields]);

  function patch(partial: Partial<QrFields>) {
    setFields((prev) => ({ ...prev, ...partial }));
  }

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    let cancelled = false;
    const effectiveLevel: Level = logo ? "H" : level;

    void (async () => {
      const QRCode = await import("qrcode");
      if (cancelled || !payload) {
        const ctx = canvas.getContext("2d");
        if (ctx) {
          ctx.fillStyle = bg;
          ctx.fillRect(0, 0, size, size);
        }
        return;
      }
      canvas.width = size;
      canvas.height = size;
      await QRCode.toCanvas(canvas, payload, {
        width: size,
        margin,
        errorCorrectionLevel: effectiveLevel,
        color: { dark: fg, light: bg },
      });
      if (cancelled || !logo) return;
      const img = new Image();
      img.crossOrigin = "anonymous";
      await new Promise<void>((resolve, reject) => {
        img.onload = () => resolve();
        img.onerror = () => reject(new Error("Logo gagal dimuat"));
        img.src = logo;
      });
      if (cancelled) return;
      const ctx = canvas.getContext("2d");
      if (!ctx) return;
      const logoSize = Math.round(size * 0.2);
      const x = (size - logoSize) / 2;
      const y = (size - logoSize) / 2;
      const pad = Math.round(logoSize * 0.12);
      ctx.fillStyle = bg;
      ctx.beginPath();
      const r = 8;
      ctx.roundRect(x - pad, y - pad, logoSize + pad * 2, logoSize + pad * 2, r);
      ctx.fill();
      ctx.drawImage(img, x, y, logoSize, logoSize);
    })().catch(() => {
      toast.error("Gagal menggambar QR.");
    });

    return () => {
      cancelled = true;
    };
  }, [payload, size, margin, fg, bg, level, logo]);

  async function downloadPng() {
    const canvas = canvasRef.current;
    if (!canvas || !payload) return;
    canvas.toBlob((blob) => {
      if (!blob) return;
      downloadBlob(blob, "kita-qr.png");
    }, "image/png");
  }

  async function downloadSvg() {
    if (!payload) return;
    const QRCode = await import("qrcode");
    let svg = await QRCode.toString(payload, {
      type: "svg",
      margin,
      errorCorrectionLevel: logo ? "H" : level,
      color: { dark: fg, light: bg },
      width: size,
    });
    if (logo) {
      const logoSize = Math.round(size * 0.2);
      const x = (size - logoSize) / 2;
      const y = (size - logoSize) / 2;
      svg = svg.replace(
        "</svg>",
        `<image href="${logo}" x="${x}" y="${y}" width="${logoSize}" height="${logoSize}" /></svg>`,
      );
    }
    downloadBlob(new Blob([svg], { type: "image/svg+xml" }), "kita-qr.svg");
  }

  return (
    <div className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_22rem]">
      <div className="panel rounded-2xl p-5 md:p-6">
        <Tabs value={kind} onValueChange={(v) => setKind(v as QrKind)}>
          <TabsList>
            <TabsTrigger value="text">Teks</TabsTrigger>
            <TabsTrigger value="wifi">WiFi</TabsTrigger>
            <TabsTrigger value="whatsapp">WhatsApp</TabsTrigger>
            <TabsTrigger value="email">Email</TabsTrigger>
            <TabsTrigger value="vcard">Kontak</TabsTrigger>
          </TabsList>
          <TabsContent value="text" className="space-y-2">
            <Label htmlFor="qr-text">Teks atau tautan</Label>
            <Textarea
              id="qr-text"
              value={fields.text}
              onChange={(e) => patch({ text: e.target.value })}
              placeholder="https://contoh.com atau catatan singkat"
            />
          </TabsContent>
          <TabsContent value="wifi" className="grid gap-4">
            <Field label="Nama jaringan (SSID)">
              <Input value={fields.wifiSsid} onChange={(e) => patch({ wifiSsid: e.target.value })} />
            </Field>
            <Field label="Sandi">
              <Input
                type="password"
                value={fields.wifiPassword}
                onChange={(e) => patch({ wifiPassword: e.target.value })}
                disabled={fields.wifiType === "nopass"}
              />
            </Field>
            <Field label="Keamanan">
              <select
                className="native-select"
                value={fields.wifiType}
                onChange={(e) =>
                  patch({ wifiType: e.target.value as QrFields["wifiType"] })
                }
              >
                <option value="WPA">WPA / WPA2</option>
                <option value="WEP">WEP</option>
                <option value="nopass">Tanpa sandi</option>
              </select>
            </Field>
            <label className="flex min-h-11 items-center justify-between gap-3">
              <span className="text-sm">Jaringan tersembunyi</span>
              <Switch
                checked={fields.wifiHidden}
                onCheckedChange={(v) => patch({ wifiHidden: v })}
              />
            </label>
          </TabsContent>
          <TabsContent value="whatsapp" className="grid gap-4">
            <Field label="Nomor (kode negara, tanpa + boleh)">
              <Input
                inputMode="tel"
                placeholder="62812xxxxxxx"
                value={fields.waPhone}
                onChange={(e) => patch({ waPhone: e.target.value })}
              />
            </Field>
            <Field label="Pesan">
              <Textarea
                value={fields.waMessage}
                onChange={(e) => patch({ waMessage: e.target.value })}
                placeholder="Halo, saya tertarik…"
              />
            </Field>
          </TabsContent>
          <TabsContent value="email" className="grid gap-4">
            <Field label="Alamat">
              <Input
                type="email"
                value={fields.emailTo}
                onChange={(e) => patch({ emailTo: e.target.value })}
              />
            </Field>
            <Field label="Subjek">
              <Input
                value={fields.emailSubject}
                onChange={(e) => patch({ emailSubject: e.target.value })}
              />
            </Field>
            <Field label="Isi">
              <Textarea
                value={fields.emailBody}
                onChange={(e) => patch({ emailBody: e.target.value })}
              />
            </Field>
          </TabsContent>
          <TabsContent value="vcard" className="grid gap-4">
            <Field label="Nama">
              <Input value={fields.vName} onChange={(e) => patch({ vName: e.target.value })} />
            </Field>
            <Field label="Organisasi">
              <Input value={fields.vOrg} onChange={(e) => patch({ vOrg: e.target.value })} />
            </Field>
            <Field label="Telepon">
              <Input value={fields.vPhone} onChange={(e) => patch({ vPhone: e.target.value })} />
            </Field>
            <Field label="Email">
              <Input value={fields.vEmail} onChange={(e) => patch({ vEmail: e.target.value })} />
            </Field>
            <Field label="Situs">
              <Input value={fields.vUrl} onChange={(e) => patch({ vUrl: e.target.value })} />
            </Field>
          </TabsContent>
        </Tabs>
      </div>

      <aside className="space-y-5">
        <div className="panel rounded-2xl p-5">
          <div className="flex aspect-square items-center justify-center rounded-lg bg-bg p-4">
            <canvas
              ref={canvasRef}
              width={size}
              height={size}
              className="max-h-full max-w-full"
              style={{ imageRendering: "pixelated" }}
            />
          </div>
          {!payload ? (
            <p className="mt-3 text-center text-sm text-muted">Isi data untuk melihat pratinjau.</p>
          ) : null}
          <div className="mt-4 grid grid-cols-2 gap-2">
            <Button type="button" onClick={downloadPng} disabled={!payload}>
              <Download />
              PNG
            </Button>
            <Button type="button" variant="secondary" onClick={downloadSvg} disabled={!payload}>
              <Download />
              SVG
            </Button>
          </div>
        </div>

        <div className="panel space-y-4 rounded-2xl p-5">
          <Field label={`Ukuran · ${size}px`}>
            <Slider min={160} max={720} step={8} value={[size]} onValueChange={(v) => setSize(v[0] ?? 320)} />
          </Field>
          <Field label={`Margin · ${margin}`}>
            <Slider min={0} max={8} step={1} value={[margin]} onValueChange={(v) => setMargin(v[0] ?? 2)} />
          </Field>
          <div className="grid grid-cols-2 gap-3">
            <Field label="Warna QR">
              <Input type="color" value={fg} onChange={(e) => setFg(e.target.value)} className="h-11 p-1" />
            </Field>
            <Field label="Latar">
              <Input type="color" value={bg} onChange={(e) => setBg(e.target.value)} className="h-11 p-1" />
            </Field>
          </div>
          <Field label="Koreksi error">
            <select
              className="native-select"
              value={level}
              onChange={(e) => setLevel(e.target.value as Level)}
              disabled={Boolean(logo)}
            >
              <option value="L">L — rendah</option>
              <option value="M">M — sedang</option>
              <option value="Q">Q — tinggi</option>
              <option value="H">H — sangat tinggi</option>
            </select>
            {logo ? (
              <p className="mt-1 text-xs text-muted">Logo memakai koreksi H otomatis.</p>
            ) : null}
          </Field>
          <div className="flex gap-2">
            <Button type="button" variant="secondary" className="flex-1" asChild>
              <label className="cursor-pointer">
                <ImagePlus />
                Logo
                <input
                  type="file"
                  accept="image/png,image/jpeg,image/webp,image/svg+xml"
                  className="sr-only"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (!file) return;
                    const reader = new FileReader();
                    reader.onload = () => setLogo(String(reader.result));
                    reader.readAsDataURL(file);
                  }}
                />
              </label>
            </Button>
            <Button
              type="button"
              variant="ghost"
              size="icon"
              aria-label="Reset"
              onClick={() => {
                setLogo(null);
                setFg("#12110e");
                setBg("#faf7f0");
                setSize(320);
                setMargin(2);
                setLevel("M");
              }}
            >
              <RotateCcw />
            </Button>
          </div>
        </div>
      </aside>
    </div>
  );
}

function Field({ label, children }: { label: string; children: ReactNode }) {
  return (
    <div className="space-y-2">
      <Label>{label}</Label>
      {children}
    </div>
  );
}
