import { Link } from "@tanstack/react-router";
import { APP_NAME } from "@/lib/config";
import { cn } from "@/lib/utils";

export function BrandMark({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 32 32"
      className={cn("size-8 shrink-0", className)}
      aria-hidden
    >
      <rect width="32" height="32" rx="6" className="fill-fg" />
      <path
        className="fill-bg"
        d="M7 6h6v20H7zm10.2 0 8.8 0-6.4 8.4h-2.4zm0 11.6h2.4L26 26h-8.8z"
      />
    </svg>
  );
}

export function BrandLockup({ className }: { className?: string }) {
  return (
    <Link
      to="/"
      className={cn("flex min-h-11 items-center gap-2.5", className)}
      aria-label={APP_NAME}
    >
      <BrandMark />
      <span className="font-display text-lg font-semibold tracking-tight">{APP_NAME}</span>
    </Link>
  );
}
