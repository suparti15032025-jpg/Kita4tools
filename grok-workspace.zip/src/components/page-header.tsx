import { Link } from "@tanstack/react-router";
import { ArrowLeft } from "lucide-react";

export function PageHeader({
  kicker,
  title,
  description,
}: {
  kicker?: string;
  title: string;
  description: string;
}) {
  return (
    <header className="max-w-2xl space-y-4">
      <Link
        to="/"
        className="inline-flex min-h-11 items-center gap-2 text-sm text-muted transition-colors hover:text-fg"
      >
        <ArrowLeft className="size-4" />
        Beranda
      </Link>
      {kicker ? <p className="kicker">{kicker}</p> : null}
      <h1 className="font-display text-title leading-tight font-semibold tracking-tight">{title}</h1>
      <p className="text-base leading-relaxed text-muted md:text-lg">{description}</p>
    </header>
  );
}
