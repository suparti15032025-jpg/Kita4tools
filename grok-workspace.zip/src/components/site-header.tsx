import { Link, useRouterState } from "@tanstack/react-router";
import { Menu } from "lucide-react";
import { BrandLockup } from "@/components/brand-mark";
import { ThemeToggle } from "@/components/theme-toggle";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { APP_NAME, TOOLS } from "@/lib/config";
import { cn } from "@/lib/utils";

function NavLinks({ onClick, className }: { onClick?: () => void; className?: string }) {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  return (
    <nav className={cn("flex items-center gap-1", className)}>
      {TOOLS.map((tool) => {
        const active = pathname === tool.href || pathname.startsWith(`${tool.href}/`);
        return (
          <Link
            key={tool.slug}
            to={tool.href}
            onClick={onClick}
            className={cn(
              "relative inline-flex min-h-11 items-center px-3 text-sm font-medium transition-colors duration-(--motion-quick) ease-(--ease-out)",
              active ? "text-fg" : "text-muted hover:text-fg",
            )}
          >
            {tool.short}
            <span
              className={cn(
                "absolute inset-x-3 bottom-2 h-px bg-fg transition-opacity duration-(--motion-quick)",
                active ? "opacity-100" : "opacity-0",
              )}
            />
          </Link>
        );
      })}
    </nav>
  );
}

export function SiteHeader() {
  return (
    <header className="sticky top-0 z-40 border-b border-border bg-bg">
      <div className="mx-auto flex h-16 max-w-6xl items-center justify-between gap-3 px-4 sm:px-6">
        <BrandLockup />
        <div className="hidden md:block">
          <NavLinks />
        </div>
        <div className="flex items-center gap-1">
          <ThemeToggle />
          <Sheet>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="md:hidden" aria-label="Menu">
                <Menu />
              </Button>
            </SheetTrigger>
            <SheetContent>
              <SheetHeader>
                <SheetTitle>{APP_NAME}</SheetTitle>
              </SheetHeader>
              <NavLinks className="mt-8 flex-col items-stretch" />
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </header>
  );
}
