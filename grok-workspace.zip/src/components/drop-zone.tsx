import { Upload } from "lucide-react";
import { useRef, useState } from "react";
import { cn } from "@/lib/utils";

export function DropZone({
  accept,
  multiple,
  disabled,
  hint,
  onFiles,
}: {
  accept?: string;
  multiple?: boolean;
  disabled?: boolean;
  hint: string;
  onFiles: (files: File[]) => void;
}) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [over, setOver] = useState(false);

  function take(list: FileList | File[] | null) {
    if (!list) return;
    const files = Array.from(list);
    if (files.length) onFiles(files);
  }

  return (
    <button
      type="button"
      disabled={disabled}
      onClick={() => inputRef.current?.click()}
      onDragEnter={(e) => {
        e.preventDefault();
        setOver(true);
      }}
      onDragOver={(e) => {
        e.preventDefault();
        setOver(true);
      }}
      onDragLeave={() => setOver(false)}
      onDrop={(e) => {
        e.preventDefault();
        setOver(false);
        take(e.dataTransfer.files);
      }}
      className={cn(
        "flex min-h-52 w-full flex-col items-center justify-center gap-4 rounded-2xl border border-dashed px-6 py-12 text-center transition-[border-color,background-color] duration-(--motion-fast) ease-(--ease-smooth-out)",
        over ? "border-fg bg-accent-soft" : "border-border-strong bg-surface",
        disabled && "opacity-60",
      )}
    >
      <span className="flex size-12 items-center justify-center rounded-md bg-secondary">
        <Upload className="size-5" />
      </span>
      <div className="space-y-1.5">
        <p className="text-sm font-medium">Letakkan berkas di sini, atau ketuk untuk memilih</p>
        <p className="text-sm text-muted">{hint}</p>
      </div>
      <input
        ref={inputRef}
        type="file"
        className="sr-only"
        accept={accept}
        multiple={multiple}
        disabled={disabled}
        onChange={(e) => {
          take(e.target.files);
          e.currentTarget.value = "";
        }}
      />
    </button>
  );
}
