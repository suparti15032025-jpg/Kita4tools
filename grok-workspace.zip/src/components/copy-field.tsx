import { Check, Copy } from "lucide-react";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { copyText } from "@/lib/utils";

export function CopyField({
  label,
  value,
  multiline = false,
}: {
  label: string;
  value: string;
  multiline?: boolean;
}) {
  const [copied, setCopied] = useState(false);

  async function onCopy() {
    const ok = await copyText(value);
    if (!ok) return;
    setCopied(true);
    window.setTimeout(() => setCopied(false), 1400);
  }

  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between gap-3">
        <p className="text-xs font-medium tracking-wide text-muted uppercase">{label}</p>
        <Button type="button" variant="ghost" size="sm" onClick={onCopy} className="h-8 px-2">
          {copied ? <Check className="size-3.5" /> : <Copy className="size-3.5" />}
          {copied ? "Tersalin" : "Salin"}
        </Button>
      </div>
      {multiline ? (
        <pre className="overflow-x-auto rounded-md border border-border bg-bg px-3 py-2.5 font-mono text-xs leading-relaxed whitespace-pre-wrap">
          {value}
        </pre>
      ) : (
        <Input readOnly value={value} className="font-mono text-xs" />
      )}
    </div>
  );
}
