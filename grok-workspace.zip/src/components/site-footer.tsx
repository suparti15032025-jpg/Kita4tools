import { Link } from "@tanstack/react-router";
import { BrandMark } from "@/components/brand-mark";
import { APP_NAME, TOOLS } from "@/lib/config";

export function SiteFooter() {
  return (
    <footer className="border-t border-border">
      <div className="mx-auto grid max-w-6xl gap-10 px-4 py-12 sm:px-6 md:grid-cols-[1.4fr_1fr_1fr]">
        <div className="space-y-4">
          <div className="flex items-center gap-2.5">
            <BrandMark className="size-7" />
            <span className="font-display text-lg font-semibold tracking-tight">{APP_NAME}</span>
          </div>
          <p className="max-w-xs text-sm leading-relaxed text-muted">
            Empat alat harian. Tanpa akun, tanpa omong kosong. QR, media, TikTok, dan berkas publik.
          </p>
        </div>
        <div>
          <p className="kicker">Alat</p>
          <ul className="mt-4 space-y-2">
            {TOOLS.map((tool) => (
              <li key={tool.slug}>
                <Link to={tool.href} className="text-sm text-muted transition-colors hover:text-fg">
                  {tool.title}
                </Link>
              </li>
            ))}
          </ul>
        </div>
        <div>
          <p className="kicker">Situs</p>
          <ul className="mt-4 space-y-2">
            <li>
              <Link to="/syarat" className="text-sm text-muted transition-colors hover:text-fg">
                Syarat
              </Link>
            </li>
            <li>
              <Link to="/privasi" className="text-sm text-muted transition-colors hover:text-fg">
                Privasi
              </Link>
            </li>
            <li>
              <Link to="/admin/login" className="text-sm text-muted transition-colors hover:text-fg">
                Admin
              </Link>
            </li>
          </ul>
        </div>
      </div>
      <div className="border-t border-border">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-5 sm:px-6">
          <p className="font-mono text-xs tracking-widest text-muted uppercase">{APP_NAME}</p>
          <p className="text-xs text-muted">Tanpa akun. Siap dipakai.</p>
        </div>
      </div>
    </footer>
  );
}
