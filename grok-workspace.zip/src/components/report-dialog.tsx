import { Flag } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { REPORT_REASONS } from "@/lib/config";
import { submitReport } from "@/lib/server-fns";

export function ReportDialog({ fileId }: { fileId: string }) {
  const [open, setOpen] = useState(false);
  const [reason, setReason] = useState<string>(REPORT_REASONS[0].id);
  const [busy, setBusy] = useState(false);

  async function send() {
    setBusy(true);
    try {
      await submitReport({ data: { id: fileId, reason } });
      toast.success("Laporan terkirim. Terima kasih.");
      setOpen(false);
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Gagal mengirim laporan.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button type="button" variant="ghost" size="sm">
          <Flag className="size-3.5" />
          Laporkan berkas
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Laporkan berkas</DialogTitle>
          <DialogDescription>
            Kami akan menandai berkas ini untuk ditinjau. Jangan unggah data pribadi di sini.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-2">
          <Label>Alasan</Label>
          <Select value={reason} onValueChange={setReason}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {REPORT_REASONS.map((item) => (
                <SelectItem key={item.id} value={item.id}>
                  {item.label}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <DialogFooter>
          <Button type="button" variant="outline" onClick={() => setOpen(false)}>
            Batal
          </Button>
          <Button type="button" onClick={send} disabled={busy}>
            {busy ? "Mengirim…" : "Kirim laporan"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
