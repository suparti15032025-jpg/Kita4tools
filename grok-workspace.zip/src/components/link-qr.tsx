import { useEffect, useRef } from "react";

export function LinkQr({ value, size = 168 }: { value: string; size?: number }) {
  const ref = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = ref.current;
    if (!canvas || !value) return;
    let cancelled = false;
    void (async () => {
      const QRCode = await import("qrcode");
      if (cancelled) return;
      await QRCode.toCanvas(canvas, value, {
        width: size,
        margin: 1,
        color: { dark: "#161512", light: "#fffcf7" },
      });
    })();
    return () => {
      cancelled = true;
    };
  }, [value, size]);

  return <canvas ref={ref} width={size} height={size} className="rounded-md" />;
}
