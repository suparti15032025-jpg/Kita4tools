import type { ComponentProps } from "react";
import { Toaster as Sonner } from "sonner";

type ToasterProps = ComponentProps<typeof Sonner>;

function Toaster({ ...props }: ToasterProps) {
  return (
    <Sonner
      theme="system"
      className="toaster group"
      toastOptions={{
        classNames: {
          toast:
            "group toast bg-surface text-fg border-border font-sans",
          description: "text-muted",
          actionButton: "bg-primary text-primary-foreground",
          cancelButton: "bg-secondary text-fg",
        },
      }}
      {...props}
    />
  );
}

export { Toaster };
