import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowDown, ArrowUpRight, Clapperboard, FileUp, Images, QrCode } from "lucide-react";
import { SiteShell } from "@/components/site-shell";
import { Button } from "@/components/ui/button";
import { APP_NAME, TOOLS } from "@/lib/config";

export const Route = createFileRoute("/")({ component: Home });

const ICONS = {
  qr: QrCode,
  media: Images,
  tiktok: Clapperboard,
  upload: FileUp,
} as const;

const NOTES = [
  { k: "01", t: "Tanpa akun", d: "Buka, pakai, selesai. Tidak ada daftar atau profil." },
  { k: "02", t: "QR di peramban", d: "Kode dibuat di perangkat Anda. Tidak pernah naik ke server." },
  { k: "03", t: "Berkas punya umur", d: "Pilih masa aktif. Yang kedaluwarsa dihapus sendiri." },
] as const;

function Home() {
  return (
    <SiteShell>
      <section className="hero-wash relative overflow-hidden">
        <div className="mx-auto max-w-6xl px-4 pt-14 pb-12 sm:px-6 sm:pt-24 sm:pb-16">
          <p className="hero-copy kicker">
            {APP_NAME} · empat alat · tanpa akun
          </p>
          <h1 className="hero-copy mt-6 max-w-5xl font-display text-display leading-display font-semibold tracking-tight">
            Semua yang perlu,{" "}
            <span className="font-sans font-normal italic">tanpa</span> yang tidak.
          </h1>
          <p className="hero-copy mt-6 max-w-xl text-base leading-relaxed text-muted sm:text-lg">
            QR, tautan media, unduhan TikTok, dan berkas publik. Langsung dipakai di
            peramban — rapi di ponsel, tenang di layar besar.
          </p>
          <div className="hero-copy mt-8 flex flex-wrap items-center gap-3">
            <Button asChild size="lg">
              <a href="#alat">
                Lihat alat
                <ArrowDown />
              </a>
            </Button>
            <Button asChild size="lg" variant="secondary">
              <Link to="/qr">
                Buat QR sekarang
                <ArrowUpRight />
              </Link>
            </Button>
          </div>
        </div>
      </section>

      <section className="border-y border-border">
        <div className="mx-auto grid max-w-6xl gap-px bg-border sm:grid-cols-3">
          {NOTES.map((note) => (
            <div key={note.k} className="bg-bg px-4 py-6 sm:px-6">
              <p className="font-mono text-xs tracking-widest text-muted">{note.k}</p>
              <p className="mt-3 font-display text-lg font-semibold tracking-tight">{note.t}</p>
              <p className="mt-1.5 text-sm leading-relaxed text-muted">{note.d}</p>
            </div>
          ))}
        </div>
      </section>

      <section id="alat" className="mx-auto max-w-6xl scroll-mt-20 px-4 py-14 sm:px-6 sm:py-20">
        <div className="mb-8 flex items-end justify-between gap-4">
          <div>
            <p className="kicker">Katalog</p>
            <h2 className="mt-3 font-display text-title font-semibold tracking-tight">Empat alat.</h2>
          </div>
          <p className="hidden max-w-xs text-right text-sm text-muted sm:block">
            Satu kartu, satu pekerjaan. Tidak ada yang tersembunyi di balik menu.
          </p>
        </div>
        <ul className="grid gap-3 sm:grid-cols-2">
          {TOOLS.map((tool) => {
            const Icon = ICONS[tool.slug];
            return (
              <li key={tool.slug} className="tool-card">
                <Link
                  to={tool.href}
                  className="group relative flex h-full min-h-56 flex-col overflow-hidden rounded-2xl p-6 tool-tile"
                >
                  <span aria-hidden className="tool-index">
                    {tool.index}
                  </span>
                  <div className="relative flex items-start justify-between gap-4">
                    <span className="flex size-12 items-center justify-center rounded-md bg-secondary">
                      <Icon className="size-5" />
                    </span>
                    <span className="font-mono text-xs tracking-widest text-muted">{tool.index}</span>
                  </div>
                  <h3 className="relative mt-auto pt-10 font-display text-2xl font-semibold tracking-tight">
                    {tool.title}
                  </h3>
                  <p className="relative mt-2 max-w-sm text-sm leading-relaxed text-muted">{tool.blurb}</p>
                  <span className="relative mt-5 inline-flex items-center gap-1.5 text-sm font-medium">
                    Buka
                    <ArrowUpRight className="size-4 transition-transform duration-(--motion-fast) ease-(--ease-smooth-out) group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
                  </span>
                </Link>
              </li>
            );
          })}
        </ul>
      </section>
    </SiteShell>
  );
}
