import { createFileRoute, redirect, useNavigate } from "@tanstack/react-router";
import { useState, type FormEvent } from "react";
import { toast } from "sonner";
import { SiteShell } from "@/components/site-shell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ADMIN_PASSWORD_DEFAULT } from "@/lib/config";
import { adminLogin, adminSession } from "@/lib/server-fns";

export const Route = createFileRoute("/admin/login")({
  loader: async () => {
    const session = await adminSession();
    if (session.ok) throw redirect({ to: "/admin" });
    return null;
  },
  component: AdminLoginPage,
});

function AdminLoginPage() {
  const navigate = useNavigate();
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    try {
      await adminLogin({ data: { password } });
      await navigate({ to: "/admin" });
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Gagal masuk.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <SiteShell>
      <div className="mx-auto max-w-sm space-y-6 px-4 py-16 sm:px-6">
        <p className="kicker">Panel</p>
        <h1 className="font-display text-title font-semibold tracking-tight">Admin</h1>
        <p className="text-sm text-muted">Masuk untuk meninjau dan menghapus berkas.</p>
        <form onSubmit={onSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="password">Sandi</Label>
            <Input
              id="password"
              type="password"
              autoComplete="current-password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </div>
          <Button type="submit" className="w-full" disabled={busy}>
            {busy ? "Memeriksa…" : "Masuk"}
          </Button>
        </form>
        <p className="text-xs text-muted">Sandi pratinjau: {ADMIN_PASSWORD_DEFAULT}</p>
      </div>
    </SiteShell>
  );
}
