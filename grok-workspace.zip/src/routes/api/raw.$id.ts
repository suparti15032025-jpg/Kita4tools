import { createFileRoute } from "@tanstack/react-router";
import { serveStoredFile } from "@/lib/file-response.server";

export const Route = createFileRoute("/api/raw/$id")({
  server: {
    handlers: {
      GET: async ({ params }) => serveStoredFile(params.id, "inline"),
    },
  },
});
