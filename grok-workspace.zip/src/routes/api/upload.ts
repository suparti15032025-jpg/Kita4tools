import { createFileRoute } from "@tanstack/react-router";
import {
  EXPIRY_OPTIONS,
  RATE,
  UPLOAD_CHUNK_BYTES,
  type ExpiryId,
} from "@/lib/config";
import { originFromRequest, urlsForFile } from "@/lib/files-shared";
import {
  createPendingFile,
  finalizeFile,
  insertFile,
  maxBytesForMode,
  purgeExpired,
  putFileChunk,
  validateUpload,
} from "@/lib/files.server";
import { clientIp, rateLimit } from "@/lib/rate-limit.server";

function jsonError(error: string, status: number) {
  return Response.json({ error }, { status });
}

function parseExpiry(raw: string): (typeof EXPIRY_OPTIONS)[number] {
  const found = EXPIRY_OPTIONS.find((o) => o.id === raw);
  return found ?? EXPIRY_OPTIONS[2]!;
}

export const Route = createFileRoute("/api/upload")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        try {
          const ip = clientIp(request);
          await purgeExpired();
          let form: FormData;
          try {
            form = await request.formData();
          } catch (err) {
            const msg = err instanceof Error ? err.message : "";
            if (/payload|too large|body/i.test(msg)) {
              return jsonError("Berkas terlalu besar. Unggah ulang; sistem akan memotongnya otomatis.", 413);
            }
            return jsonError("Tidak bisa membaca unggahan.", 400);
          }

          const step = String(form.get("step") || "single");

          if (step === "init") {
            const rl = rateLimit(`upload:${ip}`, RATE.upload.limit, RATE.upload.windowMs);
            if (!rl.ok) {
              return jsonError(`Terlalu banyak unggahan. Coba lagi dalam ${rl.retryAfterSec} detik.`, 429);
            }
            const name = String(form.get("name") || "");
            const size = Number(form.get("size") || 0);
            const mime = String(form.get("mime") || "");
            const mode = form.get("mode") === "media" ? "media" : "file";
            const chunkCount = Number(form.get("chunkCount") || 0);
            const expiry = parseExpiry(String(form.get("expiry") ?? "7d") as ExpiryId);
            const check = validateUpload({ name, size, mime, mode });
            if (!check.ok) return jsonError(check.error, 400);
            const expected = Math.max(1, Math.ceil(size / UPLOAD_CHUNK_BYTES));
            if (!Number.isInteger(chunkCount) || chunkCount < 1 || chunkCount > expected + 2) {
              return jsonError("Jumlah potongan unggahan tidak valid.", 400);
            }
            const meta = await createPendingFile({
              originalName: check.name,
              mime: check.mime,
              kind: check.kind,
              size,
              chunkCount,
              expiresAt: expiry.ms ? new Date(Date.now() + expiry.ms) : null,
            });
            return Response.json({ id: meta.id });
          }

          if (step === "chunk") {
            const rl = rateLimit(`chunk:${ip}`, RATE.chunk.limit, RATE.chunk.windowMs);
            if (!rl.ok) {
              return jsonError(`Terlalu banyak unggahan. Coba lagi dalam ${rl.retryAfterSec} detik.`, 429);
            }
            const id = String(form.get("id") || "");
            const index = Number(form.get("index"));
            const chunk = form.get("chunk");
            if (!id || !Number.isInteger(index) || !(chunk instanceof File)) {
              return jsonError("Potongan unggahan tidak valid.", 400);
            }
            if (chunk.size > UPLOAD_CHUNK_BYTES + 64 * 1024) {
              return jsonError("Potongan terlalu besar.", 413);
            }
            const bytes = new Uint8Array(await chunk.arrayBuffer());
            await putFileChunk(id, index, bytes);
            return Response.json({ ok: true, index });
          }

          if (step === "complete") {
            const id = String(form.get("id") || "");
            if (!id) return jsonError("Sesi unggahan tidak valid.", 400);
            const meta = await finalizeFile(id);
            const origin = originFromRequest(request);
            const urls = urlsForFile(origin, meta.id, meta.kind);
            return Response.json({ file: meta, ...urls });
          }

          const rl = rateLimit(`upload:${ip}`, RATE.upload.limit, RATE.upload.windowMs);
          if (!rl.ok) {
            return jsonError(`Terlalu banyak unggahan. Coba lagi dalam ${rl.retryAfterSec} detik.`, 429);
          }
          const file = form.get("file");
          if (!(file instanceof File)) return jsonError("Berkas tidak ditemukan.", 400);
          const mode = form.get("mode") === "media" ? "media" : "file";
          const cap = maxBytesForMode(mode);
          if (file.size > cap) {
            return jsonError(`Berkas terlalu besar. Maksimal ${Math.round(cap / (1024 * 1024))} MB.`, 413);
          }
          const expiry = parseExpiry(String(form.get("expiry") ?? "7d") as ExpiryId);
          const check = validateUpload({
            name: file.name,
            size: file.size,
            mime: file.type,
            mode,
          });
          if (!check.ok) return jsonError(check.error, 400);
          const bytes = new Uint8Array(await file.arrayBuffer());
          const meta = await insertFile({
            originalName: check.name,
            mime: check.mime,
            kind: check.kind,
            bytes,
            expiresAt: expiry.ms ? new Date(Date.now() + expiry.ms) : null,
          });
          const origin = originFromRequest(request);
          const urls = urlsForFile(origin, meta.id, meta.kind);
          return Response.json({ file: meta, ...urls });
        } catch (err) {
          const message = err instanceof Error ? err.message : "Gagal mengunggah.";
          const status = /terlalu besar|potongan/i.test(message) ? 413 : 500;
          return jsonError(message, status);
        }
      },
    },
  },
});
