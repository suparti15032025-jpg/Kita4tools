import { createFileRoute } from "@tanstack/react-router";
import { contentDisposition } from "@/lib/files.server";
import { safeRemoteUrl } from "@/lib/tiktok.server";

function allowedHost(host: string): boolean {
  const h = host.toLowerCase();
  const parts = [
    "tiktok",
    "tiktokcdn",
    "tiktokv",
    "byteoversea",
    "bytecdn",
    "ibyteimg",
    "musical.ly",
    "muscdn",
    "tikwm",
    "ttwstatic",
    "akamaized",
    "ssstik",
    "tiklydown",
  ];
  return parts.some((part) => h.includes(part));
}

export const Route = createFileRoute("/api/tiktok-file")({
  server: {
    handlers: {
      GET: async ({ request }) => {
        const url = new URL(request.url);
        const remote = url.searchParams.get("url") ?? "";
        const filename = (url.searchParams.get("filename") ?? "tiktok-media").replace(/[/\\]/g, "");
        if (!safeRemoteUrl(remote)) {
          return Response.json({ error: "URL tidak valid." }, { status: 400 });
        }
        let parsed: URL;
        try {
          parsed = new URL(remote);
        } catch {
          return Response.json({ error: "URL tidak valid." }, { status: 400 });
        }
        if (!allowedHost(parsed.hostname)) {
          return Response.json({ error: "Sumber media tidak diizinkan." }, { status: 400 });
        }
        try {
          const res = await fetch(remote, {
            headers: {
              "user-agent":
                "Mozilla/5.0 (iPhone; CPU iPhone OS 17_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.5 Mobile/15E148 Safari/604.1",
              referer: "https://www.tiktok.com/",
            },
            redirect: "follow",
            signal: AbortSignal.timeout(25000),
          });
          if (!res.ok || !res.body) {
            return Response.json({ error: "Gagal mengunduh media sumber. Coba lagi." }, { status: 502 });
          }
          const type = res.headers.get("content-type") ?? "application/octet-stream";
          const headers = new Headers({
            "content-type": type,
            "content-disposition": contentDisposition(filename, "attachment"),
            "x-content-type-options": "nosniff",
          });
          const len = res.headers.get("content-length");
          if (len) headers.set("content-length", len);
          return new Response(res.body, { headers });
        } catch {
          return Response.json(
            { error: "Gagal mengunduh media sumber. Tautan kedaluwarsa atau diblokir. Ambil ulang videonya." },
            { status: 502 },
          );
        }
      },
    },
  },
});
