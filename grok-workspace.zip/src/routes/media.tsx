import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { CopyField } from "@/components/copy-field";
import { DropZone } from "@/components/drop-zone";
import { PageHeader } from "@/components/page-header";
import { SiteShell } from "@/components/site-shell";
import { Progress } from "@/components/ui/progress";
import { MAX_FILES_PER_BATCH, MAX_MEDIA_BYTES, formatMbLimit } from "@/lib/config";
import type { UploadResult } from "@/lib/files-shared";
import { xhrUpload } from "@/lib/upload-client";
import { formatBytes, humanizeServerError } from "@/lib/utils";

export const Route = createFileRoute("/media")({ component: MediaPage });

type Job = {
  id: string;
  name: string;
  progress: number;
  error?: string;
  result?: UploadResult;
};

function MediaPage() {
  const [jobs, setJobs] = useState<Job[]>([]);
  const busy = jobs.some((j) => !j.result && !j.error);

  async function onFiles(files: File[]) {
    const slice = files.slice(0, MAX_FILES_PER_BATCH);
    if (files.length > MAX_FILES_PER_BATCH) {
      toast.error(`Maksimal ${MAX_FILES_PER_BATCH} berkas sekaligus.`);
    }
    const incoming: Job[] = slice.map((file) => ({
      id: `${file.name}-${file.size}-${file.lastModified}-${Math.random()}`,
      name: file.name,
      progress: 0,
      error: file.size > MAX_MEDIA_BYTES
        ? `Berkas terlalu besar. Maksimal ${formatMbLimit(MAX_MEDIA_BYTES)}.`
        : undefined,
    }));
    setJobs((prev) => [...incoming, ...prev]);
    await Promise.all(
      slice.map(async (file, i) => {
        const job = incoming[i];
        if (!job || job.error) return;
        try {
          const result = await xhrUpload(file, { mode: "media", expiry: "30d" }, (pct) => {
            setJobs((prev) => prev.map((j) => (j.id === job.id ? { ...j, progress: pct } : j)));
          });
          setJobs((prev) => prev.map((j) => (j.id === job.id ? { ...j, progress: 100, result } : j)));
        } catch (err) {
          const message = humanizeServerError(err, "Gagal mengunggah. Coba lagi.");
          setJobs((prev) => prev.map((j) => (j.id === job.id ? { ...j, error: message } : j)));
        }
      }),
    );
  }

  return (
    <SiteShell>
      <div className="mx-auto max-w-3xl space-y-10 px-4 py-10 sm:px-6 sm:py-16">
        <PageHeader
          kicker="02 · Hosting"
          title="Tautan media"
          description="Unggah gambar atau video sampai 30 MB, lalu bagikan tautan langsung, halaman pratinjau, atau kode embed."
        />
        <DropZone
          accept="image/jpeg,image/png,image/gif,image/webp,video/mp4,video/webm,video/quicktime,.jpg,.jpeg,.png,.gif,.webp,.mp4,.webm,.mov"
          multiple
          disabled={busy}
          hint={`JPG, PNG, GIF, WEBP, MP4, WEBM, MOV · maks ${formatMbLimit(MAX_MEDIA_BYTES)}`}
          onFiles={onFiles}
        />
        <ul className="space-y-4">
          {jobs.map((job) => (
            <li key={job.id} className="panel rounded-2xl p-5">
              <div className="flex items-start justify-between gap-3">
                <p className="text-sm font-medium">{job.name}</p>
                {job.result ? (
                  <span className="text-xs text-muted">{formatBytes(job.result.file.sizeBytes)}</span>
                ) : null}
              </div>
              {!job.result && !job.error ? (
                <div className="mt-3 space-y-2">
                  <Progress value={job.progress} />
                  <p className="font-mono text-xs text-muted tabular-nums">{job.progress}%</p>
                </div>
              ) : null}
              {job.error ? <p className="mt-3 text-sm text-danger">{job.error}</p> : null}
              {job.result ? <MediaResult result={job.result} /> : null}
            </li>
          ))}
        </ul>
      </div>
    </SiteShell>
  );
}

function MediaResult({ result }: { result: UploadResult }) {
  const { file, directUrl, previewUrl } = result;
  const isVideo = file.kind === "video";
  const html = isVideo
    ? `<video src="${directUrl}" controls style="max-width:100%"></video>`
    : `<a href="${previewUrl}"><img src="${directUrl}" alt="${file.originalName}" /></a>`;
  const bb = isVideo ? `[video]${directUrl}[/video]` : `[img]${directUrl}[/img]`;
  const md = isVideo ? `[${file.originalName}](${directUrl})` : `![${file.originalName}](${directUrl})`;

  return (
    <div className="mt-5 space-y-5">
      {isVideo ? (
        <video src={directUrl} controls className="max-h-64 w-full rounded-lg bg-bg" />
      ) : (
        <img src={directUrl} alt="" className="max-h-64 rounded-lg object-contain" />
      )}
      <CopyField label="Halaman pratinjau" value={previewUrl} />
      <CopyField label="Tautan langsung" value={directUrl} />
      <CopyField label="HTML" value={html} multiline />
      <CopyField label="BBCode" value={bb} multiline />
      <CopyField label="Markdown" value={md} multiline />
    </div>
  );
}
