import { createFileRoute } from "@tanstack/react-router";
import { PageHeader } from "@/components/page-header";
import { SiteShell } from "@/components/site-shell";

export const Route = createFileRoute("/syarat")({ component: SyaratPage });

function SyaratPage() {
  return (
    <SiteShell>
      <article className="mx-auto max-w-2xl space-y-8 px-4 py-10 sm:px-6 sm:py-16">
        <PageHeader
          title="Syarat penggunaan"
          description="Ringkas, tanpa bahasa hukum yang berputar-putar."
        />
        <div className="space-y-4 text-sm leading-relaxed text-muted">
          <p>
            Kita menyediakan alat gratis: pembuat QR, tautan media, unduhan TikTok, dan unggah berkas
            publik. Dengan memakai situs ini, Anda setuju untuk tidak mengunggah malware, data pribadi
            orang lain, atau materi yang melanggar hukum Indonesia.
          </p>
          <p>
            Tautan berkas bersifat publik. Siapa pun yang memegang tautan dapat mengunduh isinya. Jangan
            unggah dokumen rahasia.
          </p>
          <p>
            Unduhan TikTok hanya untuk keperluan pribadi. Hak cipta tetap milik kreator. Kita tidak
            menyimpan salinan video di server.
          </p>
          <p>
            Berkas dapat kedaluwarsa sesuai masa aktif yang Anda pilih, atau dihapus jika dilaporkan.
            Layanan disediakan apa adanya, tanpa jaminan ketersediaan.
          </p>
        </div>
      </article>
    </SiteShell>
  );
}
