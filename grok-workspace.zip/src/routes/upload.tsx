import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { CopyField } from "@/components/copy-field";
import { DropZone } from "@/components/drop-zone";
import { PageHeader } from "@/components/page-header";
import { SiteShell } from "@/components/site-shell";
import { Label } from "@/components/ui/label";
import { Progress } from "@/components/ui/progress";
import {
  EXPIRY_OPTIONS,
  MAX_FILE_BYTES,
  MAX_FILES_PER_BATCH,
  formatMbLimit,
  type ExpiryId,
} from "@/lib/config";
import type { UploadResult } from "@/lib/files-shared";
import { xhrUpload } from "@/lib/upload-client";
import { formatBytes, humanizeServerError } from "@/lib/utils";

export const Route = createFileRoute("/upload")({ component: UploadPage });

type Job = {
  id: string;
  name: string;
  progress: number;
  error?: string;
  result?: UploadResult;
};

function UploadPage() {
  const [expiry, setExpiry] = useState<ExpiryId>("7d");
  const [jobs, setJobs] = useState<Job[]>([]);
  const busy = jobs.some((j) => !j.result && !j.error);

  async function onFiles(files: File[]) {
    const slice = files.slice(0, MAX_FILES_PER_BATCH);
    if (files.length > MAX_FILES_PER_BATCH) {
      toast.error(`Maksimal ${MAX_FILES_PER_BATCH} berkas sekaligus.`);
    }
    const incoming: Job[] = slice.map((file) => ({
      id: `${file.name}-${file.size}-${file.lastModified}-${Math.random()}`,
      name: file.name,
      progress: 0,
      error: file.size > MAX_FILE_BYTES
        ? `Berkas terlalu besar. Maksimal ${formatMbLimit(MAX_FILE_BYTES)}.`
        : undefined,
    }));
    setJobs((prev) => [...incoming, ...prev]);
    await Promise.all(
      slice.map(async (file, i) => {
        const job = incoming[i];
        if (!job || job.error) return;
        try {
          const result = await xhrUpload(file, { mode: "file", expiry }, (pct) => {
            setJobs((prev) => prev.map((j) => (j.id === job.id ? { ...j, progress: pct } : j)));
          });
          setJobs((prev) => prev.map((j) => (j.id === job.id ? { ...j, progress: 100, result } : j)));
        } catch (err) {
          const message = humanizeServerError(err, "Gagal mengunggah. Coba lagi.");
          setJobs((prev) => prev.map((j) => (j.id === job.id ? { ...j, error: message } : j)));
        }
      }),
    );
  }

  return (
    <SiteShell>
      <div className="mx-auto max-w-3xl space-y-10 px-4 py-10 sm:px-6 sm:py-16">
        <PageHeader
          kicker="04 · Penyimpanan"
          title="Berkas publik"
          description="Unggah APK, ZIP, PDF, atau berkas lain sampai 150 MB. Penerima membuka halaman unduh — berkas tidak langsung tersimpan."
        />
        <div className="space-y-2">
          <Label htmlFor="expiry">Masa aktif</Label>
          <select
            id="expiry"
            className="native-select"
            value={expiry}
            onChange={(e) => setExpiry(e.target.value as ExpiryId)}
          >
            {EXPIRY_OPTIONS.map((opt) => (
              <option key={opt.id} value={opt.id}>
                {opt.label}
              </option>
            ))}
          </select>
        </div>
        <DropZone
          multiple
          disabled={busy}
          hint={`Semua jenis berkas kecuali skrip server · maks ${formatMbLimit(MAX_FILE_BYTES)}`}
          onFiles={onFiles}
        />
        <ul className="space-y-4">
          {jobs.map((job) => (
            <li key={job.id} className="panel rounded-2xl p-5">
              <p className="text-sm font-medium">{job.name}</p>
              {!job.result && !job.error ? (
                <div className="mt-3 space-y-2">
                  <Progress value={job.progress} />
                  <p className="font-mono text-xs text-muted tabular-nums">{job.progress}%</p>
                </div>
              ) : null}
              {job.error ? <p className="mt-3 text-sm text-danger">{job.error}</p> : null}
              {job.result ? (
                <div className="mt-5 space-y-4">
                  <p className="text-xs text-muted">{formatBytes(job.result.file.sizeBytes)}</p>
                  <CopyField label="Bagikan halaman ini" value={job.result.pageUrl} />
                </div>
              ) : null}
            </li>
          ))}
        </ul>
      </div>
    </SiteShell>
  );
}
