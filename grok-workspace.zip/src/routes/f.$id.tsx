import { createFileRoute, notFound } from "@tanstack/react-router";
import { formatDistanceToNow } from "date-fns";
import { id as localeId } from "date-fns/locale";
import { Download } from "lucide-react";
import { LinkQr } from "@/components/link-qr";
import { ReportDialog } from "@/components/report-dialog";
import { SiteShell } from "@/components/site-shell";
import { Button } from "@/components/ui/button";
import { getPublicFile } from "@/lib/server-fns";
import { fileExtension, formatBytes } from "@/lib/utils";

export const Route = createFileRoute("/f/$id")({
  loader: async ({ params }) => {
    const file = await getPublicFile({ data: { id: params.id } });
    if (!file) throw notFound();
    return file;
  },
  component: FilePage,
});

function FilePage() {
  const file = Route.useLoaderData();
  const downloadUrl = `/api/dl/${file.id}`;
  const pageUrl = typeof window === "undefined" ? `/f/${file.id}` : window.location.href;
  const ext = fileExtension(file.originalName) || "file";
  const expiry = file.expiresAt
    ? `Kedaluwarsa ${formatDistanceToNow(new Date(file.expiresAt), { addSuffix: true, locale: localeId })}`
    : "Permanen";

  return (
    <SiteShell>
      <div className="mx-auto max-w-3xl px-4 py-12 sm:px-6 sm:py-16">
        <div className="panel overflow-hidden rounded-2xl">
          <div className="border-b border-border px-6 py-8 sm:px-8">
            <p className="kicker">Berkas publik</p>
            <div className="mt-5 flex items-start gap-4">
              <span className="flex size-14 shrink-0 items-center justify-center rounded-lg bg-secondary font-mono text-xs font-medium uppercase tracking-wider">
                {ext.slice(0, 4)}
              </span>
              <div className="min-w-0">
                <h1 className="font-display text-title leading-tight font-semibold tracking-tight break-all">
                  {file.originalName}
                </h1>
                <p className="mt-2 text-sm text-muted">
                  {formatBytes(file.sizeBytes)} · {expiry}
                </p>
              </div>
            </div>
          </div>

          <div className="grid gap-8 px-6 py-8 sm:px-8 lg:grid-cols-[1fr_11rem]">
            <div className="space-y-6">
              <dl className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <dt className="text-muted">Diunggah</dt>
                  <dd className="mt-1 font-medium">
                    {formatDistanceToNow(new Date(file.createdAt), { addSuffix: true, locale: localeId })}
                  </dd>
                </div>
                <div>
                  <dt className="text-muted">Unduhan</dt>
                  <dd className="mt-1 font-medium tabular-nums">{file.downloadCount}</dd>
                </div>
              </dl>
              <Button asChild size="lg" className="w-full">
                <a href={downloadUrl}>
                  <Download />
                  Unduh berkas
                </a>
              </Button>
              <p className="text-sm text-muted">
                Berkas tidak tersimpan otomatis. Ketuk tombol di atas jika Anda ingin mengunduhnya.
              </p>
              <ReportDialog fileId={file.id} />
            </div>
            <aside className="flex flex-col items-start gap-3">
              <LinkQr value={pageUrl} size={140} />
              <p className="text-xs leading-relaxed text-muted">
                Pindai dengan kamera HP — iPhone, Android, atau Google Lens. Tidak perlu aplikasi tambahan.
              </p>
            </aside>
          </div>
        </div>
      </div>
    </SiteShell>
  );
}
