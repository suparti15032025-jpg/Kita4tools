import { createFileRoute } from "@tanstack/react-router";
import { Download, Music2 } from "lucide-react";
import { useState, type FormEvent } from "react";
import { PageHeader } from "@/components/page-header";
import { SiteShell } from "@/components/site-shell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import type { TikTokInfo } from "@/lib/files-shared";
import { inspectTikTok } from "@/lib/server-fns";
import { humanizeServerError } from "@/lib/utils";

export const Route = createFileRoute("/tiktok")({ component: TikTokPage });

function proxyUrl(url: string, filename: string) {
  const params = new URLSearchParams({ url, filename });
  return `/api/tiktok-file?${params.toString()}`;
}

function TikTokPage() {
  const [url, setUrl] = useState("");
  const [busy, setBusy] = useState(false);
  const [info, setInfo] = useState<TikTokInfo | null>(null);
  const [error, setError] = useState<string | null>(null);

  async function run(e: FormEvent) {
    e.preventDefault();
    setBusy(true);
    setInfo(null);
    setError(null);
    try {
      const data = await inspectTikTok({ data: { url } });
      setInfo(data);
    } catch (err) {
      setError(
        humanizeServerError(
          err,
          "Tidak bisa mengambil video. Pastikan tautan publik, coba tautan lengkap tiktok.com/@akun/video/…, lalu ulangi.",
        ),
      );
    } finally {
      setBusy(false);
    }
  }

  return (
    <SiteShell>
      <div className="mx-auto max-w-3xl space-y-10 px-4 py-10 sm:px-6 sm:py-16">
        <PageHeader
          kicker="03 · Unduhan"
          title="Unduh TikTok"
          description="Tempel tautan video atau vm.tiktok.com. Kami mengambil metadata di server, lalu menyiapkan unduhan video, audio, atau foto."
        />
        <form onSubmit={run} className="space-y-3">
          <Label htmlFor="tt-url">Tautan TikTok</Label>
          <div className="flex flex-col gap-2 sm:flex-row">
            <Input
              id="tt-url"
              value={url}
              onChange={(e) => setUrl(e.target.value)}
              placeholder="https://www.tiktok.com/@akun/video/…"
              required
            />
            <Button type="submit" disabled={busy} className="sm:w-40">
              {busy ? "Memeriksa…" : "Ambil"}
            </Button>
          </div>
        </form>

        {error ? (
          <p className="rounded-xl border border-border bg-surface px-4 py-3 text-sm text-danger">{error}</p>
        ) : null}

        {info ? (
          <article className="panel overflow-hidden rounded-2xl">
            {info.cover ? (
              <img src={info.cover} alt="" className="aspect-video w-full object-cover bg-bg" />
            ) : null}
            <div className="space-y-4 p-5">
              <div>
                <p className="text-xs text-muted">@{info.authorId || info.author}</p>
                <h2 className="mt-1 font-display text-2xl font-semibold tracking-tight">{info.title}</h2>
                <p className="mt-1 text-sm text-muted">{info.author}</p>
              </div>
              <div className="flex flex-col gap-2 sm:flex-row sm:flex-wrap">
                {info.videoHdUrl || info.videoUrl ? (
                  <Button asChild>
                    <a href={proxyUrl(info.videoHdUrl || info.videoUrl || "", `${info.id}.mp4`)}>
                      <Download />
                      Video tanpa watermark
                    </a>
                  </Button>
                ) : null}
                {info.musicUrl ? (
                  <Button asChild variant="secondary">
                    <a href={proxyUrl(info.musicUrl, `${info.id}.mp3`)}>
                      <Music2 />
                      Audio MP3
                    </a>
                  </Button>
                ) : null}
              </div>
              {info.images.length > 0 ? (
                <div className="space-y-3">
                  <p className="text-sm font-medium">Foto slideshow</p>
                  <ul className="grid grid-cols-2 gap-2 sm:grid-cols-3">
                    {info.images.map((img) => (
                      <li key={img.index}>
                        <a
                          href={proxyUrl(img.url, `${info.id}-${img.index + 1}.jpg`)}
                          className="block overflow-hidden rounded-md"
                        >
                          <img src={img.url} alt="" className="aspect-square w-full object-cover" />
                        </a>
                      </li>
                    ))}
                  </ul>
                </div>
              ) : null}
            </div>
          </article>
        ) : null}

        <p className="text-sm text-muted">
          Hormati hak cipta kreator. Unduhan hanya untuk keperluan pribadi. Kita tidak berafiliasi
          dengan TikTok dan tidak menyimpan video di server kami.
        </p>
      </div>
    </SiteShell>
  );
}
