import { createFileRoute, notFound } from "@tanstack/react-router";
import { formatDistanceToNow } from "date-fns";
import { id as localeId } from "date-fns/locale";
import { Download } from "lucide-react";
import { CopyField } from "@/components/copy-field";
import { ReportDialog } from "@/components/report-dialog";
import { SiteShell } from "@/components/site-shell";
import { Button } from "@/components/ui/button";
import { APP_NAME } from "@/lib/config";
import { getPublicFile } from "@/lib/server-fns";
import { formatBytes } from "@/lib/utils";

export const Route = createFileRoute("/v/$id")({
  loader: async ({ params }) => {
    const file = await getPublicFile({ data: { id: params.id } });
    if (!file) throw notFound();
    return file;
  },
  head: ({ loaderData }) => {
    const file = loaderData;
    if (!file) return { meta: [{ title: `Media — ${APP_NAME}` }] };
    const image = `/api/raw/${file.id}`;
    const isVideo = file.kind === "video";
    const meta: Array<{ title?: string; name?: string; property?: string; content?: string }> = [
      { title: `${file.originalName} — ${APP_NAME}` },
      { name: "description", content: `Media di ${APP_NAME}` },
      { property: "og:title", content: file.originalName },
      { property: "og:description", content: `${formatBytes(file.sizeBytes)} · ${APP_NAME}` },
      { property: "og:type", content: isVideo ? "video.other" : "website" },
    ];
    if (isVideo) {
      meta.push({ property: "og:video", content: image });
      meta.push({ name: "twitter:card", content: "player" });
    } else {
      meta.push({ property: "og:image", content: image });
      meta.push({ name: "twitter:card", content: "summary_large_image" });
    }
    return { meta };
  },
  component: MediaViewPage,
});

function MediaViewPage() {
  const file = Route.useLoaderData();
  const direct = `/api/raw/${file.id}`;
  const downloadUrl = `/api/dl/${file.id}`;
  const isVideo = file.kind === "video";

  return (
    <SiteShell>
      <div className="mx-auto max-w-3xl space-y-6 px-4 py-12 sm:px-6 sm:py-16">
        <p className="kicker">Pratinjau media</p>
        <h1 className="font-display text-title font-semibold tracking-tight break-all">{file.originalName}</h1>
        <p className="text-sm text-muted">
          {formatBytes(file.sizeBytes)} ·{" "}
          {formatDistanceToNow(new Date(file.createdAt), { addSuffix: true, locale: localeId })} ·{" "}
          {file.downloadCount} unduhan
        </p>
        {isVideo ? (
          <video src={direct} controls className="w-full rounded-2xl bg-bg" />
        ) : (
          <img src={direct} alt={file.originalName} className="w-full rounded-2xl" />
        )}
        <div className="flex flex-wrap gap-2">
          <Button asChild>
            <a href={downloadUrl}>
              <Download />
              Unduh
            </a>
          </Button>
          <ReportDialog fileId={file.id} />
        </div>
        <CopyField label="Tautan langsung" value={typeof window === "undefined" ? direct : `${window.location.origin}${direct}`} />
      </div>
    </SiteShell>
  );
}
