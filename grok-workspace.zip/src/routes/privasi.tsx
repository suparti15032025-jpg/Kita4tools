import { createFileRoute } from "@tanstack/react-router";
import { PageHeader } from "@/components/page-header";
import { SiteShell } from "@/components/site-shell";

export const Route = createFileRoute("/privasi")({ component: PrivasiPage });

function PrivasiPage() {
  return (
    <SiteShell>
      <article className="mx-auto max-w-2xl space-y-8 px-4 py-10 sm:px-6 sm:py-16">
        <PageHeader
          title="Privasi"
          description="Kami menyimpan sesedikit mungkin."
        />
        <div className="space-y-4 text-sm leading-relaxed text-muted">
          <p>
            Tidak ada akun pengguna. QR dibuat sepenuhnya di peramban Anda. Tautan TikTok diproses di
            server lalu dibuang — kami tidak menyimpan video, audio, atau riwayat unduhan.
          </p>
          <p>
            Berkas yang Anda unggah disimpan beserta nama, ukuran, tipe, dan waktu kedaluwarsa. Alamat IP
            dipakai hanya untuk membatasi penyalahgunaan (rate limit), tidak ditautkan ke identitas.
          </p>
          <p>
            Laporan berkas mencatat alasan yang Anda pilih, bukan nama atau email. Panel admin hanya
            melihat metadata dan dapat menghapus berkas yang dilaporkan.
          </p>
          <p>Cookie dipakai untuk tema tampilan dan sesi admin, bukan untuk iklan.</p>
        </div>
      </article>
    </SiteShell>
  );
}
