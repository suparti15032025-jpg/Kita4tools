import { createFileRoute } from "@tanstack/react-router";
import { PageHeader } from "@/components/page-header";
import { QrStudio } from "@/components/qr-studio";
import { SiteShell } from "@/components/site-shell";

export const Route = createFileRoute("/qr")({ component: QrPage });

function QrPage() {
  return (
    <SiteShell>
      <div className="mx-auto max-w-6xl space-y-10 px-4 py-10 sm:px-6 sm:py-16">
        <PageHeader
          kicker="01 · Studio"
          title="QR Code"
          description="Bangun kode untuk tautan, WiFi, WhatsApp, email, atau kartu nama. Pratinjau langsung, unduh PNG atau SVG."
        />
        <QrStudio />
        <div className="max-w-2xl rounded-2xl bg-secondary px-5 py-4 text-sm leading-relaxed text-muted">
          <p className="font-medium text-fg">Cara pindai</p>
          <p className="mt-1">
            Buka kamera HP, lalu arahkan ke kode. iPhone dan Android membaca QR tanpa aplikasi
            tambahan. Kalau kamera tidak menawarkan tautan, pakai Google Lens.
          </p>
        </div>
      </div>
    </SiteShell>
  );
}
