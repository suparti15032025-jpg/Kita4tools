import { createFileRoute, redirect, useNavigate, useRouter } from "@tanstack/react-router";
import { useState } from "react";
import { toast } from "sonner";
import { SiteShell } from "@/components/site-shell";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { adminDeleteFile, adminListFiles, adminLogout, adminSession } from "@/lib/server-fns";
import { formatBytes } from "@/lib/utils";

type AdminSearch = {
  q?: string;
  reported?: boolean;
  page?: number;
};

export const Route = createFileRoute("/admin/")({
  validateSearch: (search: Record<string, unknown>): AdminSearch => ({
    q: typeof search.q === "string" && search.q ? search.q : undefined,
    reported: search.reported === "1" || search.reported === true ? true : undefined,
    page: Number(search.page) > 1 ? Number(search.page) : undefined,
  }),
  loaderDeps: ({ search }) => search,
  loader: async ({ deps }) => {
    const session = await adminSession();
    if (!session.ok) throw redirect({ to: "/admin/login" });
    return adminListFiles({
      data: {
        q: deps.q,
        reportedOnly: deps.reported,
        page: deps.page ?? 1,
      },
    });
  },
  component: AdminPage,
});

function AdminPage() {
  const data = Route.useLoaderData();
  const search = Route.useSearch();
  const navigate = useNavigate({ from: "/admin/" });
  const router = useRouter();
  const [q, setQ] = useState(search.q ?? "");
  const page = search.page ?? 1;
  const reported = search.reported ?? false;
  const totalPages = Math.max(1, Math.ceil(data.total / 20));

  async function remove(id: string) {
    if (!confirm("Hapus berkas ini?")) return;
    try {
      await adminDeleteFile({ data: { id } });
      toast.success("Berkas dihapus.");
      await router.invalidate();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : "Gagal menghapus.");
    }
  }

  async function logout() {
    await adminLogout();
    await navigate({ to: "/admin/login" });
  }

  return (
    <SiteShell>
      <div className="mx-auto max-w-5xl space-y-8 px-4 py-10 sm:px-6">
        <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <p className="kicker">Panel</p>
            <h1 className="mt-2 font-display text-title font-semibold tracking-tight">Berkas</h1>
            <p className="mt-1 text-sm text-muted tabular-nums">{data.total} item</p>
          </div>
          <Button type="button" variant="outline" onClick={logout}>
            Keluar
          </Button>
        </div>

        <form
          className="flex flex-col gap-3 sm:flex-row sm:items-center"
          onSubmit={(e) => {
            e.preventDefault();
            void navigate({
              search: { q: q || undefined, reported: reported || undefined, page: undefined },
            });
          }}
        >
          <Input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Cari nama atau ID"
            className="sm:max-w-sm"
          />
          <Button type="submit" variant="secondary">
            Cari
          </Button>
          <label className="flex min-h-11 items-center gap-2 text-sm">
            <Switch
              checked={reported}
              onCheckedChange={(on) => {
                void navigate({
                  search: { q: search.q, reported: on || undefined, page: undefined },
                });
              }}
            />
            Hanya dilaporkan
          </label>
        </form>

        <div className="overflow-x-auto rounded-xl border border-border">
          <table className="w-full min-w-[40rem] text-left text-sm">
            <thead className="border-b border-border bg-secondary text-muted">
              <tr>
                <th className="px-4 py-3 font-medium">Nama</th>
                <th className="px-4 py-3 font-medium">Ukuran</th>
                <th className="px-4 py-3 font-medium">Unduh</th>
                <th className="px-4 py-3 font-medium">Status</th>
                <th className="px-4 py-3 font-medium" />
              </tr>
            </thead>
            <tbody>
              {data.items.length === 0 ? (
                <tr>
                  <td colSpan={5} className="px-4 py-10 text-center text-muted">
                    Belum ada berkas.
                  </td>
                </tr>
              ) : (
                data.items.map((file) => (
                  <tr key={file.id} className="border-b border-border last:border-0">
                    <td className="px-4 py-3">
                      <a
                        href={file.kind === "file" ? `/f/${file.id}` : `/v/${file.id}`}
                        className="font-medium hover:underline"
                      >
                        {file.originalName}
                      </a>
                      <p className="font-mono text-[11px] text-muted">{file.id}</p>
                    </td>
                    <td className="px-4 py-3 tabular-nums">{formatBytes(file.sizeBytes)}</td>
                    <td className="px-4 py-3 tabular-nums">{file.downloadCount}</td>
                    <td className="px-4 py-3">{file.reported ? "Dilaporkan" : "Normal"}</td>
                    <td className="px-4 py-3 text-right">
                      <Button type="button" variant="ghost" size="sm" onClick={() => void remove(file.id)}>
                        Hapus
                      </Button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {totalPages > 1 ? (
          <div className="flex items-center justify-between text-sm">
            <Button
              type="button"
              variant="outline"
              size="sm"
              disabled={page <= 1}
              onClick={() =>
                void navigate({
                  search: { ...search, page: page - 1 > 1 ? page - 1 : undefined },
                })
              }
            >
              Sebelumnya
            </Button>
            <span className="tabular-nums text-muted">
              {page} / {totalPages}
            </span>
            <Button
              type="button"
              variant="outline"
              size="sm"
              disabled={page >= totalPages}
              onClick={() => void navigate({ search: { ...search, page: page + 1 } })}
            >
              Berikutnya
            </Button>
          </div>
        ) : null}
      </div>
    </SiteShell>
  );
}
